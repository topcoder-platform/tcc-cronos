(A)

the following back end module API changes should be made:
(1) add method GroupInvitationService.addInvitation(invitation:GroupInvitation):void
    this method should set the newly assigned invitation id to the given entity.
(2) add method GroupInvitationService.getInvitation(invitationId:long):GroupInvitation
(3) GroupInvitationService.sendInvitation should not save invitation, we should use the
      above addInvitation to save invitation.
(4) AuthorizationService.isAdministrator(userId:long):boolean should be added to test if user is TC admin
(5) AuthorizationService.getGroupIdsOfFullPermissionsUser(userId:long):List<Long> should be added
(6) CustomerAdministratorService.getCustomersForAdministrator(userId:long):List<Client> should be added.

(7) GroupSearchCriteria.userId:Long should be added, if this userId is not null, then do extra filtering:
If the user is a customer admin, only groups of the customers
for which he is an admin should be shown. If the user is a TC admin, all groups should be shown. If the user is "full"
permission user for some groups, such groups will be shown.

The logical processing is like below, but back end should optimize the processing, e.g. directly query data using a dedicated SQL.

// for admin, no need to filter
if (!authorizationService.isAdministrator(userId)) {
    // filter groups
    List<Client> clients = customerAdministratorService.getCustomersForAdministrator(userId);
    List<Long> groupIds = authorizationService.getGroupIdsOfFullPermissionsUser(userId);
    for any group of groups {
        if (group.id is not in groupIds) and (group.client.id is not any of ids of clients) {
            the group should not be included;
        }
    }
}


(8) InvitationSearchCriteria.ownedUserId:Long should be added, if this is not null, then do extra filtering:
Only invitations received by the user of ownedUserId should be shown.

The logical processing is like below, but back end should optimize the processing, e.g. directly query data using a dedicated SQL.

for any invitation of the invitations, if invitation.groupMember.userId is not the userId, then this invitation should not be included.


(9) InvitationSearchCriteria.masterUserId:Long should be added, if this is not null, then do extra filtering:
If the user is a customer admin,
only pending approvals for groups of the customers for which he is an admin should be shown. If the user
is a TC admin, all pending approvals. If the user is "full" permission user for some groups, only pending
approvals of such groups will be shown.

The logical processing is like below, but back end should optimize the processing, e.g. directly query data using a dedicated SQL.

// for admin, no need to filter
if (!authorizationService.isAdministrator(userId)) {
    List<Client> clients = customerAdministratorService.getCustomersForAdministrator(userId);
    List<Long> groupIds = authorizationService.getGroupIdsOfFullPermissionsUser(userId);
    for any invitation of invitations {
        if (invitation.groupMember.group.id is not in groupIds)
            and (invitation.groupMember.group.client.id is not any of ids of clients) {
            the invitation should not be included;
        }
    }
}


(10) GroupMemberSearchCriteria.userId:Long should be added, if this is not null, then do extra filtering:
If the user is a customer admin,
only groups of the customers for which he is an admin should be shown. If the user is a TC admin,
all groups should be shown. If the user is "full" permission user for some groups, such groups will be shown.

The logical processing is like below, but back end should optimize the processing, e.g. directly query data using a dedicated SQL.

// for admin, no need to filter
if (!authorizationService.isAdministrator(userId)) {
    List<Client> clients = customerAdministratorService.getCustomersForAdministrator(userId);
    List<Long> groupIds = authorizationService.getGroupIdsOfFullPermissionsUser(userId);
    for any hd of historicalData {
        Get group of hd.groupId using groupService;
        if (hd.groupId is not in groupIds) and (group.client.id is not any of ids of clients) {
            the hd should not be included;
        }
    }
}




(B)
assembly doc is provided just stating integration information,
this is minor and does not deserve an assembly,
this info may be added to a later application-wise integration.


