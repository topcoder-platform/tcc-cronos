1.For the page header,
  I make it following the forum thread:http://apps.topcoder.com/forums/?module=Thread&threadID=726497&start=0
  So the header in my prototype is different from that in the storyboard.