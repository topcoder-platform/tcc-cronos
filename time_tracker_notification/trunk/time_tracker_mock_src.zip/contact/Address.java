
package com.topcoder.timetracker.contact;

/**
 * 
 * 
 * @poseidon-object-id [I3998e7b8m111455da48fmm4ae7]
 */
public class Address {
 }
