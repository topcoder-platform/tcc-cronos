
package com.topcoder.timetracker.contact;

import com.topcoder.util.errorhandling.BaseException;

/**
 * 
 * 
 * @poseidon-object-id [I3998e7b8m111455da48fmm4a1a]
 */
public class BatchOperationException extends BaseException {
 }
