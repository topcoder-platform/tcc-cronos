
package com.topcoder.timetracker.audit.persistence;

/**
 * 
 * 
 * @poseidon-object-id [Im1e78d9em1115b8e6d62mm5b16]
 */
public class Log {
 }
