
package com.topcoder.timetracker.audit.ejb;

/**
 * 
 * 
 * @poseidon-object-id [I1a8685a4m1113fbd4f95mm57f8]
 */
public class SessionContext {
 }
