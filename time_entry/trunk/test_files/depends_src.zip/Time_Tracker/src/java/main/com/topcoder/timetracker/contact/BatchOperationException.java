/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.contact;

import com.topcoder.search.builder.filter.*;

/**
 * <p>This exception will be thrown by the Contact/AddressManager classes, EJB entities, and Contact/AddressDAO classes when any operation in the batch is failed. This exception will be exposed to the caller of batch operation methods.</p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class BatchOperationException extends PersistenceException {

    /**
     * <p>Represents whether the operations in the batch are successfully compleleted. It will be set in the constructor. It is possible null, possible empty. It will be referenced by the getResult method.</p>
     *
     */
    private final boolean[] result;

    /**
     * <p>Constructs the AddressManager with given DAO and namespace.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <ol>
     * <li>Get the configManager by ConfigManager.getInstance()</li>
     * <li>Get the addressControllerNAme from the configManager with namespace and key as &quot;address_controller_name&quot;</li>
     * <li>
     * If the DAO isn't null, save the DAO to the like named variable. Else
     * <ol>
     * <li>Get the objectFactoryNamespace from the configManager with namespace and key as &quot;object_factory_namespace&quot;</li>
     * <li>Create the ObjectFactory with a new ConfigManagerSpecificationFactory created with the objectFactoryNamespace</li>
     * <li>Create dao by the ObjectFactory with the key as &quot;AddressDAO&quot;</li>
     * </ol>
     * </li>
     * </ol>
     *
     * @param message a possible null, possible empty(trim'd) error message
     * @param result possible null, possible empty array represents whether the operations in the batch are successfully compleleted
     */
    public BatchOperationException(String message, boolean[] result) {
        super(message);

        this.result = result;
    }

    /**
     * <p>Constructs the exception with given message.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message)</p>
     * <p></p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     * @param cause a possibly null cause exception
     * @param result possible null, possible empty array represents whether the operations in the batch are successfully compleleted
     */
    public BatchOperationException(String message, Exception cause, boolean[] result) {
        super(message, cause);

        this.result = result;
    }

    /**
     * <p>Get the result of the batch operation.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return result.</p>
     *
     * @return possible null, possible empty array represents whether the operations in the batch are successfully compleleted
     */
    public boolean[] getResult() {
        return result;
    }
}
