package com.topcoder.timetracker.entry.fixedbilling;

import com.topcoder.timetracker.entry.base.BaseEntry;

/**
 * <p>
 * This is the main data class of the component, and includes getters and setters to
 * access the various properties of a Fixed Billing Entry,   A Fixed Billing Entry is
 * an amount of money spent by a Project Manager for a specific Project and client.
 * </p>
 * <p>
 * This class extends BaseEntry to retrieve the properties common to a
 * Time Tracker Entry.  It also inherits from the base TimeTrackerBean
 * to include the id, creation and modification details.
 * </p>
 * <p>
 * Thread Safety:
 * This class is not thread safe; Each thread is expected to work on it's own instance,
 * or this class should be used in a read-only manner for concurrent access.
 * </p>
 *
 * @poseidon-object-id [I19d4db0cm110ea540a2fm3aee]
 */
public class FixedBillingEntry extends BaseEntry {

    /**
     * <p>
     * This is the amount of money that was spent.
     * </p>
     * <p>
     * Initial Value: 0.0
     * </p>
     * <p>
     * Accessed In: getAmount
     * </p>
     * <p>
     * Modified In: setAmount
     * </p>
     * <p>
     * Utilized In: Not Utilized
     * </p>
     * <p>
     * Valid Values: Non-null BigDecimals that are >= 0
     * </p>
     *
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3b47]
     */
    private double amount = 0.0;

    /**
     * <p>
     * This is the status of the entry, which is an indication of
     * how the FixedBillingEntry is being processed by the Time Tracker system..
     * </p>
     * <p>
     * Initial Value: null
     * </p>
     * <p>
     * Accessed In: getStatus
     * </p>
     * <p>
     * Modified In: setStatus
     * </p>
     * <p>
     * Utilized In: Not Utilized
     * </p>
     * <p>
     * Valid Values: Null (during initialization) or Non-null FixedBillingStatus objects (after setting)
     * </p>
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3c36]
     */
    private FixedBillingStatus fixedBillingStatus;

    /**
     * <p>
     * This is the id of the Time Tracker Invoice which is associated with this
     * entry (if any).  If it is 0, it represents that no invoice was associated.
     * </p>
     * <p>
     * Initial Value: null
     * </p>
     * <p>
     * Accessed In: getInvoiceId
     * </p>
     * <p>
     * Modified In: setInvoiceId
     * </p>
     * <p>
     * Utilized In: Not Utilized
     * </p>
     * <p>
     * Valid Values: Numbers >= 0
     * </p>
     *
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3c58]
     */
    private long invoiceId;

    /**
     * <p>
     * Default constructor.
     * </p>
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3c13]
     */
    public FixedBillingEntry() {
        // your code here
    }

    /**
     * <p>
     * Gets the status of the entry, which is an indication of
     * how the FixedBillingEntry is being processed by the
     * Time Tracker system..
     * </p>
     *
     *
     * @poseidon-object-id [Im201b61aam110ea9a3fb2mm4eff]
     * @return the status of the entry
     */
    public com.topcoder.timetracker.entry.fixedbilling.FixedBillingStatus getFixedBillingStatus() {
        return this.fixedBillingStatus;
    }

    /**
     * <p>
     * Sets the status of the entry, which is an indication of
     * how the FixedBillingEntry is being processed by the
     * Time Tracker system..
     * </p>
     *
     *
     * @poseidon-object-id [Im201b61aam110ea9a3fb2mm4ee4]
     * @param fixedBillingStatus the status of the entry
     * @throws IllegalArgumentException if status is null.
     */
    public void setFixedBillingStatus(com.topcoder.timetracker.entry.fixedbilling.FixedBillingStatus fixedBillingStatus) {
        this.fixedBillingStatus = fixedBillingStatus;
    }

    /**
     * <p>
     * This is the id of the Time Tracker Invoice which is associated with this
     * entry (if any).  It will be 0 to indicate no invoiceId is currently associated..
     * </p>
     *
     *
     * @poseidon-object-id [I505fe2em11111512d34mm363c]
     * @return The id of the invoice associated with this entry.
     */
    public long getInvoiceId() {
        return invoiceId;
    }

    /**
     * <p>
     * This is the id of the Time Tracker Invoice which is associated with this
     * entry (if any).  It will be 0 to indicate no invoiceId is currently associated.
     * </p>
     *
     *
     * @poseidon-object-id [I505fe2em11111512d34mm3621]
     * @param invoiceId the id of the Time Tracker Invoice which is associated with this entry (if any).
     * @throws IllegalArgumentException if invoiceId is < 0.
     */
    public void setInvoiceId(long invoiceId) {
        this.invoiceId = invoiceId;
    }

    /**
     * <p>
     * Gets the amount of money that was spent.
     * </p>
     *
     * @poseidon-object-id [Im289d5a81m1111712f980mm3773]
     * @return the amount of money that was spent.
     */
    public double getAmount() {
        return amount;
    }

    /**
     * <p>
     * Sets the amount of money that was spent.
     * </p>
     *
     * @poseidon-object-id [Im289d5a81m1111712f980mm3758]
     * @param amount the amount of money that was spent.
     * @throws IllegalArgumentException if amount is < 0.
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }
}