/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.rejectreason;

import com.topcoder.util.errorhandling.BaseException;

/**
 * This exception is thrown when a problem occurs while working with the RejectReason DAOs.
 * <ID="UML note. note-id=[Im51386793m1113e23f788mm3cf2] ">Custom Exceptions are thrown by locals, DAOAccesses,
 * and sessionBeans. So the throws dependencies are shown
 * as package to CE rather than classes to CE for clarity
 * <BR></ID>
 *
 * @author TCSDEVELOPER, TCSDEVELOPER
 * @version 1.0
 */
public class RejectReasonDAOException extends BaseException {

    /**
     * <p>The Reject Reason that the DAO was working with when a problem occurred.</p>
     * <p>Initialized In: Constructor (may be null).</p>
     * <p>Accessed In: getProblemRejectReason</p>
     * <p>Modified In: Not modified</p>
     *
     */
    private RejectReason problemRejectReason;

    /**
     * <p>Constructor accepting a message</p>
     * <p>Implementation Notes: Simply call super(message);</p>
     * <p></p>
     *
     * @param message The message of the exception.
     * @throws IllegalArgumentException if the message is null or an empty String.
     */
    public RejectReasonDAOException(String message) {
        // your code here
    }

    /**
     * <p>Constructor accepting a message and cause.</p>
     * <p>Implementation Notes: Simply call super(message, cacuse);</p>
     * <p></p>
     *
     * @param message The message of the exception
     * @param cause The cause of the exception
     * @throws IllegalArgumentException if the message is null or an empty String.
     */
    public RejectReasonDAOException(String message, Throwable cause) {
        // your code here
    }

    /**
     * <p>Constructor accepting a message, cause and problem RejectReason.</p>
     *
     * @param message The message of the exception.
     * @param cause The cause of the exception.
     * @param reason The RejectReason that the DAO was working on when the exception occurred.
     * @throws IllegalArgumentException if the message is null or an empty String.
     */
    public RejectReasonDAOException(String message, Throwable cause, RejectReason reason) {
        // your code here
    }

    /**
     * <p>Retrieves the Reject Reason that the DAO was working with when a problem occurred.</p>
     *
     * @return the Reject Reason that the DAO was working with when a problem occurred.
     */
    public RejectReason getProblemRejectReason() {
        // your code here
        return null;
    }
}
