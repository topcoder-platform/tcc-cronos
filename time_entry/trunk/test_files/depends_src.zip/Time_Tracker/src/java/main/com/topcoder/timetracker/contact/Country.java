/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.contact;

import com.topcoder.timetracker.common.TimeTrackerBean;
import com.topcoder.search.builder.filter.*;

/**
 * This class holds the information of a country
 * <p><strong>Implementation Notes:</strong></p>
 * <p>This class will be created by the application directly and created by the implementaions of AddressDAO. The application can get/set all the properties of it.</p>
 * <p><strong>Thread Safety:</strong></p>
 * <p>This class is not thread safe by being mutable. This class is not supposed to be used in multithread environment. If it would be used in multithread environment, it should be synchronized externally.</p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class Country extends TimeTrackerBean {

    /**
     * <p>Represents the name of the country. This variable is set to null initially,&nbsp; is mutable. It is only allowed to be set to non null, non empty string by the setter. It is access by its getter and setter methods.</p>
     *
     */
    private String name = null;

    /**
     * <p>Constructs the Country</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Empty constructor.</p>
     * <p></p>
     *
     */
    public Country() {
        // your code here
    }

    /**
     * <p>Get the name</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return name</p>
     * <p></p>
     *
     * @return possible null, non empty name
     */
    public String getName() {
        return name;
    }

    /**
     * <p>Set the name</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variable</p>
     *
     * @param name non null, non empty name
     * @throws IllegalArgumentException if the name is null or empty(trim'd)
     */
    public void setName(String name) {
        this.name = name;
    }
}
