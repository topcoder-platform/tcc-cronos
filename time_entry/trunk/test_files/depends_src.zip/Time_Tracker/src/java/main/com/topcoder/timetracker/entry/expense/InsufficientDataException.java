package com.topcoder.timetracker.entry.expense;

import com.topcoder.util.errorhandling.BaseException;

/**
 * This exception is thrown when some required fields (NOT NULL) are not set when creating or
 * updating an entry, type or status in the persistence. <span style="color:Blue">This exception
 * are thrown by the persistence interfaces and implementations, EJBs, and the manager interfaces
 *  and implementations.</span>
 *
 * @poseidon-object-id [Im1793e9bfm1047f09dd91mm7781]
 */
public class InsufficientDataException extends BaseException {

    /**
     * Creates a new instance of this custom exception. This constructor has one parameter: message - a decriptive message
     *
     * @poseidon-object-id [Im1793e9bfm1047f09dd91mm7734]
     * @param message a descriptive message
     */
    public InsufficientDataException(String message) {
        // your code here
    }

    /**
     * Creates a new instance of this custom exception. This constructor has two parameters: message -
     *  a decriptive message cause - the cause exception
     *
     * @poseidon-object-id [Im1793e9bfm1047f09dd91mm76cf]
     * @param message a descriptive message
     * @param cause the cause
     */
    public InsufficientDataException(String message, Throwable cause) {
        // your code here
    }
}
