/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.rejectreason;

/**
 * This exception is thrown if the involved RejectReason was not found in the data store. This is thrown during update/delete methods.
 * <ID="UML note. note-id=[Im51386793m1113e23f788mm3cf2] ">Custom Exceptions are thrown by locals, DAOAccesses,
 * and sessionBeans. So the throws dependencies are shown
 * as package to CE rather than classes to CE for clarity
 * <BR></ID>
 *
 * @author TCSDEVELOPER, TCSDEVELOPER
 * @version 1.0
 */
public class RejectReasonNotFoundException extends RejectReasonDAOException {

    /**
     * <p>Constructor accepting a message</p>
     * <p>Implementation Notes: Simply call super(message);</p>
     * <p></p>
     *
     * @param message The message of the exception.
     * @throws IllegalArgumentException if the message is null or an empty String.
     */
    public RejectReasonNotFoundException(String message) {
        super(message);
    }

    /**
     * <p>Constructor accepting a message and cause.</p>
     * <p>Implementation Notes: Simply call super(message, cacuse);</p>
     * <p></p>
     *
     * @param message The message of the exception
     * @param cause The cause of the exception
     * @throws new value
     */
    public RejectReasonNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * <p>Constructor accepting a message, cause and problem RejectReason.</p>
     *
     * @param message The message of the exception.
     * @param cause The cause of the exception.
     * @param reason The RejectReason that the DAO was working on when the exception occurred.
     */
    public RejectReasonNotFoundException(String message, Throwable cause, RejectReason reason) {
        super(message, cause, reason);
    }
}
