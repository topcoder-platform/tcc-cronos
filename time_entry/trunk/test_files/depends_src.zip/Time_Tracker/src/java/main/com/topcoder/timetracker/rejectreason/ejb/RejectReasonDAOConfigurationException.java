/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.timetracker.rejectreason.ejb;

import com.topcoder.timetracker.rejectreason.RejectReasonDAOException;

/**
 * This exception is thrown from constructor of RejectReasonSessionBean when any of needed environment variables to create an instance of RejecReasonDAO can't be found or with an illegal value.
 *
 *
 * @author TCSDEVELOPER, TCSDEVELOPER
 * @version 1.0
 */
public class RejectReasonDAOConfigurationException extends RejectReasonDAOException {

    /**
     * <p>Constructor accepting a message</p>
     * <p>Implementation Notes: Simply call super(message);</p>
     * <p></p>
     *
     * @param message The message of the exception.
     * @throws IllegalArgumentException if the message is null or an empty String.
     */
    public RejectReasonDAOConfigurationException(String message) {
        super(message);
    }

    /**
     * <p>Constructor accepting a message and cause.</p>
     * <p>Implementation Notes: Simply call super(message, cacuse);</p>
     * <p></p>
     *
     * @param message The message of the exception
     * @param cause The cause of the exception
     * @throws IllegalArgumentException if the message is null or an empty String.
     */
    public RejectReasonDAOConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
