/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.rejectreason;

import com.topcoder.search.builder.filter.Filter;
import com.topcoder.timetracker.rejectreason.RejectReason;
import com.topcoder.timetracker.rejectreason.RejectReasonDAOException;
import com.topcoder.timetracker.rejectreason.RejectReasonNotFoundException;

/**
 * <p>This interface defines the necessary methods that a RejectReason DAO should support. Create, Retrieve, Update, Delete and Enumerate (CRUDE) methods are provided. There is also a search method that utilizes Filter classes from the Search Builder 1.3.1 component.</p>
 * <p>Thread Safety: - Implementations should be thread safe.</p>
 *
 *
 * @author TCSDEVELOPER, TCSDEVELOPER
 * @version 1.0
 */
public interface RejectReasonDAO {

    /**
     * <p>This is a constant for a search filter field name for the Company Id which a RejectReason belongs to.</p>
     * <p>Filters from the Search Builder component may use this constant when building their search parameters. Implementations of the RejectReasonDAO interface should be able to recognize search filters bearing the provided constant and adjust their searches according to the searchRejectReasons method.</p>
     * <p>Initialized In:&nbsp; declaration</p>
     * <p>Accessed In: class variable can be access directly</p>
     * <p>Modified In: Not modified</p>
     * <p></p>
     *
     */
    public static final String SEARCH_COMPANY_ID = "search_company_id";

    /**
     * <p>This is a constant for a search filter field name for the Description of the RejectReason</p>
     * <p>Filters from the Search Builder component may use this constant when building their search parameters. Implementations of the RejectReasonDAO interface should be able to recognize search filters bearing the provided constant and adjust their searches according to the searchRejectReasons method.</p>
     * <p>Initialized In:&nbsp; declaration</p>
     * <p>Accessed In: class variable can be access directly</p>
     * <p>Modified In: Not modified</p>
     * <p></p>
     * <p></p>
     *
     */
    public static final String SEARCH_DESCRIPTION = "search_description";

    /**
     * <p>This is a constant for a search filter field name for the Active Status of the RejectReason</p>
     * <p>Filters from the Search Builder component may use this constant when building their search parameters. Implementations of the RejectReasonDAO interface should be able to recognize search filters bearing the provided constant and adjust their searches according to the searchRejectReasons method.</p>
     * <p>Initialized In:&nbsp; declaration</p>
     * <p>Accessed In: class variable can be access directly</p>
     * <p>Modified In: Not modified</p>
     * <p></p>
     * <p></p>
     *
     */
    public static final String SEARCH_ACTIVE_STATUS = "search_active_status";

    /**
     * <p>This is a constant for a search filter field name for the Reject Reason's Date of Creation.</p>
     * <p>Filters from the Search Builder component may use this constant when building their search parameters. Implementations of the RejectReasonDAO interface should be able to recognize search filters bearing the provided constant and adjust their searches according to the searchRejectReasons method.</p>
     * <p>Initialized In:&nbsp; declaration</p>
     * <p>Accessed In: class variable can be access directly</p>
     * <p>Modified In: Not modified</p>
     * <p></p>
     * <p></p>
     *
     */
    public static final String SEARCH_CREATED_DATE = "search_created_date";

    /**
     * <p>This is a constant for a search filter field name for the Reject Reason's User Creator.</p>
     * <p>Filters from the Search Builder component may use this constant when building their search parameters. Implementations of the RejectReasonDAO interface should be able to recognize search filters bearing the provided constant and adjust their searches according to the searchRejectReasons method.</p>
     * <p>Initialized In:&nbsp; declaration</p>
     * <p>Accessed In: class variable can be access directly</p>
     * <p>Modified In: Not modified</p>
     * <p></p>
     * <p></p>
     *
     */
    public static final String SEARCH_CREATED_USER = "search_created_user";

    /**
     * <p>This is a constant for a search filter field name for the Reject Reason's Last Date of Modification.</p>
     * <p>Filters from the Search Builder component may use this constant when building their search parameters. Implementations of the RejectReasonDAO interface should be able to recognize search filters bearing the provided constant and adjust their searches according to the searchRejectReasons method.</p>
     * <p>Initialized In:&nbsp; declaration</p>
     * <p>Accessed In: class variable can be access directly</p>
     * <p>Modified In: Not modified</p>
     * <p></p>
     * <p></p>
     *
     */
    public static final String SEARCH_MODIFICATION_DATE = "search_modification_date";

    /**
     * <p>This is a constant for a search filter field name for the Reject Reason's Last User of Modification.</p>
     * <p>Filters from the Search Builder component may use this constant when building their search parameters. Implementations of the RejectReasonDAO interface should be able to recognize search filters bearing the provided constant and adjust their searches according to the searchRejectReasons method.</p>
     * <p>Initialized In:&nbsp; declaration</p>
     * <p>Accessed In: class variable can be access directly</p>
     * <p>Modified In: Not modified</p>
     * <p></p>
     * <p></p>
     *
     */
    public static final String SEARCH_MODIFICATION_USER = "search_modification_user";

    /**
     * <p>Creates a datastore entry for the given Reject Reason. An id is automatically generated by the DAO and assigned to the reason. The RejectReason is also considered to have been created by the specified username.&nbsp;If the argument isAudit is true, insert the corresponding audit record in data store.</p>
     *
     * @param rejectReason the RejectReason to be persistent in the data store
     * @param username The username of the user responsible for creating the RejectReason entry within the datastore.
     * @param isAudit Need audit or not
     * @return The same rejectReason Object, with an assigned id, creationDate, modificationDate, creationUser and modificationUser assigned appropriately. (none null)
     * @throws IllegalArgumentEException if the rejectReason or username is null, or if username is an empty String.
     * @throws RejectReasonDAOException if a problem occurs while accessing the data store.
     */
    public RejectReason createRejectReason(RejectReason rejectReason, String username, boolean isAudit)
        throws RejectReasonDAOException;

    /**
     * <p>Retrieves a RejectReason from the datastore with the provided id. If no RejectReason with that id exists, then a null is returned.</p>
     *
     * @param id The id of the RejectReason to retrieve from the datastore.
     * @return The retrieved RejectReason object (maube null)
     * @throws IllegalArgumentException if id is <=0
     * @throws RejectReasonDAOException if a problem occurs while accessing the data store.
     */
    public RejectReason retrieveRejctReason(long id) throws RejectReasonDAOException;

    /**
     * <p>Updates the given RejectReason in the data store. The RejectReason is considered to have been modified by the specified username.&nbsp;If the argument isAudit is true, insert the corresponding audit record in data store.</p>
     *
     * @param rejectReason The RejectReason entity to modify.
     * @param username The username of the user responsible for performing the update.
     * @param isAudit Need audit or not
     * @throws RejectReasonDAOException if a problem occurs while accessing the data store.
     * @throws RejectReasonNotFoundException if the RejectReason to update was not found in the data store.
     */
    public void updateRejectReason(RejectReason rejectReason, String username, boolean isAudit)
        throws RejectReasonNotFoundException, RejectReasonDAOException;

    /**
     * <p>Removes the specified RejectReason from the data store.&nbsp;If the argument isAudit is true, insert the corresponding audit record in data store.</p>
     *
     * @param rejectReason The rejectReason to delete.
     * @param isAudit Need audit or not
     * @throws IllegalArgumentException if the rejectReason is null.
     * @throws RejectReasonDAOException if a problem occurs while accessing the data store.
     * @throws RejectReasonNotFoundException if the RejectReason to delete was not found in the data store.
     */
    public void deleteRejectReason(RejectReason rejectReason, String username, boolean isAudit)
        throws RejectReasonNotFoundException, RejectReasonDAOException;

    /**
     * <p>Enumerates all the RejectReasons that are present within the data store. &nbsp;If no record found an empty array will be return.</p>
     *
     * @return A list of all the RejectReasons within the data store.
     * @throws RejectReasonDAOException if a problem occurs while accessing the data store.
     */
    public RejectReason[] listRejectReasons() throws RejectReasonDAOException;

    /**
     * <p>Returns a list of all the RejectReasons within the datastore that satisfy the filters that are provided. &nbsp;If no record found an empty array will be return. The filters are defined using classes from the Search Builder v1.3.1 component and com.cronos.timetracker. common.search package.</p>
     *
     * @param filter The filter that is used as criterion to facilitate the search..
     * @return A list of RejectReasons that satisfy the search criterion.
     * @throws IllegalArgumentException if the filter is null.
     * @throws RejectReasonDAOException if a problem occurs while accessing the data store.
     */
    public RejectReason[] searchRejectReasons(Filter filter) throws RejectReasonDAOException;
}
