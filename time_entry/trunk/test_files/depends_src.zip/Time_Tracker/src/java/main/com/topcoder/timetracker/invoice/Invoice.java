package com.topcoder.timetracker.invoice;

import com.topcoder.timetracker.common.PaymentTerm;
import com.topcoder.timetracker.common.TimeTrackerBean;
import com.topcoder.timetracker.entry.expense.ExpenseEntry;
import com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry;
import com.topcoder.timetracker.invoice.servicedetail.ServiceDetail;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>This is the main data class of the component, and includes getters and setters to access the
 * various properties of a Time Tracker Invoice, This class encapsulates the invoice's information
 * within the Time Tracker component.</p>
 * <p>It also extends from the base TimeTrackerBean to include the id, creation and modification details.</p>
 * <p>Thread Safety: This class is not thread safe; Each thread is expected to work on it's own instance,
 * or this class should be used in a read-only manner for concurrent access.</p>
 *
 * @poseidon-object-id [I2490ae86m111523c2c74mm7f0a]
 */
public class Invoice extends TimeTrackerBean {
    /**
     * <p>This is the company's id that this invoice belongs to</p>
     * <p>Initial Value: Long.MIN_VALUE (This indicates an uninitialized value)</p>
     * <p>Accessed In: getCompanyId</p>
     * <p>Modified In: setCompanyId</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7d07]
     */
    private long companyId;

    /**
     * <p>This is the project's id that this invoice will be billed to</p>
     * <p>Initial Value: Long.MIN_VALUE (This indicates an uninitialized value)</p>
     * <p>Accessed In: getProjectId</p>
     * <p>Modified In: setProjectId</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7d02]
     */
    private long projectId;

    /**
     * <p>The Accounting Invoice number wich ties this invoice back to the account system.</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getInvoiceNumber</p>
     * <p>Modified In: setInvoiceNumber</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cfd]
     */
    private String invoiceNumber;

    /**
     * <p>Entered by admin to tie the invoice to a customers purchase order</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getPurchaseOrderNumber</p>
     * <p>Modified In: setPurchaseOrderNumber</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cf8]
     */
    private String purchaseOrderNumber;

    /**
     * <p>Has this invoice been paid</p>
     * <p>Initial Value: false</p>
     * <p>Accessed In: isPaid</p>
     * <p>Modified In: setPaid</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cf2]
     */
    private boolean paid;

    /**
     * <p>The due date plus the number of days in the terms</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getDueDate</p>
     * <p>Modified In: setDueDate</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7ced]
     */
    private Date dueDate;

    /**
     * <p>The invoice date plus the number of days in the terms</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getInvoiceDate</p>
     * <p>Modified In: setInvoiceDate</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7ce8]
     */
    private Date invoiceDate;

    /**
     * <p>The total of all the Service Details.</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getServicesSubTotal</p>
     * <p>Modified In: none</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7ce3]
     */
    private BigDecimal servicesSubTotal;

    /**
     * <p>The total of all the expense</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getExpenseSubTotal</p>
     * <p>Modified In: none</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cde]
     */
    private BigDecimal expenseSubTotal;

    /**
     * <p>The sales for this invoice, from the project record.</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getSalesTax</p>
     * <p>Modified In: setSalesTax</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cd9]
     */
    private BigDecimal salesTax;

    /**
     * <p>The current status of the invoice</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getInvoiceStatus</p>
     * <p>Modified In: setInvoiceStatus</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cd4]
     */
    private InvoiceStatus invoiceStatus;

    /**
     * <p>The terms of this invoice</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getPaymentTerms</p>
     * <p>Modified In: setPaymentTerms</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7ccf]
     */
    private PaymentTerm paymentTerm;

    /**
     * <p>The list of Expense being billed on this invoice</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getExpenseEntries</p>
     * <p>Modified In: setExpenseEntries</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values,can be void, can contain null values.</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cc9]
     */
    private ExpenseEntry[] expenseEntries;

    /**
     * <p>The list of Fixed Billing being billed on this invoice</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getFixedBillingEntries</p>
     * <p>Modified In: setFixedBillingEntries</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values,can be void, can contain null values.</p>
     *
     */
    private FixedBillingEntry[] fixedBillingEntries;

    /**
     * <p>The list of Time Entries being billed on this invoice</p>
     * <p>Initial Value: Null</p>
     * <p>Accessed In: getServiceDetails</p>
     * <p>Modified In: setServiceDetails</p>
     * <p>Utilized In: Not Utilized</p>
     * <p>Valid Values: all values,can be void, can contain null values.</p>
     *
     */
    private ServiceDetail[] serviceDetails;

    /**
     * <p>Construct an empty Invoice</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cb7]
     */
    public Invoice() {
        // TODO Auto-generated constructor stub
    }

    /**
     * Return the company id.
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7cb1]
     * @return the company id
     */
    public long getCompanyId() {
        return companyId;
    }

    /**
     * <p>Set the company id.</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7ca8]
     * @param companyId the company id to set
     */
    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    /**
     * <p>Return the due date</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7ca1]
     * @return the due date
     */
    public Date getDueDate() {
        return dueDate;
    }

    /**
     * <p>Set the due date</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c99]
     * @param dueDate the due date to set
     */
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * <p>Return the expense entries</p>
     * <p>Impl: return a shallow copy</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c92]
     * @return the expense entries
     */
    public ExpenseEntry[] getExpenseEntries() {
        return expenseEntries;
    }

    /**
     * <p>Set the expense entries</p>
     * <p>Valid args: all args, can be void, can contains null values</p>
     * <p>Impl:</p>
     * <p>Set the expense entries and calculate the subtotals. For subtotals sum all expense amounts (amount property).</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c8a]
     * @param expenseEntries the expense entries to set
     */
    public void setExpenseEntries(ExpenseEntry[] expenseEntries) {
        this.expenseEntries = expenseEntries;
    }

    /**
     * Return the expense sub total
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c83]
     * @return the expense sub total
     */
    public BigDecimal getExpenseSubTotal() {
        return expenseSubTotal;
    }

    /**
     * Return the invoice number
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c74]
     * @return the invoice number
     */
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    /**
     * <p>Set the invoice number</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c6c]
     * @param invoiceNumber the invoice number to set
     */
    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    /**
     * <p>Return the invoice service details</p>
     * <p>Impl: Return a shallow copy</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c65]
     * @return the invoice service details
     */
    public ServiceDetail[] getServiceDetails() {
        return serviceDetails;
    }

    /**
     * <p>Set the service details</p>
     * <p>Valid args: all args, can be void, can contains null values</p>
     * <p>Set the service details and calculate the subtotals. For subtotals sum all service details amounts (amount property).</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c5d]
     * @param serviceDetails the invoice dervice details to set
     */
    public void setServiceDetails(ServiceDetail[] serviceDetails) {
        this.serviceDetails = serviceDetails;
    }

    /**
     * Return the invoice status
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c56]
     * @return the invoice status
     */
    public InvoiceStatus getInvoiceStatus() {
        return invoiceStatus;
    }

    /**
     * <p>Set the invoice status</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c4e]
     * @param invoiceStatus the invoice status to set
     */
    public void setInvoiceStatus(InvoiceStatus invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    /**
     * Return true if the invoice has been paid, false otherwise
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c47]
     * @return true if the invoice has been paid, false otherwise
     */
    public boolean isPaid() {
        return paid;
    }

    /**
     * <p>Set the paid</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c3f]
     * @param paid the paid to set
     */
    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    /**
     * Return the payment terms
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c38]
     * @return the payment terms
     */
    public PaymentTerm getPaymentTerm() {
        return paymentTerm;
    }

    /**
     * <p>Set the payment terms</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c30]
     * @param paymentTerm the payment terms to set
     *
     * @param paymentTerms
     */
    public void setPaymentTerm(PaymentTerm paymentTerms) {
        this.paymentTerm = paymentTerms;
    }

    /**
     * Return the project id
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c2a]
     * @return the project dd
     */
    public long getProjectId() {
        return projectId;
    }

    /**
     * <p>Set the project id</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c22]
     * @param projectId the project id to set
     */
    public void setProjectId(long projectId) {
        this.projectId = projectId;
    }

    /**
     * Return the purchase order number
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c1b]
     * @return the purchase order number
     */
    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    /**
     * <p>Set the purchase order number</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c13]
     * @param purchaseOrderNumber the purchase order number to set
     */
    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    /**
     * Return the sales tax
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c0c]
     * @return the sales tax
     */
    public BigDecimal getSalesTax() {
        return salesTax;
    }

    /**
     * <p>Set the sales tax</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7c04]
     * @param salesTax the sales tax to set
     */
    public void setSalesTax(BigDecimal salesTax) {
        this.salesTax = salesTax;
    }

    /**
     * Return the services sub total
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7bfd]
     * @return the services sub total
     */
    public BigDecimal getServicesSubTotal() {
        return servicesSubTotal;
    }

    /**
     * <p>Return the fixed billing entries</p>
     * <p>Impl: return a shallow copy</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7bee]
     * @return the fixed billing entries
     */
    public FixedBillingEntry[] getFixedBillingEntries() {
        return fixedBillingEntries;
    }

    /**
     * <p>Set the fixed billing entries</p>
     * <p>Valid args: all args, can be void, can contains null values</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7be6]
     * @param fixedBillingEntries the fixed billing entries to set
     */
    public void setFixedBillingEntries(FixedBillingEntry[] fixedBillingEntries) {
        this.fixedBillingEntries = fixedBillingEntries;
    }

    /**
     * Return the invoice date
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7bdf]
     * @return the invoice date
     */
    public Date getInvoiceDate() {
        return invoiceDate;
    }

    /**
     * <p>Set the invoice date</p>
     * <p>Valid args: all args</p>
     *
     * @poseidon-object-id [I2490ae86m111523c2c74mm7bd7]
     * @param invoiceDate
     */
    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }
}
