package com.topcoder.timetracker.entry.expense;

import com.topcoder.timetracker.common.TimeTrackerBean;

/**
 * <strong>Purpose:</strong>
 * <p>This class holds the information about an expense entry status. </p>
 * <p><strong>Implementation Details:</strong></p>
 * <p>When creating an instance of this class the user has two options:
 * 1) Use the default constructor and allow the GUID Generator component to generate a unique id
 * 2) Use the parameterized constructor and provide an id for the ExpenseEntryStatus instance;
 * if the id already is contained by another status from the <span style="color:Red">expense_status</span>
 * table, then the newly created status will not be added to the <span style="color:Red">expense_status</span>
 * table. Also the user should not populate the creationDate and modificationDate fields,
 * because if he does, the status will not be added to the database. This fields will be handled
 * automatically by the component (the current date will be used). When loading from the persistence,
 * all the fields will be properly populated.</p>
 *
 * @poseidon-object-id [I68168348m10468c6f140mm292f]
 */
public class ExpenseStatus extends TimeTrackerBean {

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>This variable represents the description of the status. It is set/initialized in the
     *  dedictaed setter and can also be accessed through a dedicated getter.</p>
     * <p>Can be null.</p>
     * <p></p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm2fb]
     */
    private String description;

    /**
     * Empty constructor.
     *
     * @poseidon-object-id [Im6b4d4c86m1047f4b370fmm2cc5]
     */
    public ExpenseStatus() {
        // your code here
    }

    /**
     * Create a new instance. Simply initialize the id field.
     *
     * @poseidon-object-id [Im6b4d4c86m1047f4b370fmm2c6d]
     * @param id this value will be assigned to the id field
     */
    public ExpenseStatus(int id) {
        setId(id);
    }

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>Thi si a getter for the description variable currently set in this instance.
     * This could return any value including null.</p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm3cd]
     * @return the current description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>Setter for the description field. Can be any value, including null.</p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm388]
     * @param description description of the type to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
}