package com.topcoder.timetracker.entry.fixedbilling;

import com.topcoder.search.builder.filter.Filter;
import com.topcoder.timetracker.common.TimeTrackerBean;

/**
 * <p>
 * This is a bean that represents a FixedBillingEntryStatus, which represents a possible
 * state that a FixedBillingEntry can have in the context of the Time Tracker
 * system.
 * </p>
 * <p>
 * Thread Safety:
 * This class is not thread safe; Each thread is expected to work on it's own instance,
 * or this class should be used in a read-only manner for concurrent access.
 * </p>
 *
 *
 * @poseidon-object-id [I19d4db0cm110ea540a2fm3b69]
 */
public class FixedBillingStatus extends TimeTrackerBean {

    /**
     * <p>
     * This is a short String that describes the status.
     * </p>
     * <p>
     * Initial Value: null
     * </p>
     * <p>
     * Accessed In: getDescription
     * </p>
     * <p>
     * Modified In: setDescription
     * </p>
     * <p>
     * Utilized In: Not Utilized
     * </p>
     * <p>
     * Valid Values: Null (during initialization) or Not null and Not empty String objects (after setting)
     * </p>
     *
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3bb1]
     */
    private String description;

    /**
     * <p>
     * Default Constructor.
     * </p>
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3ce3]
     */
    public FixedBillingStatus() {
        // your code here
    }

    /**
     * <p>
     * Gets a short String that describes the status.
     * </p>
     *
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3d06]
     * @return a short String that describes the status.
     */
    public String getDescription() {
        return description;
    }

    /**
     * <p>
     * Sets a short String that describes the status.
     * </p>
     *
     *
     * @poseidon-object-id [I19d4db0cm110ea540a2fm3d21]
     * @param description a short String that describes the status.
     * @throws IllegalArgumentException if description is a null or empty String.
     */
    public void setDescription(String description) {
        this.description = description;
    }
}
