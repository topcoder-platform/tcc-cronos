package com.topcoder.timetracker.entry.expense;

import java.util.List;

/**
 * <strong>Purpose:</strong>
 * <p>This class holds the information about an expense entry type.</p>
 * <p><strong>Implementation Details:</strong></p>
 * <p>When creating an instance of this class the user has two options: 1) Use the default constructor and allow the GUID Generator component to generate a unique id 2) Use the parameterized constructor and provide an id for the ExpenseEntryType instance; if the id already is contained by another type from the ExpenseTypes table, then the newly created type will not be added to the ExpenseTypes table. Also the user should not populate the creationDate and modificationDate fields, because if he does, the type will not be added to the database. This fields will be handled automatically by the component (the current date will be used). When loading from the persistence, all the fields will be properly populated.</p>
 * <p><strong><span style="color:Red">Thread-Safety</span></strong></p>
 * <p><span style="color:Red">This class is not thread safe as it is mutable.</span></p>
 *
 * @poseidon-object-id [I68168348m10468c6f140mm2ceb]
 */
public class ExpenseType extends com.topcoder.timetracker.common.TimeTrackerBean {

    /**
     * the active flag of this expense entry type.
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1c16]
     */
    private boolean active;

    /**
     * the company id this expense entry type associated with.
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1bf5]
     */
    private int companyId;

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>This variable represents the description of the status. It is set/initialized in the dedictaed setter and can also be accessed through a dedicated getter.</p>
     * <p>Can be null.</p>
     * <p></p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm2d8]
     */
    private String description;

    /**
     * Create a new instance. Empty constructor.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm2c33]
     */
    public ExpenseType() {
        // empty
    }

    /**
     * Create a new instance. Simply initialize the id field.
     *
     * @poseidon-object-id [Im6b4d4c86m1047f4b370fmm2fda]
     * @param id this value will be assigned to the id field
     */
    public ExpenseType(int id) {
        setId(id);
    }

    /**
     * get the active flag
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1bb3]
     * @return the active flag of expense entry type
     */
    public boolean getActive() {
        return this.active;
    }

    /**
     * set active to new value
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1b6e]
     * @param active the active to set
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * get the company id
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1af4]
     * @return the company id
     */
    public int getCompanyId() {
        return this.companyId;
    }

    /** lock-begin */

    /**
     * set company id to new value
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1aaf]
     * @param companyId the company id to set
     * @throws IllegalArgumentException if companyId is -1
     */
    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>Thi si a getter for the description variable currently set in this instance. This could return any value including null.</p>
     * <p></p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm2b5]
     * @return currently set description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>Setter for the description field. Can be any value, including null.</p>
     * <p></p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm270]
     * @param description description to be set
     */
    public void setDescription(String description) {
        this.description = description;
    }
}