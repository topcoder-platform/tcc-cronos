/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.contact;

import com.topcoder.search.builder.filter.*;

/**
 * <p>This exception will be thrown by the Contact/AddressManager classes, EJB entities, and Contact/AddressDAO classes when trying to update the Contact/Address which can be not found. This exception will be exposed to the caller of updateContact/Address(s) updateContact/Address(s) methods.</p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class EntityNotFoundException extends ContactException {

    /**
     * <p>Constructs the exception with given message.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message)</p>
     * <p></p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     */
    public EntityNotFoundException(String message) {
        super(message);
    }

    /**
     * <p>Constructs the exception with given message and cause.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message, cause)</p>
     * <p></p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     * @param cause a possibly null cause exception
     */
    public EntityNotFoundException(String message, Exception cause) {
        super(message, cause);
    }
}
