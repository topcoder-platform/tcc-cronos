/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.timetracker.contact;

import com.topcoder.util.collection.typesafeenum.Enum;

/**
 * <p>This enumeration represents the address type.</p>
 * <p><strong>Implementation Notes:</strong></p>
 * <p>This enumeration will be used in AddressManager and implementations of AddressDAO.</p>
 * <p><strong>Thread Safety:</strong></p>
 * <p>This class is thread-safe by being immutable.</p>
 *
 */
public class AddressType extends Enum {
    /**
     * <p>Represents the project address type. It will never be null. It will be referenced in AddressManager.</p>
     *
     */
    public static final AddressType PROJECT = new AddressType(1, "PROJECT");

    /**
     * <p>Represents the client address type. It will never be null. It will be referenced in AddressManager.</p>
     *
     */
    public static final AddressType CLIENT = new AddressType(2, "CLIENT");

    /**
     * <p>Represents the company address type. It will never be null. It will be referenced in AddressManager.</p>
     *
     */
    public static final AddressType COMPANY = new AddressType(3, "COMPANY");

    /**
     * <p>Represents the user address type. It will never be null. It will be referenced in AddressManager.</p>
     *
     */
    public static final AddressType USER = new AddressType(4, "USER");

    /**
     * <p>Represents the id of the address type. This variable is set in constructor,&nbsp; is immutable and &gt;0.
     * It is referenced by the getId method.</p>
     *
     */
    private final long id;

    /**
     * <p>Represents the string representation of the type. This variable is set in constructor,&nbsp;
     * is immutable and non null, non empty. It is referenced by the toString method.</p>
     *
     */
    private final String type;

    /**
     * <p>Get the id</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return id</p>
     * <p></p>
     *
     * @param id >0 id of the type
     * @param type the non null non empty string representing the type
     */
    private AddressType(long id, String type) {
        this.id = id;
        this.type = type;
    }

    /**
     * <p>Get the id</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return id</p>
     * <p></p>
     *
     * @return >0 id of the type
     */
    public long getId() {
        return id;
    }

    /**
     * <p>Get the string representation of the type</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return type</p>
     *
     * @return the non null non empty string representing the type
     */
    public String toString() {
        return type;
    }
}