/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.contact;

import com.topcoder.util.collection.typesafeenum.Enum;

/**
 * This enumeration represents the contact type.
 * <p><strong>Implementation Notes:</strong></p>
 * <p>This enumeration will be used in ContactManager and implementations of ContactDAO.</p>
 * <p><strong>Thread Safety:</strong></p>
 * <p>This class is thread-safe by being immutable.</p>
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class ContactType extends Enum {

    /**
     * <p>Represents the project contact type. It will never be null. It will be referenced in ContactManager.</p>
     *
     */
    public static final ContactType PROJECT = new ContactType(1, "PROJECT");

    /**
     * <p>Represents the client contact type. It will never be null. It will be referenced in ContactManager.</p>
     *
     */
    public static final ContactType CLIENT = new ContactType(2, "CLIENT");

    /**
     * <p>Represents the company contact type. It will never be null. It will be referenced in ContactManager.</p>
     *
     */
    public static final ContactType COMPANY = new ContactType(3, "COMPANY");

    /**
     * <p>Represents the user contact type. It will never be null. It will be referenced in ContactManager.</p>
     *
     */
    public static final ContactType USER = new ContactType(4, "USER");

    /**
     * <p>Represents the id of the contact type. This variable is set in constructor,&nbsp; is immutable and &gt;0. It is referenced by the getId method.</p>
     *
     */
    private final long id;

    /**
     * <p>Represents the string representation of the type. This variable is set in constructor,&nbsp; is immutable and non null, non empty. It is referenced by the toString method.</p>
     *
     */
    private final String type;

    /**
     * <p>Private constructor of ContactType.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Empty constructor.</p>
     *
     * @param id >0 id of the type
     * @param type the non null non empty string representing the type
     */
    private ContactType(long id, String type) {
        this.id = id;
        this.type = type;
    }

    /**
     * <p>Get the id</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return id</p>
     * <p></p>
     *
     * @return >0 id of the type
     */
    public long getId() {
        return id;
    }

    /**
     * <p>Get the string representation of the type</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return type</p>
     *
     * @return the non null non empty string representing the type
     */
    public String toString() {
        return type;
    }
}
