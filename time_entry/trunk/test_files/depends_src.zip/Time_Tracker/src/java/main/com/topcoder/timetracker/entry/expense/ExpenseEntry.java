package com.topcoder.timetracker.entry.expense;

import java.util.Date;

import com.topcoder.timetracker.entry.base.BaseEntry;
import com.topcoder.timetracker.invoice.Invoice;

/**
 * <strong>Purpose:</strong>
 * <p>This class holds the information about an expense entry. In addition to common information, an expense entry also contains the date, amount of money, the type, the current status and a flag indicating whether the client should be billed. </p>
 * <p>Version 1.1 also adds a rejectReason list containing ExpenseEntryRejectReason objects. This list contains the reject reasons for the expense entry. The list has a range of accessor methods for consulting and changing it. </p>
 * <p><span style="color:Red">Note that&nbsp; version 3.1 has removed the reject* methods since now the BaseEntry from which ExpenseEntry is derived contains rejectReaons information.</span></p>
 * <p><strong>Implementation Details:</strong></p>
 * <p>When creating an instance of this class the user has two options: 1) Use the default constructor and allow the GUID Generator component to generate a unique id 2) Use the parameterized constructor and provide an id for the ExpenseEntry instance; if the id already is contained by another entry from the ExpenseEntries table, then the newly created entry will not be added to the ExpenseEntries table. Also the user should not populate the creationDate and modificationDate fields, because if he does, the entry will not be added to the database. This fields will be handled automatically by the component(the current date will be used). When loading from the persistence, all the fields will be properly populated. </p>
 * <p><strong>Thread-Safety: </strong></p>
 * <p>Because the class is mutable it is not thread safe. Threads will typically not share instances but if they do, the mutability should be used with care since any change done in one thread will affect the other thread, possibly without even being aware of the change.</p>
 *
 * @poseidon-object-id [I68168348m10468c6f140mm2d65]
 */
public class ExpenseEntry extends BaseEntry {
    /**
     * Represents the date for the entry. Initial value is null.
     * This field must be initialized by the user, using the setDate method. Valid values: non-null.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm2971]
     */
    private java.sql.Date date = null;

    /**
     * Represents the amount of money the employee spent.
     * Must be initialized by the user, using the setAmount method. Valid values: non-negative.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm295b]
     */
    private java.math.BigDecimal amount = null;

    /**
     * Represents the type of this entry. Initial value is null.
     * Must be initialized by the user using the setExpenseType method. Valid values: non-null.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm2945]
     */
    private com.topcoder.timetracker.entry.expense.ExpenseType expenseType = null;

    /**
     * Represents the status of this entry. Initial value is null.
     * Must be initialized by the user using the setStatus method. Valid values: non-null.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm25d9]
     */
    private com.topcoder.timetracker.entry.expense.ExpenseStatus status = null;

    /**
     * Represents a flag to indicate whether the entry is billable to client.
     * True means that the entry is billable, false means that is not.
     * If the billable field is true then the corresponding column in the ExpenseEntries table
     * \will be 1. If the billable field is false then the corresponding column in the ExpenseEntries table will be 0.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm25c3]
     */
    private boolean billable = false;

    /**
     * <p>Represents ...</p>
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1d13]
     */
    private int companyId = -1;

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>This variable represents the invoice for this ExpenseEntry.
     * It is set/initialized in the dedictaed setter and can also be accessed through a dedicated getter.</p>
     * <p>Can be null if the expense has not yet been invoiced.</p>
     * <p></p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm161]
     */
    private com.topcoder.timetracker.invoice.Invoice invoice;

    /**
     * Empty constructor.
     *
     * @poseidon-object-id [Im6b4d4c86m1047f4b370fmm2de7]
     */
    public ExpenseEntry() {
        // your code here
    }

    /**
     * Create a new instance. Simply initialize the id field.
     *
     * @poseidon-object-id [Im6b4d4c86m1047f4b370fmm2d8f]
     * @param id this value will be assigned to the id field
     */
    public ExpenseEntry(int id) {
        this.setId(id);
    }

    /**
     * Setter for the date field. If the argument is null, NullPointerException will be thrown.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm24bd]
     * @param date this value will be assigned to the date field
     * @throws NullpointerException - if the argument is null
     */
    public void setDate(java.sql.Date date) {
        this.date = date;
    }

    /**
     * Setter for the date field. If the argument is null, NullPointerException will be thrown.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm2478]
     * @param amount this value will be assigned to the amount field
     * @throws NullPointerException - if the argument is null
     * @throws IllegalArgumentException - if the argument is negative
     */
    public void setAmount(java.math.BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * Setter for the expenseType field. If the argument is null, NullPointerException will be thrown.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm2433]
     * @param expenseType this value will be assigned to the expenseType field
     * @throws NullPointerException - if the argument is null
     */
    public void setExpenseType(ExpenseType expenseType) {
        this.expenseType = expenseType;
    }

    /**
     * Setter for the status field. If the argument is null, NullPointerException will be thrown.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm23ee]
     * @param status this value will be assigned to the status field
     * @throws NullPointerException - if the argument is null
     */
    public void setStatus(ExpenseStatus status) {
        this.status = status;
    }

    /**
     * Setter for the billable field.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm23a9]
     * @param billable this value will be assigned to the billable field
     */
    public void setBillable(boolean billable) {
        this.billable = billable;
    }

    /**
     * Getter for the date field. Simply return the date.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm2208]
     * @return the date field
     */
    public Date getDate() {
        return this.date;
    }

    /**
     * Getter for the amount field. Simply return the amount field.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm21e4]
     * @return the amount field
     */
    public java.math.BigDecimal getAmount() {
        return this.amount;
    }

    /**
     * Getter for the expenseType field. Simply return the expenseType field.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm21c0]
     * @return the amount field
     */
    public ExpenseType getExpenseType() {
        return this.expenseType;
    }

    /**
     * Getter for the status field. Simply return the status field.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm219c]
     * @return the status field
     */
    public ExpenseStatus getStatus() {
        return this.status;
    }

    /**
     * This method simply returns the billable field. Using this method a user can find out if the entry is billable or not.
     *
     * @poseidon-object-id [I68168348m10468c6f140mm2178]
     * @return the billable field
     */
    public boolean isBillable() {
        return this.billable;
    }

    /**
     * get the company id
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1ce0]
     * @return the company id
     */
    public long getCompanyId() {
        return this.companyId;
    }

    /**
     * set company id to new value,
     *
     * @poseidon-object-id [Im7dc3d43am10b717e8277mm1c9b]
     * @param int companyId the new company id
     * @exception IllegalArgumentException if companyId is -1
     */
    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>Set the invoice for this expense entry. Can accept null, which would mean un-invoiced expense.</p>
     * <p></p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aamm140]
     * @param invoice invoice
     */
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    /**
     * <p><strong>Purpose:</strong></p>
     * <p>Return the current instance of Invoice associatied with this ExpenseEntry. Could possibly
     * return a null if the invoice is not set.</p>
     *
     * @poseidon-object-id [Im302568b8m110ec7791aammc6]
     * @return current invoice
     */
    public Invoice getInvoice() {
        return this.invoice;
    }
}
