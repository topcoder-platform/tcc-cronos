
package com.topcoder.timetracker.entry.fixedbilling;
import com.topcoder.search.builder.filter.Filter;
/**
 * <p>
 * This interface defines a factory that is capable of creating search filters used for searching through
 * FixedBillingStatuses.  It offers a convenient way of specifying search criteria to use.  The
 * factory is capable of producing filters that conform to a specific schema, and is associated with
 * the FixedBillingStatusManager that supports the given schema.
 * </p>
 * <p>
 * The filters that are produced by this factory should only be used by the FixedBillingStatusManager or
 * FixedBillingStatusDAO implementation that produced this FixedBillingStatusFilterFactory instance.
 * This ensures  that the Filters can be recognized by the utility.
 * </p>
 * <p>
 * It may be possible to create complex criterion by combining the filters produced by this
 * factory with any of the Composite Filters in the Search Builder Component (AndFilter, OrFilter,
 * etc.)
 * </p>
 * <p>
 * Thread Safety: This class is required to be thread-safe.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im5c841b97m110eadd46d0mm4e81]
 */
public interface FixedBillingStatusFilterFactory extends com.topcoder.timetracker.entry.fixedbilling.BaseFilterFactory {
/**
 * <p>
 * This creates a Filter that will select FixedBillingStatuses based on the Status'
 * description.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im5c841b97m110eadd46d0mm4e49]
 * @param description The description of the status.
 * @param matchType The String matchng that is desired on the search.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException if the String is null or an empty String or matchType is null.
 */
    public com.topcoder.search.builder.filter.Filter createDescriptionFilter(String description, String matchType);
}


