package com.topcoder.timetracker.entry.fixedbilling;

import com.topcoder.search.builder.filter.Filter;
import com.topcoder.util.collection.typesafeenum.Enum;

/**
 * <p>
 * This is an enum that is used by the FilterFactories for those methods when a String criterion is specified.
 * This gives the user a convenient way of specifying the method of matching the Strings.
 * </p>
 * <p>
 * Thread Safety: This class is an enum, and therefor thread-safe.
 * </p>
 *
 *
 * @poseidon-object-id [Im6b9f2725m111202efc02mm3558]
 */
public class StringMatchType extends Enum {
    /**
     * <p>
     * This specifies that the criterion should be based on whether it begins with the specified String.
     * </p>
     *
     *
     * @poseidon-object-id [Im6b9f2725m111202efc02mm354c]
     */
    public static final StringMatchType STARTS_WITH = new StringMatchType("SW:");

    /**
     * <p>
     * This specifies that the criterion should be based on whether it ends with the specified String.
     * </p>
     *
     *
     * @poseidon-object-id [Im6b9f2725m111202efc02mm3546]
     */
    public static final StringMatchType ENDS_WITH = new StringMatchType("EW:");

    /**
     * <p>
     * This specifies that the criterion should be based on whether it contains the specified String.
     * </p>
     *
     *
     * @poseidon-object-id [Im6b9f2725m111202efc02mm3540]
     */
    public static final StringMatchType SUBSTRING = new StringMatchType("SS:");

    /**
     * <p>
     * This specifies that the criterion should be based on whether it exactly matches the specified String.
     * </p>
     *
     *
     * @poseidon-object-id [Im6b9f2725m111202efc02mm353a]
     */
    public static final StringMatchType EXACT_MATCH = new StringMatchType("");

    /**
     * <p>
     * This is the filter prefix that the Filter Factory should provide to the LikeFilter that it produces in order to
     * achieve the desired functionality.
     * </p>
     * <p>
     * Initial Value: null
     * </p>
     * <p>
     * Accessed In: getFilterPrefix
     * </p>
     * <p>
     * Modified In: Not Modified
     * </p>
     * <p>
     * Utilized In: toString
     * </p>
     * <p>
     * Valid Values: Null (during initialization) or Not null and Not empty String objects (after setting)
     * </p>
     *
     *
     * @poseidon-object-id [Im6b9f2725m111202efc02mm3534]
     */
    private final String filterPrefix;

    /**
     * <p>
     * Private constructorthat produces a StringMatchType with given prefix.
     * </p>
     *
     * @poseidon-object-id [I47b25a01m1112a90a75amm2421]
     * @param filterPrefix The prefix that the Filter Factory should provide to the LikeFilter
     */
    private StringMatchType(String filterPrefix) {
        this.filterPrefix = filterPrefix;
    }

    /**
     * <p>
     * Retrievs the filter prefix of this match type.
     * </p>
     *
     *
     * @poseidon-object-id [Im6b9f2725m111202efc02mm352e]
     * @return the filter prefix of this match type.
     */
    public String getFilterPrefix() {
        return filterPrefix;
    }

    /**
     * <p>
     * Retrieves the String representation of this match type,
     * which is equivalent ot the filter prefix.
     * </p>
     *
     *
     * @poseidon-object-id [Im6b9f2725m111202efc02mm3527]
     * @return the filter prefix of this match type.
     */
    public String toString() {
        return filterPrefix;
    }
}
