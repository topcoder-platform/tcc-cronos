
package com.topcoder.timetracker.entry.fixedbilling;
import com.topcoder.search.builder.filter.Filter;
import com.topcoder.timetracker.contact.State;
/**
 * <p>
 * This interface defines a factory that is capable of creating search filters used for searching through
 * Time Tracker FixedBillingEntries.  It offers a convenient way of specifying search criteria to use.  The
 * factory is capable of producing filters that conform to a specific schema, and is associated with
 * the FixedBillingEntryManager that supports the given schema.
 * </p>
 * <p>
 * The filters that are produced by this factory should only be used by the FixedBillingEntryManager or 
 * FixedBillingEntryDAO implementation that produced this FixedBillingEntryFilterFactory instance.  
 * This ensures that the Filters can be recognized by the utility.
 * </p>
 * <p>
 * It may be possible to create complex criterion by combining the filters produced by this 
 * factory with any of the Composite Filters in the Search Builder Component (AndFilter, OrFilter,
 * etc.)
 * </p>
 * <p>
 * Note that all ranges specified are inclusive of the boundaries.  If a null is given at a range (or for int/long
 * ranges, a value of Integer.MIN_VALUE), it signifies that that particular bound (min or max) should be 
 * ignored.
 * </p>
 * <p>
 * Thread Safety: This class is required to be thread-safe.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7017]
 */
public interface FixedBillingEntryFilterFactory extends com.topcoder.timetracker.entry.fixedbilling.BaseFilterFactory {
/**
 * <p>
 * This creates a Filter that will select FixedBillingEntries based on the Entry's
 * invoice id.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6f29]
 * @param invoiceId The invoice id to use.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException if invoiceId is <= 0.
 */
    public com.topcoder.search.builder.filter.Filter createInvoiceIdFilter(long invoiceId);
/**
 * <p>
 * This creates a Filter that will select FixedBillingEntries based on the Entry's
 * description.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im7d8a053m110e2bb787emm2cbf]
 * @param description The description of the time entry.
 * @param matchType The String matchng that is desired on the search.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException if the String is null or an empty String or matchType is null.
 */
    public com.topcoder.search.builder.filter.Filter createDescriptionFilter(String description, com.topcoder.timetracker.entry.fixedbilling.StringMatchType matchType);
/**
 * <p>
 * This creates a Filter that will select FixedBillingEntries based on the Entry's
 * entry date.   A date range that may be open-ended can be specified.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6e38]
 * @param rangeStart The lower bound of the date criterion.  May be null to specify that this has no lower bound.
 * @param rangeEnd The upper bound of the date criterion.  May be null to specify that this has no upper bound.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException the range specified is invalid (eg. rangeStart > rangeEnd), or if both arguments are null.
 */
    public com.topcoder.search.builder.filter.Filter createEntryDateFilter(java.util.Date rangeStart, java.util.Date rangeEnd);
/**
 * <p>
 * This creates a Filter that will select FixedBillingEntries based on the Entry's
 * amount spent.
 * </p>
 * 
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6ece]
 * @param rangeStart The lower bound of the criterion.   May be Double.MIN_VALUE to indicate no lower bound.
 * @param rangeEnd The upper bound of the criterion.  May be Double.MIN_VALUE to indicate no upper bound.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException the range specified is invalid (eg. rangeStart > rangeEnd), or if both arguments are null.
 */
    public com.topcoder.search.builder.filter.Filter createAmountFilter(double rangeStart, double rangeEnd);
/**
 * <p>
 * This creates a Filter that will select FixedBillingEntries based on the Entry's
 * fixed billing status.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6d8a]
 * @param status The status of the entry.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException if the status is null.
 */
    public com.topcoder.search.builder.filter.Filter createFixedBillingStatusFilter(com.topcoder.timetracker.entry.fixedbilling.FixedBillingStatus status);
/**
 * <p>
 * This creates a Filter that will select FixedBillingEntries based on the Entry's
 * RejectReason.
 * </p>
 * 
 * 
 * @poseidon-object-id [Im73f44d97m110bc60be12mm7655]
 * @param rejectReasonId The reject reason to search for.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException if the rejectReasonId is <= 0.
 */
    public com.topcoder.search.builder.filter.Filter createRejectReasonFilter(long rejectReasonId);
/**
 * <p>
 * This creates a Filter that will select FixedBillingEntries based on the Entry's
 * companyId.
 * </p>
 * 
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6fdf]
 * @param companyId the id of the Time Tracker Company to search.
 * @return A filter that will be based off the specified criteria.
 * @throws IllegalArgumentException if the id <= 0.
 */
    public com.topcoder.search.builder.filter.Filter createCompanyIdFilter(long companyId);
}


