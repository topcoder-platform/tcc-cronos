package com.topcoder.timetracker.invoice;

/**
 *
 *
 * @poseidon-object-id [I22dbc7d7m11157306dd2mm290b]
 */
public class InvoiceStatus {
}
