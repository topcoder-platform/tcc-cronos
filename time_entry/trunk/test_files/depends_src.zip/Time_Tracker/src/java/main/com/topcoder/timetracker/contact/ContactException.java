/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.contact;

import com.topcoder.search.builder.filter.*;
import com.topcoder.util.errorhandling.BaseException;

/**
 * This exception will be the base exception for all exceptions thrown by the ContactManager/AddressManager. This exception can be used by the application to simply their exception processing by catching a single exception regardless of the actual subclass.
 * <p><strong>Implementation Notes:</strong></p>
 * <p>The developer should strongly suggest that all custom components inherit from this exception.</p>
 * <p><strong>Thread Safety:</strong></p>
 * <p>This exception is thread safe by being immutable.</p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class ContactException extends BaseException {
    /**
     * <p>Constructs the exception with given message.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message)</p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     */
    public ContactException(String message) {
        super(message);
    }

    /**
     * <p>Constructs the exception with given message and cause.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message, cause)</p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     * @param cause a possibly null cause exception
     */
    public ContactException(String message, Exception cause) {
        super(message, cause);
    }
}
