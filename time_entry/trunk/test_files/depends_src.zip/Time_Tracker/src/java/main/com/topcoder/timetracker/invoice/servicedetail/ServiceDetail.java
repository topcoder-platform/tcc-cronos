package com.topcoder.timetracker.invoice.servicedetail;

import com.topcoder.timetracker.common.TimeTrackerBean;

public class ServiceDetail extends TimeTrackerBean {

}
