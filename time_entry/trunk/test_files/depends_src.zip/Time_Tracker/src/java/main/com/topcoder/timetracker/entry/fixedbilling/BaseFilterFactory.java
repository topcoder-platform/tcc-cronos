package com.topcoder.timetracker.entry.fixedbilling;

import com.topcoder.search.builder.filter.Filter;

/**
 * <p>
 * This is a base FilterFactory interface that provides filter creation methods that may be used for filters
 * of any Time Tracker Bean.  It encapsulates filters for the common functionality - namely, the
 * creation and modification date and user.
 * </p>
 *
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6c6a]
 */
public interface BaseFilterFactory {
    /**
     * <p>
     * Creates a Filter based on the Creation Date of the entity.  A
     * date range that may be open-ended can be specified.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6c32]
     * @param rangeStart The lower bound of the date criterion.  May be null to specify that this has no lower bound.
     * @param rangeEnd The upper bound of the date criterion.  May be null to specify that this has no upper bound.
     * @return A filter that will be based off the specified criteria.
     * @throws IllegalArgumentException the range specified is invalid (eg. rangeStart > rangeEnd), or if both arguments are null.
     */
    public com.topcoder.search.builder.filter.Filter createCreationDateFilter(java.util.Date rangeStart,
        java.util.Date rangeEnd);

    /**
     * <p>
     * Creates a Filter based on the Modification Date of the entity.  A
     * date range that may be open-ended can be specified.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6c1a]
     * @param rangeStart The lower bound of the date criterion. May be null to specify that this has no lower bound.
     * @param rangeEnd The upper bound of the date criterion.  May be null to specify that this has no upper bound.
     * @return A filter that will be based off the specified criteria.
     * @throws IllegalArgumentException the range specified is invalid (eg. rangeStart > rangeEnd), or if both arguments are null.
     */
    public com.topcoder.search.builder.filter.Filter createModificationDateFilter(java.util.Date rangeStart,
        java.util.Date rangeEnd);

    /**
     * <p>
     * Creates a Filter based on the Creation User of the entity.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6c02]
     * @param username The username used for searching.
     * @param matchType The String matchng that is desired on the search.
     * @return A filter that will be based off the specified criteria.
     * @throws IllegalArgumentException if the String is null or an empty String or matchType is null.
     */
    public com.topcoder.search.builder.filter.Filter createCreationUserFilter(String username,
        com.topcoder.timetracker.entry.fixedbilling.StringMatchType matchType);

    /**
     * <p>
     * Creates a Filter based on the Modification User of the entity.
     * </p>
     *
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm6bea]
     * @param username The username used for searching.
     * @param matchType The String matchng that is desired on the search.
     * @return A filter that will be based off the specified criteria.
     * @throws IllegalArgumentException if the String is null or an empty String or matchType is null.
     */
    public com.topcoder.search.builder.filter.Filter createModificationUserFilter(String username,
        com.topcoder.timetracker.entry.fixedbilling.StringMatchType matchType);
}
