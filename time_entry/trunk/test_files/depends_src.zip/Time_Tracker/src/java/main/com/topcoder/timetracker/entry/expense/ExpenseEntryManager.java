package com.topcoder.timetracker.entry.expense;

import java.util.List;

import com.topcoder.timetracker.entry.expense.criteria.Criteria;
import com.topcoder.timetracker.entry.expense.persistence.PersistenceException;

/**
 * This interface defines the contract for the complete management of an expense entry. It provides single and batch
 * CRUD operations with the choice to perform audits on all writeable operations using the
 * Time Tracker Audit 3.1 component. Furthermore, all batch operations support selective operations,
 * so these calls can be either atomic or non-atomic. Atomic mode means that a failure on one entry causes
 * the entire operation to fail. Non-atomic means that a failure in one entry doesn't affect the other and the
 * user has a way to know which ones failed. It has one implementation in this design: ExpenseEntryManagerLocalDelegate.
 * <p><strong>Thread Safety</strong></p>
 * Implementations need not necessarily be thread safe. Each implementation should specify whether it is
 * thread-safe or not. The application should pick the correct implementation for it's requirements.
 *
 * @poseidon-object-id [Im231acf1m11159858c5am2f03]
 */
public interface ExpenseEntryManager {
    /**
     * Adds a new ExpenseEntry instance to the database. If the id of the entry is contained by the entries
     * table false will be returned. If the auditFlag is true then we should be auditing this action.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f0d]
     * @return true if the entry was added; false if an entry with the argument id already exists in the database
     * @param entry the entry that will be added to the database
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @throws IllegalArgumentException - if the argument is null, or if creationDate is not null and/or modificationDate is not null
     * @throws InsufficientDataException - If one of the fields except creationDate, modificationDate, or invoice are null
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public boolean addEntry(ExpenseEntry entry, boolean auditFlag) throws InsufficientDataException,
        PersistenceException;

    /**
     * Updates an entry in the database.
     * If the entry is updated true will be returned.
     * If an entry with the id of the argument entry does not exist in the database false will be returned.
     * If the auditFlag is true then we should be auditing this action.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f1b]
     * @return true if the entry was updated; false if an entry with the id of the argument type does not exist in the database
     * @param entry the entry to be updated
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @throws IllegalArgumentException - if the argument is null
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public boolean updateEntry(ExpenseEntry entry, boolean auditFlag) throws PersistenceException;

    /**
     * Deletes an entry from the database.
     * If an entry with the specified id does not exist in the database false will be returned.
     * If the entry is deleted true will be returned.
     * If the auditFlag is true then we should be auditing this action.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f28]
     * @return true if the entry is deleted; false if the entry does not exist in the database
     * @param entryId the id that identifies the entry
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public boolean deleteEntry(int entryId, boolean auditFlag) throws PersistenceException;

    /**
     * Retrieves the entry with the specified id from the database.
     * If an entry with the specified id exist in the database and is sucsessfully retrieved, then this method will create an
     * ExpenseEntry instance and this instance will be returned to the caller.
     * If an entry with the specified id does not exist in the database, null will be returned.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f33]
     * @return an ExpenseEntry instance or null if not found
     * @param entryId the id identifying the entry
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception),
     * or if the billable column is not 0 or 1
     */
    public ExpenseEntry retrieveEntry(int entryId) throws PersistenceException;

    /**
     * Deletes all entries from the database.
     * If the auditFlag is true then we should be auditing this action.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f3d]
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public void deleteAllEntries(boolean auditFlag) throws PersistenceException;

    /**
     * Retrieves all the entries from the database. If entries are sucessfully retrieved from the database,
     * then an ExpenseEntry array will be returned. The array will be empty if
     * there are no ExpenseEntries in the persistence.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f45]
     * @return an ExpenseEntry array containing all the entries, or empty if none are found
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public ExpenseEntry[] retrieveAllEntries() throws PersistenceException;

    /**
     * Performs a search for expense entries matching a given criteria. The criteria is abstracted using the Criteria interface.
     * The Criteria implementations cover the basic SQL filtering abilities (=, like, between, or, and, not). The result of the search
     * is an array with the matched expense entries. It is empty if no matches found (but it can't be null or contain nulls).
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f4e]
     * @return the results of the search (can be empty if no matches found)
     * @param criteria the criteria to be used in the search
     * @throws IllegalArgumentException if the argument is null
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public ExpenseEntry[] searchEntries(Criteria criteria) throws PersistenceException;

    /**
     * Adds atomically set of entries to the database.
     * If the auditFlag is true then we should be auditing this action.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f5a]
     * @param entries the entries to add
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @throws IllegalArgumentException if the array is null, empty or has nulls, or if creationDate is not
     * null and/or modificationDate is not null
     * @throws InsufficientDataException - If one of the fields except creationDate and modificationDate, are null
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public void addEntries(ExpenseEntry[] entries, boolean auditFlag) throws InsufficientDataException,
        PersistenceException;

    /**
     * <p>Adds a set of entries to the database.</p>
     *
     * <p>If the addition is atomic then it means that entire addition will fail if a single expense entry addition fails.</p>
     *
     * <p>If the addition is non-atomic then it means each expense entry is added individually. If it fails, that won't affect the others.
     * A list with the failed entries is returned to the user (empty if no error occurs).</p>
     *
     * <p>If the auditFlag is true then we should be auditing this action.</p>
     *
     * <p>Implementations are free to not implement this and throw UnsupportedOperationException</p>
     *
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f68]
     * @return the entries that failed to be added in non atomic mode (null in atomic mode)
     * @param entries the entries to add
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @param isAtomic whether the operation should be atomic or not
     * @throws IllegalArgumentException if the array is null, empty or has nulls, or if creationDate is not null and/or modificationDate is not null (in atomic mode only)
     * @throws InsufficientDataException - If one of the fields except creationDate and modificationDate, are null  (in atomic mode only)
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception) (in atomic mode only)
     */
    public ExpenseEntry[] addEntries(ExpenseEntry[] entries, boolean auditFlag, boolean isAtomic)
        throws InsufficientDataException, PersistenceException;

    /**
     * Updates atomically a set of entries in the database.
     * If the auditFlag is true then we should be auditing this action.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f77]
     * @param entries the ids of the entries to update
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @throws IllegalArgumentException if the array is null, empty or has nulls
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public void updateEntries(ExpenseEntry[] entries, boolean auditFlag) throws PersistenceException;

    /**
     * <p>Updates a set of entries in the database.</p>
     *
     * <p>If the update is atomic then it means that entire update will fail if a single expense entry update fails.</p>
     *
     * <p>If the update is non-atomic then it means each expense entry is updated individually. If it fails, that won't affect the others.
     * A list with the failed entries is returned to the user (empty if no error occurs).</p>
     *
     * <p>If the auditFlag is true then we should be auditing this action.</p>
     *
     * <p>Implementations are free to not implement this and throw UnsupportedOperationException</p>
     *
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f84]
     * @return the entries that failed to be updated in non atomic mode (null in atomic mode)
     * @param entries the ids of the entries to update
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @param isAtomic whether the operation should be atomic or not
     * @throws IllegalArgumentException if the array is null, empty or has nulls
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public ExpenseEntry[] updateEntries(ExpenseEntry[] entries, boolean auditFlag, boolean isAtomic)
        throws PersistenceException;

    /**
     * Deletes atomically a set of entries from the database.
     * If the auditFlag is true then we should be auditing this action.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f92]
     * @param entryIds the ids of the entries to delete
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @throws IllegalArgumentException if the array is null or empty
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public void deleteEntries(int[] entryIds, boolean auditFlag) throws PersistenceException;

    /**
     * <p>Deletes a set of entries from the database.</p>
     *
     * <p>If the deletion is atomic then it means that entire retrieval will fail if a single expense entry deletion fails.</p>
     *
     * <p>If the deletion is non-atomic then it means each expense entry is deleted individually. If it fails, that won't affect the others.
     * A list with the failed ids is returned to the user (empty if no error occurs).</p>
     *
     * <p>If the auditFlag is true then we should be auditing this action.</p>
     *
     * <p>Implementations are free to not implement this and throw UnsupportedOperationException</p>
     *
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2f9f]
     * @return the entries that failed to be deleted in non atomic mode (null in atomic mode)
     * @param entryIds the ids of the entries to delete
     * @param auditFlag audit flag which specifies if the user want to audit the action
     * @param isAtomic whether the operation should be atomic or not
     * @throws IllegalArgumentException if the array is null or empty
     * @throws PersistenceException wraps a persistence implementation specific exception (such as SQL exception)
     */
    public int[] deleteEntries(int[] entryIds, boolean auditFlag, boolean isAtomic) throws PersistenceException;

    /**
     * Retrieves atomically a set of entries with given ids from the database.
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2fac]
     * @return the entries that were retrieved in both modes, or empty if none found
     * @param entryIds the ids of the entries to retrieve. Will be empty if no results are available
     * @throws IllegalArgumentException if the array is null or empty
     * @throws PersistenceException wraps a persistence implementation specific exception
     * (such as SQL exception) or if the billable column of an entry is not 0 or 1
     */
    public ExpenseEntry[] retrieveEntries(int[] entryIds) throws PersistenceException;

    /**
     * <p>Retrieves a set of entries with given ids from the database.</p>
     * <p>If the retrieval is atomic then it means that entire retrieval will fail if a single expense entry retrieval fails.</p>
     * <p>If the retrieval is non-atomic then it means each expense entry is retrieved individually.</p>
     * <p>If it fails that won't affect the others. The potentially partial ExpenseEntry array of results will be returned.</p>
     * <p>If any error occurs it will be ignored, and the operation would continue to retrieve further entries.</p>
     * <p>Implementations are free to not implement this and throw UnsupportedOperationException</p>
     *
     * @poseidon-object-id [Im231acf1m11159858c5am2fb8]
     * @return the entries that were retrieved in either mode, or empty if none found
     * @param entryIds the ids of the entries to retrieve
     * @param isAtomic whether the operation should be atomic or not
     * @throws IllegalArgumentException if the array is null or empty
     * @throws PersistenceException wraps a persistence implementation specific exception
     * (such as SQL exception) or if the billable column of an entry is not 0 or 1 (in atomic mode only)
     */
    public ExpenseEntry[] retrieveEntries(int[] entryIds, boolean isAtomic) throws PersistenceException;
}
