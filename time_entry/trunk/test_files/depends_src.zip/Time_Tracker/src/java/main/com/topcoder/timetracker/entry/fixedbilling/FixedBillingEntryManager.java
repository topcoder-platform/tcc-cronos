package com.topcoder.timetracker.entry.fixedbilling;

import com.topcoder.search.builder.filter.Filter;
import com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry;

/**
 * <p>This interface represents the API that may be used in order to manipulate the various details involving a Time Tracker Fixed Billing Entry. CRUDE and search methods are provided to manage the Entries inside a persistent store. There are also methods for the manipulation of RejectReasons associated with the FixedBillingEntry.</p>
 * <p>It is also possible to search the persistent store for entries based on different search criteria.</p>
 * <p>Thread safety: Thread safety is required for implementations of this interface.</p>
 *
 * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7c4b]
 */
public interface FixedBillingEntryManager {
    /**
     * <p>
     * Defines a fixed billing entry to be recognized within the persistent store managed by this utility.
     * A unique fixed billing entry id will automatically be generated and assigned to the entry.
     * There is also the option to perform an audit.
     * </p>
     * <p>
     * The implementation will set the Entry's creation and modification date to the current
     * date.   These creation/modification details will also reflect in the persistent store.
     * The creation and modification user is the responsibility of the calling application.
     * </p>
     * <p>
     * The entity should be provided with no id set (id = 0).  Otherwise, the implementation should
     * throw IllegalArgumentException.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7c13]
     * @param entry The entry for which the operation should be performed.
     * @param audit Indicates whether an audit should be performed.
     * @throws IllegalArgumentException if entry is null, or has an invalid entry provided.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public void createFixedBillingEntry(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry entry,
        boolean audit) throws DataAccessException;

    /**
     * <p>
     * Modifies the persistent store so that it now reflects the data in the provided FixedBillingEntry parameter.
     * There is also the option to perform an audit.
     * </p>
     * <p>
     * The implementation will set the Entry's modification details to the current
     * date.   These modification details will also reflect in the persistent store.
     * The modification user is the responsibility of the calling application.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7bfb]
     * @param entry The entry for which the operation should be performed.
     * @param audit Indicates whether an audit should be performed.
     * @throws IllegalArgumentException if entry is null.
     * @throws UnrecognizedEntityException if a entry with the provided id was not found in the data store.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public void updateFixedBillingEntry(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry entry,
        boolean audit) throws DataAccessException;

    /**
     * <p>
     * Modifies the persistent store so that it  no longer contains data on the fixed billing
     * entry with the specified id.
     * </p>
     * <p>
     * There is also the option to perform an audit.
     * The creation and modification user is the responsibility of the calling application.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm78e4]
     * @param entryId The entryId for which the operation should be performed.
     * @param audit Indicates whether an audit should be performed.
     * @throws UnrecognizedEntityException if a entry with the provided id was not found in the data store.
     * @throws IllegalArgumentException if entryId <= 0.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public void deleteFixedBillingEntry(long entryId, boolean audit) throws DataAccessException;

    /**
     * <p>
     * Retrieves a FixedBillingEntry object that reflects the data in the persistent store
     * with the specified entryId.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7be3]
     * @param entrytId The id of the entry to retrieve.
     * @return The entry with specified id.
     * @throws UnrecognizedEntityException if a entry with the provided id was not found in the data store.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry getFixedBillingEntry(long entrytId)
        throws DataAccessException;

    /**
     * <p>
     * Searches the persistent store for any fixed billing entries  that satisfy the criteria that was specified in the
     * provided search filter.  The provided filter should be created using either the filters that are
     * created using the FixedBillingEntryFilterFactory returned by getFixedBillingEntryFilterFactory of this instance, or
     * a composite Search Filters (such as AndFilter, OrFilter and NotFilter from Search Builder component)
     * that combines the filters created using FixedBillingEntryFilterFactory.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7bcb]
     * @param filter The filter used to search for entries.
     * @return The entries satisfying the conditions in the search filter.
     * @throws IllegalArgumentException if filter is null.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     * @throws InvalidFilterException if the filter cannot be recognized.
     */
    public com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry[] searchFixedBillingEntries(
        com.topcoder.search.builder.filter.Filter filter) throws DataAccessException;

    /**
     * <p>
     * This is a batch version of the createFixedBillingEntry method.
     * </p>
     * <p>
     * The creation and modification user is the responsibility of the calling application.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7bb3]
     * @param entries An array of entries for which the operation should be performed.
     * @param audit Indicates whether an audit should be performed.
     * @throws IllegalArgumentException if entries is null or contains null values.
     * @throws BatchOperationException if a problem occurs while processing the batch.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public void createFixedBillingEntries(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry[] entries,
        boolean audit) throws DataAccessException;

    /**
     * <p>
     * This is a batch version of the updateFixedBillingEntry method.
     * </p>
     * <p>
     * The modification user is the responsibility of the calling application.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7659]
     * @param entries An array of entries for which the operation should be performed.
     * @param audit Indicates whether an audit should be performed.
     * @throws IllegalArgumentException if entries is null or contains null values.
     * @throws BatchOperationException if a problem occurs while processing the batch.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public void updateFixedBillingEntries(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry[] entries,
        boolean audit) throws DataAccessException;

    /**
     * <p>
     * This is a batch version of the deleteFixedBillingEntry method.
     * </p>
     * <p>
     * The creation and modification user is the responsibility of the calling application.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7614]
     * @param entryIds An array of entryIds for which the operation should be performed.
     * @param audit Indicates whether an audit should be performed.
     * @throws BatchOperationException if a problem occurs while processing the batch.
     * @throws IllegalArgumentException if entryIds is null or contains values <= 0.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public void deleteFixedBillingEntries(long[] entryIds, boolean audit) throws DataAccessException;

    /**
     * <p>
     * This is a batch version of the getFixedBillingEntry method.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm75ce]
     * @param entryIds An array of entryIds for which entries should be retrieved.
     * @return The entries corresponding to the provided ids.
     * @throws BatchOperationException if a problem occurs while processing the batch.
     * @throws UnrecognizedEntityException if an entry  with the provided id was not found in the data store.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry[] getFixedBillingEntries(long[] entryIds)
        throws DataAccessException;

    /**
     * <p>
     * This adds RejectReason with the specified id
     * to the specified entry.
     * </p>
     * <p>
     * There is also the option to perform an audit.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7573]
     * @param entry The entry for which the operation should be performed.
     * @param rejectReasonId The id of rejectReason to add to the Entry.
     * @param audit Indicates whether an audit should be performed.
     * @throws IllegalArgumentException if any parameter is null.
     * @throws UnrecognizedEntityException if a rejectReason or entry was not found with specified id.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     * @throws InvalidCompanyException if the companyId of the entry and RejectReason do not match.
     */
    public void addRejectReasonToEntry(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry entry,
        long rejectReasonId, boolean audit) throws DataAccessException;

    /**
     * <p>
     * This removes a RejectReason with the specified id
     * from the specified entry.
     * </p>
     * <p>
     * There is also the option to perform an audit.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7470]
     * @param entry The entry for which the operation should be performed.
     * @param rejectReasonsId The rejectReason to remove.
     * @param audit Indicates whether an audit should be performed.
     * @throws UnrecognizedEntityException if a rejectReason or entry was not found with specified id.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     * @throws IllegalArgumentException if either argument is null.
     */
    public void removeRejectReasonFromEntry(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry entry,
        long rejectReasonsId, boolean audit) throws DataAccessException;

    /**
     * <p>
     * This removes all RejectReasons from the specified entry.
     * </p>
     * <p>
     * There is also the option to perform an audit.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7458]
     * @param entry The entry for which the operation should be performed.
     * @param audit Indicates whether an audit should be performed.
     * @throws IllegalArgumentException if the entry is null.
     * @throws UnrecognizedEntityException if the given entry was not found in the data store.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public void removeAllRejectReasonsFromEntry(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry entry,
        boolean audit) throws DataAccessException;

    /**
     * <p>
     * This retrieves all RejectReasons for the specified entry.
     * </p>
     * <p>
     * There is also the option to perform an audit.  If an audit is specified, then the audit
     * must be rolled back in the case that the operation fails.
     * </p>
     *
     * @poseidon-object-id [Im4cccfaa2m110bbe8e4bcmm7440]
     * @param entry The entry to retrieve RejectReasons from.
     * @return An array of RejectReason ids for the given entry.
     * @throws IllegalArgumentException if the entry is null.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     * @throws UnrecognizedEntityException if a entry was not found in the data store.
     */
    public long[] getAllRejectReasonsForEntry(com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry entry)
        throws DataAccessException;

    /**
     * <p>
     * Retrieves all the FixedBillingEntries that are currently in the persistent
     * store.
     * </p>
     *
     * @poseidon-object-id [Im73f44d97m110bc60be12mm6f9b]
     * @return An array of fixed billing entries retrieved from the persistent store.
     * @throws DataAccessException if a problem occurs while accessing the persistent store.
     */
    public com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntry[] getAllFixedBillingEntries()
        throws DataAccessException;

    /**
     * <p>
     * Retrieves the FixedBillingEntryFilterFactory that is capable of creating SearchFilters to use when searching
     * for FixedBillingEntries.  This is used to conveniently specify the search criteria that should be used.  The
     * filters returned by the given factory should be used with this instance's searchFixedBillingEntries method.
     * </p>
     *
     * @poseidon-object-id [Im7d8a053m110e2bb787emm2dfd]
     * @return the FixedBillingEntryFilterFactory that is capable of creating SearchFilters to use when searching for fixed billing entries.
     */
    public com.topcoder.timetracker.entry.fixedbilling.FixedBillingEntryFilterFactory getFixedBillingEntryFilterFactory();
}
