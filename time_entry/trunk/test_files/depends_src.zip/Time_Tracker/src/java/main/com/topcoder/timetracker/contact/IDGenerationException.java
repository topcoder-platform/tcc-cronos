/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */

package com.topcoder.timetracker.contact;

import com.topcoder.search.builder.filter.*;

/**
 * <p>This exception will be thrown by the Contact/AddressManager classes, EJB entities, and Contact/AddressDAO classes when ID can't be generated successfully. This exception will be exposed to the caller of addContact/Address method.</p>
 * <p></p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class IDGenerationException extends ContactException {

    /**
     * <p>Constructs the exception with given message.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message)</p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     */
    public IDGenerationException(String message) {
        super(message);
    }

    /**
     * <p>Constructs the exception with given message and cause.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message, cause)</p>
     * <p></p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     * @param cause a possibly null cause exception
     */
    public IDGenerationException(String message, Exception cause) {
        super(message, cause);
    }
}
