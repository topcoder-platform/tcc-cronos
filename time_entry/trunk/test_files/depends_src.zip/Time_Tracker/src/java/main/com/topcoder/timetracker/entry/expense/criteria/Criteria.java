package com.topcoder.timetracker.entry.expense.criteria;

/**
 * This interface abstracts a criteria used for searching expense entries. The criterias are database oriented, approach chosen for speed by being able to filter expense entries at the SQL query level, thus avoiding the need to bring all expense entries into memory. The criteria implementations are used to build the where clause of an SQL query on the expense entry table. To do that, the actual clause expression (string) is needed. Since the clause may have user given parameters the interface has a method to return that too. The parameters are NOT inserted into the expression directly for portability reasons (different database implementations may represent data types in different ways). PreparedStatements are used instead.
 *
 * @poseidon-object-id [I15205a4m109934b9275m3881]
 * @author TCSDESIGNER
 */
public interface Criteria extends java.io.Serializable {
    /**
     * Returns the where clause expression that can be used in an SQL query to perform the filtering represented in the Criteria implementation. The expression is expected to contain ? characters where the Criteria parameters should be inserted. This is needed because PreparedStatements are typically used by the database implementations to execute the query.
     *
     * @poseidon-object-id [I15205a4m109934b9275m3944]
     * @return the where clause expression
     */
    public String getWhereClause();

    /**
     * Returns the parameter values that should be used with the where clause expression returned by the getWhereClause method. The parameter values should be inserted in place of the ? characters in the where clause expression (typically using PreparedStatements, not manually).
     *
     * @poseidon-object-id [I15205a4m109934b9275m394b]
     * @return the parameters used in the expression
     */
    public Object[] getParameters();
}
