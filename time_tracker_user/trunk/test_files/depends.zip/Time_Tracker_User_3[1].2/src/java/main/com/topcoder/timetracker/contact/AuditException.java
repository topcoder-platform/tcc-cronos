/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.timetracker.contact;

/**
 * <p>This exception will be thrown by the Contact/AddressManager classes, EJB entities, and Contact/AddressDAO classes if they encounter any exception when try to audit. This exception will be exposed to the caller of addContact/Address(s), updateContact/Address(s) and removeContact/Address(s) methods.</p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class AuditException extends ContactException {

    /**
     * <p>Constructs the exception with given message.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message)</p>
     * <p></p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     */
    public AuditException(String message) {
        super(message);
    }

    /**
     * <p>Constructs the exception with given message and cause.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Simply call super(message, cause)</p>
     * <p></p>
     *
     * @param message a possible null, possible empty(trim'd) error message
     * @param cause a possibly null cause exception
     */
    public AuditException(String message, Exception cause) {
        super(message, cause);
    }
}
