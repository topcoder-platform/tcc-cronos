package com.topcoder.timetracker.contact;

import com.topcoder.timetracker.common.TimeTrackerBean;
import com.topcoder.search.builder.filter.*;

/**
 * This class holds the information of a contact.
 * <p><strong>Implementation Notes:</strong></p>
 * <p>This class will be created by the application directly and created by the implementaions of ContactDAO. The application can get/set all the properties of it.</p>
 * <p><strong>Thread Safety:</strong></p>
 * <p>This class is not thread safe by being mutable. This class is not supposed to be used in multithread environment. If it would be used in multithread environment, it should be synchronized externally.</p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class Contact extends TimeTrackerBean {

    /**
     * <p>Represents the first name of this Contact. This variable is set to null initially,&nbsp; is mutable. It is only allowed to be set to non null, non empty string by the setter. It is access by its getter and setter methods.</p>
     *
     */
    private String firstName = null;

    /**
     * <p>Represents the last name of this Contact. This variable is set to null initially,&nbsp; is mutable. It is only allowed to be set to non null, non empty string by the setter. It is access by its getter and setter methods.</p>
     *
     */
    private String lastName = null;

    /**
     * <p>Represents the phone number of this Contact. This variable is set to null initially,&nbsp; is mutable. It is only allowed to be set to non null, non empty string by the setter. It is access by its getter and setter methods.</p>
     *
     */
    private String phoneNumber = null;

    /**
     * <p>Represents the email address of this Contact. This variable is set to null initially,&nbsp; is mutable. It is only allowed to be set to non null, non empty string by the setter. It is access by its getter and setter methods.</p>
     *
     */
    private String emailAddress = null;

    /**
     * <p>Represents the type of this Contact. This variable is set to null initially,&nbsp; is mutable. It is only allowed to be set to non null ContactType. It is access by its getter and setter methods.</p>
     *
     */
    private ContactType contactType = null;

    /**
     * <p>Constructs the Contact.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Empty constructor.</p>
     *
     */
    public Contact() {
        // your code here
    }

    /**
     * <p>Get the first name.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return firstName</p>
     * <p></p>
     *
     * @return the possible null, non empty first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * <p>Set the first name</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save firstName to the like named variable</p>
     * <p></p>
     *
     * @param firstName the non null, non empty first name
     * @throws IllegalArgumentException if the firstName is null or empty(trim'd)
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * <p>Get the last name</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return lastName</p>
     *
     * @return the possible null, non empty first name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * <p>Set the last name</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save lastName to the like named variable</p>
     *
     * @param lastName the non null, non empty last name
     * @throws IllegalArgumentException if the name is null or empty(trim'd)
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * <p>Get the phone number</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return phoneNumber</p>
     *
     * @return the non null, non empty phone number
     */
    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    /**
     * <p>Set the phone number</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save phoneNumber to the like named variable</p>
     * <p></p>
     *
     * @param phoneNumber the non null, non empty phone number
     * @throws IllegalArgumentException if the phone number is null or empty(trim'd)
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * <p>Get the email address</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return emailAddress</p>
     *
     * @return the possible null, non empty email address
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * <p>Set the email address</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save emailAddress to the like named&nbsp; variable</p>
     *
     * @param emailAddress the non null, non empty email address
     * @throws IllegalArgumentException if the email address is null or empty(trim'd)
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * <p>Get the type</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return type</p>
     * <p></p>
     *
     * @return the possible null type
     */
    public ContactType getContactType() {
        return this.contactType;
    }

    /**
     * <p>Set the type</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save type to the like named&nbsp; variable</p>
     * <p></p>
     *
     * @param contactType the non null type
     * @throws IllegalArgumentException if the type is null
     */
    public void setContactType(ContactType contactType) {
        this.contactType = contactType;
    }
}
