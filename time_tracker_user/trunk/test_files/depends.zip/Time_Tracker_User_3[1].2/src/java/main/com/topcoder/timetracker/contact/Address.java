package com.topcoder.timetracker.contact;

import com.topcoder.timetracker.common.TimeTrackerBean;

/**
 * This class holds the information of an address
 * <p><strong>Implementation Notes:</strong></p>
 * <p>This class will be created by the application directly and created by the
 * implementaions of AddressDAO. The application can get/set all the properties of it.</p>
 * <p><strong>Thread Safety:</strong></p>
 * <p>This class is not thread safe by being mutable. This class is not supposed to be used in
 * multithread environment. If it would be used in multithread environment,
 * it should be synchronized externally.</p>
 *
 *
 * @author kinzz, TCSDEVELOPER
 * @version 1.0
 */
public class Address extends TimeTrackerBean {

    /**
     * <p>Represents the first line of the address. This variable is set to null initially,
     * is mutable. It is only allowed to be set to non null, non empty string by the setter.
     * It is access by its getter and setter methods.</p>
     *
     */
    private String line1 = null;

    /**
     * <p>Represents the second line of the address. This variable is set to null initially,
     * is mutable. It is only allowed to be set to non null, non empty string by the setter.
     * It is access by its getter and setter methods.</p>
     *
     */
    private String line2 = null;

    /**
     * <p>Represents the city of the address. This variable is set to null initially,
     * is mutable. It is only allowed to be set to non null, non empty string by the setter.
     * It is access by its getter and setter methods.</p>
     *
     */
    private String city = null;

    /**
     * <p>Represents the postal code of the address. This variable is set to null initially,
     * is mutable. It is only allowed to be set to non null, non empty string by the setter.
     * It is access by its getter and setter methods.</p>
     *
     */
    private String postalCode = null;

    /**
     * <p>Represents the country of the address. This variable is set to null initially,
     * is mutable. It is only allowed to be set to non null country by the setter.
     * It is access by its getter and setter methods.</p>
     *
     */
    private Country country = null;

    /**
     * <p>Represents the state of the address. This variable is set to null initially,
     * is mutable. It is only allowed to be set to non null state by the setter.
     * It is access by its getter and setter methods.</p>
     *
     */
    private State state = null;

    /**
     * <p>Represents the type of the address. This variable is set to null initially,
     * is mutable. It is only allowed to be set to non null type by the setter.
     * It is access by its getter and setter methods.</p>
     *
     */
    private AddressType addressType = null;

    /**
     * <p>Constructs the Address.</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Empty constructor.</p>
     * <p></p>
     *
     */
    public Address() {
        // your code here
    }

    /**
     * <p>Get the first line</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return line1</p>
     * <p></p>
     *
     * @return possible null, non empty string representing line1
     */
    public String getLine1() {
        return line1;
    }

    /**
     * <p>Set the first line</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variable</p>
     *
     * @param line1 non null, non empty string representing line1
     * @throws IllegalArgumentException if the line1 is null or empty(trim'd)
     */
    public void setLine1(String line1) {
        this.line1 = line1;
    }

    /**
     * <p>Get the second line</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return line2</p>
     * <p></p>
     *
     * @return possible null, non empty string representing line2
     */
    public String getLine2() {
        return line2;
    }

    /**
     * <p>Set the second line</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variable</p>
     * <p></p>
     *
     * @param line2 non null, non empty string representing line2
     * @throws IllegalArgumentException if the line2 is null or empty(trim'd)
     */
    public void setLine2(String line2) {
        this.line2 = line2;
    }

    /**
     * <p>Get the city</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return city</p>
     * <p></p>
     *
     * @return possible null, non empty string representing city
     */
    public String getCitry() {
        return city;
    }

    /**
     * <p>Set the city</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variable</p>
     * <p></p>
     *
     * @param city non null, non empty string representing city
     * @throws IllegalArgumentException if the city is null or empty(trim'd)
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * <p>Get the postal code</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return postalCode</p>
     * <p></p>
     *
     * @return possible null, non empty string representing postal code
     */
    public String getPostalCode() {
        return this.postalCode;
    }

    /**
     * <p>Set the postal code</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variabl</p>
     * <p></p>
     *
     * @param postalCode non null, non empty string representing postal code
     * @throws IllegalArgumentException if the postalCode is null or empty(trim'd)
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * <p>Get the country</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return country</p>
     * <p></p>
     *
     * @return possible null country
     */
    public Country getCountry() {
        return this.country;
    }

    /**
     * <p>Set the country</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variabl</p>
     * <p></p>
     *
     * @param country non null country
     * @throws IllegalArgumentException if the country is null
     */
    public void setCountry(Country country) {
        this.country = country;
    }

    /**
     * <p>Set the state</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Save the argument to like named variabl</p>
     * <p></p>
     *
     * @return possible null state
     */
    public State getState() {
        return state;
    }

    /**
     * <p>Set the state</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variabl</p>
     * <p></p>
     *
     * @param state non null state
     * @throws IllegalArgumentException if the state is null
     */
    public void setState(State state) {
        this.state = state;
    }

    /**
     * <p>Get the address type</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Return addressType</p>
     * <p></p>
     *
     * @return possible null address type
     */
    public AddressType getAddressType() {
        return addressType;
    }

    /**
     * <p>Set the address type</p>
     * <p><strong>Implementation Notes:</strong></p>
     * <p>Call setChanged(true) and save the argument to like named variabl</p>
     * <p></p>
     *
     * @param addressType non null address type
     * @throws IllegalArgumentException if the type is null
     */
    public void setAddressType(AddressType addressType) {
        this.addressType = addressType;
    }
}
