/*
 * Copyright (C) 2007 TopCoder Inc., All Rights Reserved.
 */
package com.topcoder.timetracker.audit;

import com.topcoder.util.errorhandling.BaseException;

/**
 * An exception thrown by the manager whenever there are any problems in any of its methods throw during their
 * delegation to the persistence layer. Two standard constructors are provided, both which take a message
 * detailing why the exception was thrown, and one taking also the exception which caused it, for example
 * which may be an AuditPersistenceException.
 *
 *
 * @author sql_lall, TCSDEVELOPER
 * @version 1.0
 */
public class AuditManagerException extends BaseException {
    /**
     * Message-only constructor, taking the reason why the exception has been thrown.
     *
     * @param message Readable description telling why the exception was thrown.
     */
    public AuditManagerException(String message) {
        super(message);
    }

    /**
     * Constructor taking two arguments - the reason why the exception has been thrown, and the initial cause that triggered it.
     *
     * @param message Readable description telling why the exception was thrown.
     * @param cause Throwable cause that was caught and triggered this exception to be thrown.
     */
    public AuditManagerException(String message, Throwable cause) {
        super(message, cause);
    }
}
