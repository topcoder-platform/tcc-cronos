ALTER TABLE submission
        ADD feedback_text LVARCHAR(1000);

ALTER TABLE submission
        ADD feedback_thumb DECIMAL(3,0);  