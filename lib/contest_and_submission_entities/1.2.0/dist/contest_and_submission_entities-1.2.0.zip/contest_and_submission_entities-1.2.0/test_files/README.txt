1. Run the following scripts to setup the informix database.
schema_create.sql
create_seq.sql
init.sql

2. Change database configuration according to your testing environment, refer to hibernate.cfg.xml file.

3. run 'ant test' to execute the test case.

