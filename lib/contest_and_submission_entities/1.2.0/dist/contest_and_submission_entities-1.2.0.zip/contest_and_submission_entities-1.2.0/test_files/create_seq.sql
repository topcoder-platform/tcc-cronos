create sequence STUDIO_PATH_SEQ;
create sequence STUDIO_DOCUMENT_SEQ;
create sequence STUDIO_CONTEST_SEQ;
create sequence STUDIO_PRIZE_SEQ;
create sequence STUDIO_SUBMISSION_SEQ;
create sequence CONTEST_PAYMENT_SEQ;
create sequence STUDIO_CONTEST_DETAILED_STATUS_SEQ;
create sequence CONTEST_GENERAL_INFO_SEQ;
create sequence CONTEST_MULTI_ROUND_INFORMATION_SEQ;
create sequence CONTEST_RESOURCE_SEQ;
create sequence CONTEST_SPECIFICATIONS_SEQ;
create sequence CONTEST_MILESTONE_PRIZE_SEQ;
create sequence PERMISSION_TYPE_SEQ;
create sequence PERMISSION_SEQ;


CREATE SEQUENCE sq_mime_type_lu;
CREATE SEQUENCE sq_file_type_lu;
CREATE SEQUENCE sq_contest_channel_lu;
CREATE SEQUENCE sq_contest_status_icon;
CREATE SEQUENCE sq_contest_status_lu;
CREATE SEQUENCE sq_contest_type_lu;
CREATE SEQUENCE sq_path;
CREATE SEQUENCE sq_document_type_lu;
CREATE SEQUENCE sq_document;
CREATE SEQUENCE sq_submission_type_lu;
CREATE SEQUENCE sq_payment_status_lu;
CREATE SEQUENCE sq_prize_type_lu;
CREATE SEQUENCE sq_review_status_lu;
CREATE SEQUENCE sq_submission_status_lu;
CREATE SEQUENCE sq_contest;
CREATE SEQUENCE sq_prize;
CREATE SEQUENCE sq_submission;
CREATE SEQUENCE sq_contest_property_lu;
CREATE SEQUENCE sq_contest_config;
CREATE SEQUENCE sq_contest_type_config;

