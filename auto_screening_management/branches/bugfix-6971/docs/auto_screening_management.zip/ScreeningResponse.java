package com.cronos.onlinereview.autoscreening.management;

import java.io.Serializable;

public class ScreeningResponse implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setResponseSeverity(ResponseSeverity responseSeverity) {
	}
	public ResponseSeverity getResponseSeverity() {
		return null;
	}
	public void setResponseCode(String responseCode) {
	}
	public String getResponseCode() {
		return null;
	}
	public void setResponseText(String responseText) {
	}
	public String getResponseText() {
		return null;
	}
}
