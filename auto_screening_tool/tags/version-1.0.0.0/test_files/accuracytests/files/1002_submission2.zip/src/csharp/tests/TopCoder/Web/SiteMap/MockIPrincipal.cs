using System;
using System.Security.Principal;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Defines a Mock class of <c>IPrincipal</c>.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class MockIPrincipal : IPrincipal
    {

        /// <summary>
        /// The identity of the current MockIPrincipal.
        /// </summary>
        private MockIIdentity identity;

        /// <summary>
        /// The getter of the identity member.
        /// </summary>
        /// <value>
        /// The identity of the current MockIPrincipal.
        /// </value>
        public IIdentity Identity
        {
            get
            {
                return identity;
            }
        }

        /// <summary>
        /// An ignored method.
        /// </summary>
        /// <param name="role">The role to used(ignored)</param>
        /// <returns>False</returns>
        public bool IsInRole(string role)
        {
            return false;
        }

        /// <summary>
        /// Create a new <c>MockIPrincipal</c> with given name.
        /// </summary>
        /// <param name="name">The name of MockIPrincipal.</param>
        public MockIPrincipal(string name)
        {
            this.identity = new MockIIdentity(name);
        }
    }
}