namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// <p>
    /// This interface defines a contract for retrieving a site map object model from persistence. It
    /// defines a single method to be implemented. The details of reading from persistence are
    /// implementation specific. Construction of the model is trivial. The demo section of the specs
    /// demonstrates this.
    /// </p>
    /// <p>
    /// This component provides an implementation of this interface that restores the site map model
    /// from XML file.
    /// </p>
    /// </summary>
    /// <remarks>
    /// Thread safety:Implementations of this interface are expected to be thread safe. The
    /// implementation of this interface, provided by this component, is thread safe.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public interface ISiteMapReader
    {
        /// <summary>
        /// <p>
        /// Simply the method declaration for the interface.
        /// </p>
        /// <p>
        /// Implementors will restore the site map object model from a persistence.
        /// </p>
        /// </summary>
        /// <returns>
        /// The SiteMap object model constructed from persistence.
        /// </returns>
        /// <exception cref="SiteMapReadException">
        /// This exception to signal any problems while reading the site map from persistence.
        /// </exception>
        SiteMap Read();
    }
}