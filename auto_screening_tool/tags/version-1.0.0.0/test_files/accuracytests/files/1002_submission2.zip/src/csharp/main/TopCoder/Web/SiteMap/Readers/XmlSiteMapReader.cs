using System;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Schema;

namespace TopCoder.Web.SiteMap.Readers
{

    /// <summary>
    /// <p>
    /// This class implements the ISiteMapReader interface to provide the site map from an XML file.
    /// </p>
    /// <p>
    /// The XML file is separated in two areas. One that specifies the node details of the site and
    /// one that provides the hierarchy, the parent child relations, among these nodes. This separation
    /// and structuring of the nodes is done so that the multiple parents relation is easier to describe
    /// in the XML file.
    /// </p>
    /// <p>
    /// A different option would have been to nest child nodes under parent nodes. However, the main
    /// disadvantage of this method is that entire site map trees should be duplicated for nodes with
    /// multiple parents, which could easily become unmanageable even for small size site maps.
    /// </p>
    /// <p>
    /// The structure used by this design is to simply depict for every node its children which allows
    /// for multiple parents to be easily managed.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class XmlSiteMapReader : ISiteMapReader
    {
        /// <summary>
        /// Represents the const attribute name in the xml file.
        /// </summary>
        private const string NAME_ATTRIBUTE_NAME = "name";

        /// <summary>
        /// Represents the const attribute name in the xml file.
        /// </summary>
        private const string DESCRIPTION_ATTRIBUTE_NAME = "description";

        /// <summary>
        /// Represents the const attribute name in the xml file.
        /// </summary>
        private const string URL_ATTRIBUTE_NAME = "url";

        /// <summary>
        /// Represents the const attribute name in the xml file.
        /// </summary>
        private const string ROOT_ATTRIBUTE_NAME = "root";

        /// <summary>
        /// <p>
        /// The file path of the site map xml file. Set in the constructor can not be null or empty string.
        /// Not changed afterwards.
        /// </p>
        /// </summary>
        private readonly string xmlFilePath;

        /// <summary>
        /// <p>
        /// The file path of the site map XSD validation file. Set in the constructor can not be null or
        /// empty string. Not changed afterwards.
        /// </p>
        /// </summary>
        private readonly string xsdFilePath;

        /// <summary>
        /// Create a new <c>XmlSiteMapReader</c> instance with given xmlFilePath and xsdFilePath.
        /// </summary>
        /// <param name="xmlFilePath">The file path of the site map xml file.</param>
        /// <param name="xsdFilePath">Validation schema for the xml file.</param>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        /// <exception cref="ArgumentException">
        /// If the either parameter is empty string or either file path does not exist.</exception>
        public XmlSiteMapReader(string xmlFilePath, string xsdFilePath)
        {
            // check parameters
            SiteMapHelper.ValidateNotNullOrEmpty(xmlFilePath, "xmlFilePath");
            SiteMapHelper.ValidateNotNullOrEmpty(xsdFilePath, "xsdFilePath");

            // check the files.
            if (!File.Exists(xmlFilePath))
            {
                throw new ArgumentException("The file : " + xmlFilePath + "does not exist.");
            }

            if (!File.Exists(xsdFilePath))
            {
                throw new ArgumentException("The file : " + xsdFilePath + "does not exist.");
            }

            this.xmlFilePath = xmlFilePath;
            this.xsdFilePath = xsdFilePath;
        }

        /// <summary>
        /// <p>
        /// This method reads the XML file and builds the site map object model.
        /// </p>
        /// <p>
        /// Creates a new XsdXmlFileValidator for the special XSD validation schema and checks if
        /// the special XML file is valid according to the schema. An SiteMapReadException should
        /// be thrown if the file is not valid.
        /// </p>
        /// <p>
        /// Creates an XMLDocument and loads the XML from file.
        /// </p>
        /// <p>
        /// Note that in the XML file each node must have a unique name.
        /// </p>
        /// </summary>
        /// <returns>The SiteMap object model constructed from persistence.</returns>
        /// <exception cref="SiteMapReadException">
        /// If any problems while reading the site map from the xml file.
        /// </exception>
        public SiteMap Read()
        {

            XmlValidatingReader reader = null;

            try
            {
                reader = new XmlValidatingReader(new XmlTextReader(xmlFilePath));

                // set the XmlValidatingReader to use Schema validation
                reader.ValidationType = ValidationType.Schema;

                reader.Schemas.Add(GetSchema(xsdFilePath));

                // attach the HtmlValidationEventHandler method as a subscriber to the ValidationEvent
                reader.ValidationEventHandler += new ValidationEventHandler(ValidationHandler);

                XmlDocument mapFile = new XmlDocument();

                mapFile.Load(reader);

                // the int storing the first index of the child nodes.
                int firstIndex = 0;

                // the int storing the second index of the child nodes.
                int secondIndex = 1;

                // get the base node of the data.
                XmlNode baseNode = mapFile.ChildNodes[secondIndex];

                // get the required root name.
                string rootName = baseNode.Attributes[ROOT_ATTRIBUTE_NAME].InnerText;

                // get the nodeDefinitions node.
                XmlNode nodeDefinitionsNode = baseNode.ChildNodes[firstIndex];

                // get the hierarchy node
                XmlNode hierarchyNode = baseNode.ChildNodes[secondIndex];

                IDictionary nodes = new Hashtable();

                // retrieve the defined nodes
                for (int i = 0; i < nodeDefinitionsNode.ChildNodes.Count; i++)
                {
                    // get the arguments for creating the new SiteMapNode instance.
                    string name = nodeDefinitionsNode.ChildNodes[i].Attributes[NAME_ATTRIBUTE_NAME].InnerText;

                    string description
                        = nodeDefinitionsNode.ChildNodes[i].Attributes[DESCRIPTION_ATTRIBUTE_NAME].InnerText;

                    string url = nodeDefinitionsNode.ChildNodes[i].Attributes[URL_ATTRIBUTE_NAME].InnerText;

                    nodes.Add(name, new SiteMapNode(name, description, url));
                }

                // process the relations of the defined nodes.
                for (int i = 0; i < hierarchyNode.ChildNodes.Count; i++)
                {
                    string parentName = hierarchyNode.ChildNodes[i].Attributes[NAME_ATTRIBUTE_NAME].InnerText;

                    XmlNode parentNode = hierarchyNode.ChildNodes[i];

                    for (int j = 0; j < parentNode.ChildNodes.Count; j++)
                    {
                        string childName = parentNode.ChildNodes[j].Attributes[NAME_ATTRIBUTE_NAME].InnerText;

                        new Relation(nodes[parentName] as SiteMapNode, nodes[childName] as SiteMapNode);
                    }
                }

                // return the SiteMap.
                return new SiteMap(nodes[rootName] as SiteMapNode);
            }
            catch(Exception e)
            {
                throw new SiteMapReadException(
                    "error while reading the site map from the xml file", e);
            }
            finally
            {
                if (reader != null)
                {
                    // the resource should be disposed.
                    reader.Close();
                }
            }
        }

        /// <summary>
        /// Method used as delegate for <see cref="XmlValidatingReader.ValidationEventHandler"/>.
        /// </summary>
        /// <param name="sender">The XmlValidatingReader that sent the notification
        /// </param>
        /// <param name="args">The validation args informing how the document does not meet the XSD
        /// </param>
        /// <exception cref="SiteMapReadException">If the format of the given Xml file is invalid.</exception>
        private void ValidationHandler(object sender, ValidationEventArgs args)
        {
            throw new SiteMapReadException("The format of the given Xml file is invalid.");
        }

        /// <summary>
        /// Gets the schema from given path of XSD file.
        /// </summary>
        /// <param name="xsdPath">The XSD path from which to obtain the schema.</param>
        /// <returns>The obtained schema</returns>
        private XmlSchema GetSchema(string xsdPath)
        {
            using (TextReader reader = new StreamReader(xsdPath))
            {
                XmlSchema schema = XmlSchema.Read(reader, new ValidationEventHandler(ValidationHandler));
                schema.Compile(new ValidationEventHandler(ValidationHandler));
                return schema;
            }
        }
    }
}