using System;
using System.Runtime.Serialization;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// <p>
    /// This exception is used to signal problems while reading from the configuration file and to
    /// signal problems while creating the objects to use with the Object Factory component.
    /// This exception is thrown by both AbstractSiteMapDataSource and NodeAuthorization classes.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [Serializable]
    public class SiteMapConfigurationException : SiteMapException
    {
        /// <summary>
        /// Creates a new instance of <c>SiteMapConfigurationException</c> class.
        /// </summary>
        public SiteMapConfigurationException()
        {
        }

        /// <summary>
        /// Creates a new instance of <c>SiteMapConfigurationException</c> class. The detailed error message is
        /// given.
        /// <p>
        /// The string argument is not checked - it may be null or empty.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        public SiteMapConfigurationException(string message) : base(message)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>SiteMapConfigurationException</c> class. The detailed error message and
        /// the original innerException of this error are given.
        /// <p>
        /// Both arguments are not checked.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        /// <param name="innerException">The original innerException of this error.</param>
        public SiteMapConfigurationException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>SiteMapConfigurationException</c> class with deserialization.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source and destination.</param>
        protected SiteMapConfigurationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}