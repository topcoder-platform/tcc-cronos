using System;
using NUnit.Framework;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Tests the functionality and error cases of the <c>SiteMap</c> class. Since this class is immutable,
    /// the property is tested with constructor.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class SiteMapTestCase
    {
        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string NAME = "name";

        /// <summary>
        /// <p>The description of the site map node.</p>
        /// </summary>
        private const string DESCRIPTION = "description";

        /// <summary>
        /// <p>The url of the site map node.</p>
        /// </summary>
        private const string URL = "/";

        /// <summary>
        /// <p>
        /// The root site map node.
        /// </p>
        /// </summary>
        private SiteMapNode root;

        /// <summary>
        /// Represents the SiteMap instance used in the test.
        /// </summary>
        private SiteMap siteMap;

        /// <summary>
        /// Sets up the test environment. The test instance is created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            root = new SiteMapNode(NAME, DESCRIPTION, URL);

            siteMap = new SiteMap(root);
        }

        /// <summary>
        /// Cleans up the test environment. The test instance is disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            siteMap = null;
        }

        /// <summary>
        /// Test the <c>SiteMap(SiteMapNode)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapSiteMapNodeNull()
        {
            new SiteMap(null);
        }


        /// <summary>
        /// Accuracy test of the <c>SiteMap(SiteMapNode)</c>. The instance is created. This case test
        /// RootNode property as well.
        /// </summary>
        [Test]
        public void TestSiteMapSiteMapNodeAccuracy()
        {
            siteMap = new SiteMap(root);

            // Verify.
            Assert.IsNotNull(siteMap, "The SiteMap instance should be created.");

            Assert.AreEqual(siteMap.RootNode, root,
                "The RootNode property should be the same as set in argument.");
        }

        /// <summary>
        /// Test the <c>SelectSingleNode(string)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSelectSingleNodeStringNull()
        {
            siteMap.SelectSingleNode(null);
        }

        /// <summary>
        /// Test the <c>SelectSingleNode(string)</c> with empty string argument. Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSelectSingleNodeStringEmpty()
        {
            siteMap.SelectSingleNode("   ");
        }

        /// <summary>
        /// Accuracy test of the <c>SelectSingleNode(string)</c>. The node of the given name is returned if it
        /// exists in the siteMap.
        /// </summary>
        [Test]
        public void TestSelectSingleNodeStringAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 10;

            // a variable storing the base child name.
            string childBaseName = "child";

            SiteMapNode[] firstChildren = new SiteMapNode[count];

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                firstChildren[i] = new SiteMapNode(childBaseName + i, DESCRIPTION, URL);

                // add the first child nodes to the siteMap.
                root.AddChild(firstChildren[i]);

                SiteMapNode[] secondChildren = new SiteMapNode[count];

                for (int j = 0; j < count; j++)
                {
                    secondChildren[j] = new SiteMapNode(childBaseName + i + j, DESCRIPTION, URL);

                    // add the second child nodes to the siteMap.
                    firstChildren[i].AddChild(secondChildren[j]);
                }
            }

            // Verify.
            for (int i = 0; i < count; i++)
            {
                string firstChildrenName = childBaseName + i;

                SiteMapNode firstChildrenNode = siteMap.SelectSingleNode(firstChildrenName);

                // check the first children nodes.
                Assert.IsNotNull(firstChildrenNode,
                    "The given name should exist in the node of the SiteMap.");

                for (int j = 0; j < count; j++)
                {
                    string secondChildrenName = childBaseName + i + j;

                    SiteMapNode secondChildrenNode = siteMap.SelectSingleNode(secondChildrenName);

                    // check the second children nodes.
                    Assert.IsNotNull(secondChildrenNode,
                        "The given name should exist in the node of the SiteMap.");
                }
            }

            // Verify.
            for (int i = 0; i < count; i++)
            {
                string childrenName = childBaseName + i + i + i;

                SiteMapNode childrenNode = siteMap.SelectSingleNode(childrenName);

                // check the children nodes.
                Assert.IsNull(childrenNode, "The given name should not exist in the node of the SiteMap.");
            }
        }



        /// <summary>
        /// Test the <c>SelectNodes(string)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSelectNodesStringNull()
        {
            siteMap.SelectNodes(null);
        }

        /// <summary>
        /// Test the <c>SelectNodes(string)</c> with empty string argument. Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSelectNodesStringEmpty()
        {
            siteMap.SelectSingleNode("   ");
        }

        /// <summary>
        /// Accuracy test of the <c>SelectNodes(string)</c>. The nodes with the given name are returned.
        /// </summary>
        [Test]
        public void TestSelectNodesStringAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 10;

            // a variable storing the base child name.
            string childBaseName = "child";

            SiteMapNode[] firstChildren = new SiteMapNode[count];

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                firstChildren[i] = new SiteMapNode(childBaseName + i, DESCRIPTION, URL);

                // add the first child nodes to the siteMap.
                root.AddChild(firstChildren[i]);

                SiteMapNode secondChildren = new SiteMapNode(childBaseName, DESCRIPTION, URL);

                // add the second child node to the siteMap.
                firstChildren[i].AddChild(secondChildren);
            }

            // Verify.
            for (int i = 0; i < count; i++)
            {
                // check the first children nodes(single node found).
                string firstChildrenName = childBaseName + i;

                SiteMapNode[] firstChildrenNodes = siteMap.SelectNodes(firstChildrenName);

                Assert.IsTrue(firstChildrenNodes.Length > 0,
                    "The given name should exist in the node of the SiteMap.");

                Assert.AreEqual(firstChildrenNodes.Length, 1,
                    "The count of the nodes of the given name should be 1");
            }

            // check the second children nodes(more than one node found).
            string secondChildrenName = childBaseName;

            SiteMapNode[] secondChildrenNodes = siteMap.SelectNodes(secondChildrenName);

            // check the second children nodes.
            Assert.IsNotNull(secondChildrenNodes,
                "The given name should exist in the node of the SiteMap.");

            Assert.AreEqual(secondChildrenNodes.Length, count,
                "The count of the nodes of the given name should be" + count + ".");

            // Verify.
            for (int i = 0; i < count; i++)
            {
                string childrenName = childBaseName + i + i + i;

                SiteMapNode[] childrenNodes = siteMap.SelectNodes(childrenName);

                // check the children nodes.
                Assert.IsTrue(childrenNodes.Length == 0,
                    "The given name should not exist in the node of the SiteMap.");
            }
        }
    }
}