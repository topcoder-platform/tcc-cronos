using System;
using System.Security.Principal;

namespace TopCoder.Web.SiteMap.Authorization.Entities
{
    /// <summary>
    /// <p>
    /// This class implements the IAuthorizaitonEntity interface to provide the authorization entity
    /// for a web request principal.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class PrincipalAuthorizationEntity : IAuthorizationEntity
    {
        /// <summary>
        /// <p>
        /// Represents the principal to return identity name from.
        /// </p>
        /// </summary>
        private readonly IPrincipal principal;

        /// <summary>
        /// Represents a const string as action name.
        /// </summary>
        private const string ACTION_NAME = "view node";

        /// <summary>
        /// <p>Returns the principal identity name.</p>
        /// </summary>
        /// <value>
        /// The name of the principal identity.
        /// </value>
        public string PrincipalName
        {
            get
            {
                return principal.Identity.Name;
            }
        }

        /// <summary>
        /// <p>
        /// Get the action name of this class.
        /// </p>
        /// </summary>
        /// <value>
        /// The action name string.
        /// </value>
        public string ActionName
        {
            get
            {
                return ACTION_NAME;
            }
        }

        /// <summary>
        /// <p>
        /// Create a new <c>PrincipalAuthorizationEntity</c> instance with given IPrincipal.
        /// </p>
        /// </summary>
        /// <param name="principal">The principal object retrieved from the request context.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        public PrincipalAuthorizationEntity(IPrincipal principal)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(principal, "principal");

            this.principal = principal;
        }
    }
}