using System;
using NUnit.Framework;
using TopCoder.Util.ConfigurationManager;
using TopCoder.Web.SiteMap.Authorization;
using TopCoder.Web.SiteMap.Readers;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Tests the functionality and error cases of the <c>SiteMapDataSource</c> class. Since this class
    /// is immutable, the properties are tested with constructor.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class SiteMapDataSourceTestCase
    {
        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string NAME = "name";

        /// <summary>
        /// <p>The description of the site map node.</p>
        /// </summary>
        private const string DESCRIPTION = "description";

        /// <summary>
        /// <p>The url of the site map node.</p>
        /// </summary>
        private const string URL = "/";

        /// <summary>
        /// Represents a ConfigManager instance used in the test.
        /// </summary>
        private ConfigManager manager = ConfigManager.GetInstance();

        /// <summary>
        /// Represents a valid nameSpace in the configuration file.
        /// </summary>
        private const string VALID_NAME_SPACE = "TopCoder.Web.SiteMap";

        /// <summary>
        /// Represents the file name template of the namespace used to create instance.
        /// </summary>
        private const string FILE_NAME_TEMP = "../../test_files/SiteMapDataSource/{0}.xml";

        /// <summary>
        /// Represents a valid file name to create instance.
        /// </summary>
        private const string VALID_FILE = "SiteMapDataSource";

        /// <summary>
        /// Represents a missing object_factory_namespace property configuration file name.
        /// </summary>
        private const string MISSING_OBJECT_FACTORY_NAMESPACE = "Missing_object_factory_namespace";

        /// <summary>
        /// Represents an empty object_factory_namespace property configuration file name.
        /// </summary>
        private const string EMPTY_OBJECT_FACTORY_NAMESPACE = "Empty_object_factory_namespace";

        /// <summary>
        /// Represents a missing site_map_reader_key property configuration file name.
        /// </summary>
        private const string MISSING_SITE_MAP_READER_KEY = "Missing_site_map_reader_key";

        /// <summary>
        /// Represents an empty site_map_reader_key property configuration file name.
        /// </summary>
        private const string EMPTY_SITE_MAP_READER_KEY = "Empty_site_map_reader_key";

        /// <summary>
        /// Represents a missing node_authorization_key property configuration file name.
        /// </summary>
        private const string MISSING_NODE_AUTHORIZATION_KEY = "Missing_node_authorization_key";

        /// <summary>
        /// Represents an empty node_authorization_key property configuration file name.
        /// </summary>
        private const string EMPTY_NODE_AUTHORIZATION_KEY = "Empty_node_authorization_key";

        /// <summary>
        /// Represents a valid xml file path used in the test.
        /// </summary>
        private const string VALID_XML_FILE_PATH = "../../test_files/Readers/SiteMap.xml";

        /// <summary>
        /// Represents a valid xsd file path used in the test.
        /// </summary>
        private const string VALID_XSD_FILE_PATH = "../../test_files/Readers/SiteMap.xsd";

        /// <summary>
        /// Represents a <c>SiteMapDataSource</c> instance used in the test.
        /// </summary>
        private MockSiteMapDataSource source;

        /// <summary>
        /// Represents the INodeAuthorization instance used as argument in the test.
        /// </summary>
        private INodeAuthorization nodeAuthorization;

        /// <summary>
        /// Represents the ISiteMapReader instance used as argument in the test.
        /// </summary>
        private ISiteMapReader reader;

        /// <summary>
        /// Sets up the test environment. The test instances are created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            nodeAuthorization = new NodeAuthorization();

            reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            source = new MockSiteMapDataSource();
        }

        /// <summary>
        /// Cleans up the test environment. The test instances are disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            // clear the configuration manager.
            manager.Clear();

            nodeAuthorization = null;

            reader = null;

            source = null;
        }

        /// <summary>
        /// Accuracy test of the <c>Namespace</c>. The const value is returned.
        /// </summary>
        [Test]
        public void TestConstMember()
        {
            string ret = SiteMapDataSource.Namespace;

            // Verify.
            Assert.IsNotNull(ret, "The Namespace of the SiteMapDataSource should be null.");
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource()</c> when the optional property is missing.
        /// The SiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MockSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource()</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MockSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new MockSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new MockSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new MockSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new MockSiteMapDataSource();
        }

        /// <summary>
        /// Accuracy test of the <c>SiteMapDataSource()</c>. The SiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceAccuracy()
        {
            source = new MockSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.SiteMap, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.NodeAuthorization, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>SiteMapDataSource(String)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapDataSourceStringNull()
        {
            new MockSiteMapDataSource(null as string);
        }

        /// <summary>
        /// Test the <c>SiteMapDataSource(String)</c> with empty string argument. Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSiteMapDataSourceStringEmpty()
        {
            new MockSiteMapDataSource("   ");
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(String)</c> when the optional property is missing.
        /// The SiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceStringMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MockSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(String)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceStringEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MockSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceStringMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new MockSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceStringEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new MockSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceStringMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new MockSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceStringEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new MockSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Accuracy test of the <c>SiteMapDataSource(String)</c>. The SiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceStringAccuracy()
        {
            source = new MockSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.SiteMap, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.NodeAuthorization, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>SiteMapDataSource(INodeAuthorization)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapDataSourceINodeAuthorizationNull()
        {
            new MockSiteMapDataSource(null as INodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(INodeAuthorization)</c> when the optional property is missing.
        /// The SiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceINodeAuthorizationMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MockSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(INodeAuthorization)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceINodeAuthorizationEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MockSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(INodeAuthorization)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceINodeAuthorizationMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new MockSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(INodeAuthorization)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceINodeAuthorizationEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new MockSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Accuracy test of the <c>SiteMapDataSource(INodeAuthorization)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceINodeAuthorizationAccuracy()
        {
            source = new MockSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.SiteMap, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.NodeAuthorization, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>SiteMapDataSource(ISiteMapReader)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapDataSourceISiteMapReaderNull()
        {
            new MockSiteMapDataSource(null as ISiteMapReader);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(ISiteMapReader)</c> when the optional property is missing.
        /// The SiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceISiteMapReaderMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MockSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(ISiteMapReader)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceISiteMapReaderEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MockSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(ISiteMapReader)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceISiteMapReaderMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new MockSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>SiteMapDataSource(ISiteMapReader)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestSiteMapDataSourceISiteMapReaderEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new MockSiteMapDataSource(reader);
        }

        /// <summary>
        /// Accuracy test of the <c>SiteMapDataSource(ISiteMapReader)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceISiteMapReaderAccuracy()
        {
            source = new MockSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.SiteMap, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.NodeAuthorization, "The SiteMapDataSource instance should be created.");

        }

        /// <summary>
        /// Test the <c>SiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapDataSourceISiteMapReaderINodeAuthorizationNullA()
        {
            new MockSiteMapDataSource(null, reader);
        }

        /// <summary>
        /// Test the <c>SiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapDataSourceISiteMapReaderINodeAuthorizationNullB()
        {
            new MockSiteMapDataSource(nodeAuthorization, null);
        }

        /// <summary>
        /// Accuracy test of the <c>SiteMapDataSource(INodeAuthorization, ISiteMapReader)</c>. The instance
        /// is created.
        /// </summary>
        [Test]
        public void TestSiteMapDataSourceISiteMapReaderINodeAuthorizationAccuracy()
        {
            source = new MockSiteMapDataSource(nodeAuthorization, reader);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.SiteMap, "The SiteMapDataSource instance should be created.");

            Assert.IsNotNull(source.NodeAuthorization, "The SiteMapDataSource instance should be created.");
        }
    }
}