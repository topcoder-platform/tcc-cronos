using System;

namespace TopCoder.Web.SiteMap.Authorization
{
    /// <summary>
    /// This class implements INodeAuthorization to disable authorization if plugged into
    /// AbstracSiteMapDatasource. This class will simply authorize all requests.
    /// <p>
    /// AbstracSiteMapDatasource works in the same way and will use this class as if it is
    /// authorizing requests unaware that authorization is not done.
    /// </p>
    /// <p>
    /// This class is useful when a data source is required to be configured and used through
    /// the configuration file but without authorization since credentials can only be retrieved
    /// later.
    /// </p>
    /// </summary>
    /// <remarks>
    /// Thread safety:This class has no state and is thread safe.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class DisabledNodeAuthorization : INodeAuthorization
    {

        /// <summary>
        /// <p>
        /// Create a new <c>DisabledNodeAuthorization</c> instance.
        /// </p>
        /// </summary>
        public DisabledNodeAuthorization()
        {
        }

        /// <summary>
        /// <p>
        /// This method simply returns true.
        /// </p>
        /// <p>
        /// AbstractSiteMapDataSource will work in the same way whether or not it actually authorizes
        /// access to the nodes.
        /// </p>
        /// </summary>
        /// <param name="node">The node to check if the specified entity is authorized.</param>
        /// <returns>True</returns>
        /// <exception cref="ArgumentNullException">If the given node is null.</exception>
        public bool IsAccessible(SiteMapNode node)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(node, "node");

            return true;
        }
    }
}