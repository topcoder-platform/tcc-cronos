using System;
using System.Collections;
using NUnit.Framework;
using TopCoder.Web.SiteMap.Readers;
using TopCoder.Web.SiteMap.Authorization;
using TopCoder.Web.SiteMap.Authorization.Entities;
using TopCoder.Util.ConfigurationManager;
using TopCoder.Security.Authorization;
using TopCoder.Security.Authorization.Persistence;
using TopCoder.Security.Authorization.Policy;
using TopCoder.Web.UI.WebControl.Menu;
using TopCoder.Web.UI.WebControl.Menu.Source;
using TopCoder.Web.UI.WebControl.BreadCrumb.PathDiscovery;
using TopCoder.Web.UserControl.TreeView;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Tests the demo of this component, represents the main usages of this component. In the current
    /// dome, there are three demonstrations that show how this component is used.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class Demo
    {
        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string NAME = "main";

        /// <summary>
        /// <p>The description of the site map node.</p>
        /// </summary>
        private const string DESCRIPTION = "description";

        /// <summary>
        /// <p>The url of the site map node.</p>
        /// </summary>
        private const string URL = "/";

        /// <summary>
        /// Represents a ConfigManager instance used in the test.
        /// </summary>
        private ConfigManager manager = ConfigManager.GetInstance();

        /// <summary>
        /// Represents the file name used in the demo..
        /// </summary>
        private const string FILE_NAME
            = "../../test_files/Authorization/NodeAuthorization/NodeAuthorization.xml";


        /// <summary>
        /// Represents a valid xml file path used in the test.
        /// </summary>
        private const string VALID_XML_FILE_PATH = "../../test_files/Readers/SiteMap.xml";

        /// <summary>
        /// Represents a valid xsd file path used in the test.
        /// </summary>
        private const string VALID_XSD_FILE_PATH = "../../test_files/Readers/SiteMap.xsd";

        /// <summary>
        /// Represents the file name template of the namespace used to create instance.
        /// </summary>
        private const string FILE_NAME_TEMP = "../../test_files/SiteMapDataSource/{0}.xml";

        /// <summary>
        /// Represents a valid file name to create instance.
        /// </summary>
        private const string VALID_FILE = "SiteMapDataSource";

        /// <summary>
        /// Sets up the test environment. The config manger is initialized.Set up the dynamic roles
        /// using the facilities provided by this component.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(FILE_NAME);
        }

        /// <summary>
        /// Cleans up the test environment. The config manager is cleared..
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            // clear the configuration manager.
            manager.Clear();
        }

        /// <summary>
        /// Represents the SiteMapManagement usage of this component.The site map nodes and the relations
        /// among them can be managed and build programmatically. Below is an example that builds the site
        /// map as configured in the example XML file.
        /// </summary>
        [Test]
        public void SiteMapManagement()
        {
            //create the main site map node
            SiteMapNode main = new SiteMapNode("main", "main page", "/");

            //change node display name
            main.Name = "home page";

            //change node description
            main.Description = "the site home page";

            //change the URL
            main.Url = "/en/home.aspx";

            //create the services site map node
            SiteMapNode services = new SiteMapNode("services", "services page", "/services.aspx");

            //create the products site map node
            SiteMapNode products = new SiteMapNode("products", "products page", "/products.aspx");


            //create the product 1 site map node
            SiteMapNode product1 = new SiteMapNode("product1", "product 1 page", "products/product1.aspx");

            //create the product 2 site map node
            SiteMapNode product2 = new SiteMapNode("product2", "product 2 page", "products/product2.aspx");

            //create the help site map node
            SiteMapNode help = new SiteMapNode("help", "help page", "/help.aspx");

            //now we need to define the parent C child relations

            //main node is parent to services and products
            main.AddChild(services);

            main.AddChild(products);


            //we can also set a relation in a different way, but we could use this may here, since the
            // relations have  be defined.

//            new Relation (main, services);
//            new Relation (main, products);


            //add the two product nodes to the products node
            products.AddChild(product1);
            products.AddChild(product2);


            //and the help node
            products.AddChild(help);

            //we can specify a relation from child to parent node
            //set the services node as parent to help
            help.AddParent(services);

            //create a site map and set the root node
            SiteMap site = new SiteMap(main);

            //get the child nodes of a site map node
            SiteMapNode[] children = main.Children;

            //enumerate node children
            for (int index = 0; index < children.Length; index++)
            {
                Console.WriteLine(children[index].Name);
            }

            //get the parent nodes of a node
            SiteMapNode[] parents = help.Parents;

            //enumerate node parents
            for (int index = 0; index < parents.Length; index++)
            {
                Console.WriteLine(parents[index].Name);
            }

            //remove a child or parent node
            products.RemoveChild(product1);
            product2.RemoveParent(products);

            //or get the site map from an xml file
            ISiteMapReader reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            //get the site map
            site = reader.Read();

            //get the child nodes of a site map node
            children = site.RootNode.Children;

            //enumerate node children
            for (int index = 0; index < children.Length; index++)
            {
                Console.WriteLine(children[index].Name);
            }
        }

        /// <summary>
        /// Represents the Multiple Parents usage of this component.Each node can be specified any number
        /// of parents and any number of children.
        /// </summary>
        [Test]
        public void MultipleParents()
        {
            //or get the site map from an xml file
            ISiteMapReader reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            //get the site map
            SiteMap site = reader.Read();

            //get the child nodes of a site map node
            SiteMapNode[] children = site.RootNode.Children;

            //enumerate node children
            for (int index = 0; index < children.Length; index++)
            {
                Console.WriteLine(children[index].Name);

                for (int j = 0; j < children[index].Children.Length; j++)
                {
                    Console.WriteLine(children[index].Children[j].Name);
                }
            }
        }


        /// <summary>
        /// The site map node permissions need to be configured with the Authorization Manager, before
        /// they are included in the site map data source. Below is an example of how to set up the
        /// permissions.
        /// </summary>
        [Test]
        public void AuthorizationPermissionsConfigurationUsage()
        {
            //create the Authorization Manager
            AuthorizationManager am = new AuthorizationManager();

            // Get the Persistence Manager
            IAuthorizationPersistenceManager pm = am.Persistence;

            // configure the resource type
            // the resource type can be configured with this component when used to authorize a request.
            string resourceTypeName = "node";

            IActionContextType resourceType = pm.GetActionContextType(resourceTypeName);

            // configure the userType
            // the principal type can be configured with this component when used to authorize a request.
            string principalTypeName = "user";
            IActionContextType principalType = pm.GetActionContextType(principalTypeName);

            //create the action. We only define one action; the action is specified by the IAuthorizationEntiy
            // in this component when authorizing a request.

            // a variable storing the name of action.
            string actionName = "view node";
            IAction viewAction = pm.GetAction(actionName);

            //add the context types to the action
            viewAction.AddContextType(resourceType);
            viewAction.AddContextType(principalType);

            // create some site map nodes members; nodes should be specified by their name
            // all site map nodes that require  authorization should be specified
            IMember mainPage = pm.GetMember(resourceType, NAME);

            //The following configuration sets the admins role with bob identity, and the guests role with
            //jim identity

            // a variable storing the name of admin.
            string adminName = "bob";
            IMember bob = pm.GetMember(principalType, adminName);

            // a variable storing the name of admin role.
            string adminRoleName = "admin";

            IRole admin = pm.GetRole(principalType, adminRoleName);
            admin.AddMember(RoleMembershipType.Inclusion, bob);

            //add jim identity to the quests role

            // a variable storing the name of guest.
            string guestName = "jim";

            IMember jim = pm.GetMember(principalType, guestName);

            // a variable storing the name of guest role.
            string guestRoleName = "guests";

            IRole guests = pm.GetRole(principalType, guestRoleName);
            guests.AddMember(RoleMembershipType.Inclusion, jim);

            // create an access policy with "admin" role

            // a variable storing the name of policy.
            string policyName = "admins policy";

            IAuthorizationPolicy adminsPolicy = pm.GetAuthorizationPolicy(policyName);

            //add the action to the policy
            adminsPolicy.AddAction(viewAction);

            //add the role to the policy
            adminsPolicy.AddDescriptor(admin);

            //add the main page and administration page authorized only to administrators
            //descriptors should be added in the same fashion for all authorized nodes
            adminsPolicy.AddDescriptor(mainPage);
            adminsPolicy.IsAllow = true;

            //refresh the authorization manager
            am.Refresh();

            SiteMapNode node = new SiteMapNode(NAME, DESCRIPTION, URL);

            IAuthorizationEntity entity = new PrincipalAuthorizationEntity(new MockIPrincipal(guestName));

            NodeAuthorization nodeAuthorization = new NodeAuthorization(am);

            // main is accessable node base on the configuration.
            Console.WriteLine(adminName + " can access the " + mainPage.Key + ":"
                + nodeAuthorization.IsAccessible(node) + ".");

            nodeAuthorization = new NodeAuthorization(entity, am);

            // check the unaccessable configuration.
            // main is accessable node base on the configuration.
            Console.WriteLine(guestName + " can access the " + mainPage.Key + ":"
                + nodeAuthorization.IsAccessible(node) + ".");
        }

        /// <summary>
        /// Represents the usage of the MenuSiteMapDataSource. The menu control can also be configured
        /// to use the MenuSiteMapDataSource to load the menu based on the site map.
        /// </summary>
        [Test]
        public void WebMenuControlSiteMapDataSource()
        {
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            //create a node authorization implementation
            INodeAuthorization nodeAuthorization = new DisabledNodeAuthorization();

            //create the menu source
            IMenuSource menuSource = new MenuSiteMapDataSource();

            //or with node authorization to use
            menuSource = new MenuSiteMapDataSource(nodeAuthorization);

            //create the menu control 
            WebMenuControl menuControl = new WebMenuControl();

            //set the menu data source to the web menu control
            menuControl.DataSource = menuSource.GetMenu(menuControl);

            // Console out the content of the DataSource.
            foreach (MenuItem firstItem in menuControl.DataSource.MenuItems)
            {
                Console.WriteLine("The text of the first level item : " + firstItem.Text);
                Console.WriteLine("The url of the first level item : " + firstItem.Url);

                foreach (MenuItem secondItem in firstItem.MenuItems)
                {
                    Console.WriteLine("The text of the second level item below " + firstItem.Text
                        + " : " + secondItem.Text);

                    Console.WriteLine("The url of the second level item below " + firstItem.Text
                        + " : " + secondItem.Url);
                }
            }
        }

        /// <summary>
        /// Represents a usage of the TreeViewSiteMapDataSource.
        /// </summary>
        [Test]
        public void WebTreeViewControlSiteMapDataSource()
        {
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            //create a node authorization implementation
            INodeAuthorization nodeAuthorization = new DisabledNodeAuthorization();

            //create the treeSource.
            ITreeLoader treeSource  = new TreeViewSiteMapDataSource();

            //or with node authorization to use
            treeSource  = new TreeViewSiteMapDataSource(nodeAuthorization);

            // get the root node of the created tree.
            TreeNode rootNode = treeSource.LoadTree();

            // Console out the content of the tree.
            Console.WriteLine("The root node is : " + rootNode.Text);

            foreach (TreeNode firstChild in rootNode.Children)
            {
                Console.WriteLine("The children below " + rootNode.Text + " : " + firstChild.Text);

                foreach (TreeNode secondChild in firstChild.Children)
                {
                    Console.WriteLine("The children below " + firstChild.Text + " : " + secondChild.Text);
                }
            }

        }

        /// <summary>
        /// Represents the usage of the BreadCrumbSiteMapDataSource.The bread crumb static site map data source to
        /// use will need to be configured with the control. The control does not allow to programmatically set
        /// an ISiteDiscovery implementation to use.
        /// </summary>
        [Test]
        public void BreadCrumbTrailControlSiteMapDataSource()
        {

            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            //create a node authorization implementation
            INodeAuthorization nodeAuthorization = new DisabledNodeAuthorization();

            ISiteDiscovery siteSource = new BreadCrumbSiteMapDataSource();

            //or with node authorization to use (please see above)
            siteSource = new BreadCrumbSiteMapDataSource(nodeAuthorization);

            //get the site map
            IDictionary sitemap = siteSource.GetSiteMap();

            // Verify the content.
            foreach (DictionaryEntry entry in sitemap)
            {
                INodeMather root = entry.Key as INodeMather;

                Console.WriteLine("Title of the node : " + root.Title);
            }
        }
    }
}