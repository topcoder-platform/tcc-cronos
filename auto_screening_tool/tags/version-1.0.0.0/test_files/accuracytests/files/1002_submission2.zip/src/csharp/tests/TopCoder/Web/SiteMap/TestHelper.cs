using NUnit.Framework;
using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// This is a helper class used in the test.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    internal class TestHelper
    {
        /// <summary>
        /// Makes sure that the object given can be correctly serialized and deserialized.
        /// </summary>
        /// <param name="objectToSerialize">
        /// A reference to an object to test for serialization. The actual object should be as
        /// complex as possible (i.e. if there are 10 attributes, all 10 should be filled in,
        /// and if some of them are ILists, they should be filled in with some data.)
        /// </param>
        public static void SerializationTest(object objectToSerialize)
        {
            MemoryStream stream = new MemoryStream();
            IFormatter formatter = new BinaryFormatter();

            try
            {
                formatter.Serialize(stream, objectToSerialize);
            }
            catch (Exception e)
            {
                Assert.Fail("Could not serialize " +
                                objectToSerialize.GetType().ToString() + ": " +
                                e.Message);
            }

            stream.Seek(0, System.IO.SeekOrigin.Begin);

            object deserializedObject = null;

            try
            {
                deserializedObject = formatter.Deserialize(stream);
            }
            catch (Exception e)
            {
                Assert.Fail("Could not deserialize " +
                                objectToSerialize.GetType().ToString() + ": " +
                                e.Message);
            }

            Assert.IsTrue(objectToSerialize.GetType().IsInstanceOfType(deserializedObject));

            // NOTE: Doesn't test equality because many objects may not be of value types (or
            //       contain all value types) and default to object reference equality, which
            //       will always return false.
        }
    }
}