using System;
using System.Collections;

namespace TopCoder.Web.SiteMap
{

    /// <summary>
    /// <p>
    /// The site map node represents a page in the site map hierarchy. It encapsulates a title, description
    /// and the page URL. The node also encapsulates the parent and child relations.
    /// </p>
    /// <p>
    /// A node can have any number of parent nodes and any number of child nodes. Parent and child relations
    /// can be added or removed. Each node will hold a collection of relations to parent nodes and a
    /// collection of relations to children nodes. The internal methods are used by the Relation class to set
    /// the parent child relation it represents when a new Relation instance is instantiated.
    /// </p>
    /// </summary>
    /// <remarks>
    /// Thread safety:This class is thread safe. It uses synchronized list wrappers and locks on the lists
    /// inside the methods and in the properties.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class SiteMapNode
    {
        /// <summary>
        /// <p>The name of the site map node.</p>
        /// <p>
        /// Set in the constructor. Referenced and set by its associated property. Can not be null
        /// or empty string.
        /// </p>
        /// </summary>
        private string name;

        /// <summary>
        /// <p>The URL of the page the site map node represents.</p>
        /// <p>
        /// Set in the constructor. Referenced and set by its associated property. Can not be null
        /// (empty is allowed.)
        /// </p>
        /// </summary>
        private string description;

        /// <summary>
        /// <p>The URL of the page the site map node represents.</p>
        /// <p>
        /// Set in the constructor. Referenced and set by its associated property. Can not be null
        /// or empty string.
        /// </p>
        /// </summary>
        private string url;

        /// <summary>
        /// <p>
        /// The lists holds references to all the parent relations of this node. This node will be
        /// the child node in the relations.
        /// </p>
        /// <p>
        /// List elements are non null Relation objects. The list can be empty. Elements are added
        /// and removed in the AddParentRelation and RemoveParentRelation methods. Created in the
        /// constructor as a synchronized ArrayList.
        /// </p>
        /// </summary>
        private readonly IList parentRelations;

        /// <summary>
        /// <p>
        /// The lists holds references to all the child relations of this node. This node will be
        /// the parent node in the relations.
        /// </p>
        /// <p>
        /// List elements are non null Relation objects. The list can be empty. Elements are added
        /// and removed in the AddChildRelation and RemoveChildRelation methods. Created in the constructor
        /// as a synchronized ArrayList.
        /// </p>
        /// </summary>
        private readonly IList childRelations;

        /// <summary>
        /// <p>
        /// Returns or sets the name of this node.
        /// </p>
        /// <p>Will lock on this in both get and set properties.</p>
        /// </summary>
        /// <value>
        /// The name of the site map node.
        /// </value>
        /// <exception cref="ArgumentNullException">If the given value is null.</exception>
        /// <exception cref="ArgumentException">If the given value is empty string.</exception>
        public string Name
        {
            get
            {
                lock (this)
                {
                    return name;
                }
            }

            set
            {
                lock (this)
                {
                    SiteMapHelper.ValidateNotNullOrEmpty(value, "value");

                    this.name = value;
                }
            }
        }

        /// <summary>
        /// <p>Returns or sets the description of this node.</p>
        /// <p>Will lock on this in both get and set properties.</p>
        /// </summary>
        /// <value>
        /// The URL of the page the site map node represents.
        /// </value>
        /// <exception cref="ArgumentNullException">If the given value is null.</exception>
        public string Description
        {
            get
            {
                lock (this)
                {
                    return description;
                }
            }
            set
            {
                lock (this)
                {
                    SiteMapHelper.ValidateNotNull(value, "value");

                    this.description = value;
                }
            }
        }

        /// <summary>
        /// <p>Returns or sets the URL of this node.</p>
        /// <p>Will lock on this in both get and set properties.</p>
        /// </summary>
        /// <value>
        /// The URL of the page the site map node represents.
        /// </value>
        /// <exception cref="ArgumentNullException">If the given value is null.</exception>
        /// <exception cref="ArgumentException">If the given value is empty string.</exception>
        public string Url
        {
            get
            {
                lock (this)
                {
                    return url;
                }
            }
            set
            {
                lock (this)
                {
                    SiteMapHelper.ValidateNotNullOrEmpty(value, "value");

                    this.url = value;
                }
            }
        }

        /// <summary>
        /// <p>Returns an array of the parent nodes.</p>
        /// <p>
        /// Creates an SiteMapNode array of parentRelations.Count size. For each Relation in parentRelation
        /// get the parent node and added to the array.
        /// </p>
        /// <p>Will lock on parentRelation list while enumerating the parent relations.</p>
        /// </summary>
        /// <value>
        /// The array of the parent nodes.
        /// </value>
        public SiteMapNode[] Parents
        {
            get
            {
                lock (parentRelations)
                {
                    SiteMapNode[] ret = new SiteMapNode[parentRelations.Count];

                    for (int i = 0; i < parentRelations.Count; i++)
                    {
                        ret[i] = (parentRelations[i] as Relation).Parent;
                    }

                    return ret;
                }
            }
        }

        /// <summary>
        /// <p>Returns an array of the child nodes.</p>
        /// <p>
        /// Creates an SiteMapNode array of childRelations.Count size. For each Relation in childRelation
        /// get the child node and added to the array.
        /// </p>
        /// <p>
        /// Will lock on childRelation list while enumerating the child relations.
        /// </p>
        /// </summary>
        /// <value>
        /// The array of the child nodes.
        /// </value>
        public SiteMapNode[] Children
        {
            get
            {
                lock (childRelations)
                {
                    SiteMapNode[] ret = new SiteMapNode[childRelations.Count];

                    for (int i = 0; i < childRelations.Count; i++)
                    {
                        ret[i] = (childRelations[i] as Relation).Child;
                    }

                    return ret;
                }
            }
        }


        /// <summary>
        /// <p>Create a new <c>SiteMapNode</c> instance with parameter values.</p>
        /// </summary>
        /// <param name="name">The site map node name.</param>
        /// <param name="description">The site map node description.</param>
        /// <param name="url">The site map node url.</param>
        /// <exception cref="ArgumentNullException">If any argument is null.</exception>
        /// <exception cref="ArgumentException">If any argument is empty string except the description.
        /// </exception>
        public SiteMapNode(string name, string description, string url)
        {
            // check parameters.
            SiteMapHelper.ValidateNotNullOrEmpty(name, "name");
            SiteMapHelper.ValidateNotNull(description, "description");
            SiteMapHelper.ValidateNotNullOrEmpty(url, "url");

            this.name = name;
            this.description = description;
            this.url = url;

            this.childRelations = ArrayList.Synchronized(new ArrayList());
            this.parentRelations = ArrayList.Synchronized(new ArrayList());
        }

        /// <summary>
        /// <p>This method adds the given relation to the parentRelations list.</p>
        /// <p>
        /// This method is used by the Relation class to add itself to the node parent relations collections.
        /// </p>
        /// </summary>
        /// <param name="parentRelation">The relation object to add.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        internal void AddParentRelation(Relation parentRelation)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(parentRelation, "parentRelation");

            this.parentRelations.Add(parentRelation);
        }

        /// <summary>
        /// <p>This method adds the given relation to the childRelations list.</p>
        /// <p>
        /// This method is used by the Relation class to add itself to the node children relations collections.
        /// </p>
        /// </summary>
        /// <param name="childRelation">The relation object to add.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        internal void AddChildRelation(Relation childRelation)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(childRelation, "childRelation");

            this.childRelations.Add(childRelation);
        }

        /// <summary>
        /// <p>This method simply removes the relation object from the parentRelations list.</p>
        /// <p>This method is used by the AddParent and AddChild methods.</p>
        /// </summary>
        /// <param name="parentRelation">The relation object to remove.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        internal void RemoveParentRelation(Relation parentRelation)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(parentRelation, "parentRelation");

            this.parentRelations.Remove(parentRelation);
        }

        /// <summary>
        /// <p>This method simply removes the relation object from the childRelations list.</p>
        /// <p>This method is used by the AddParent and AddChild methods.</p>
        /// </summary>
        /// <param name="childRelation">The relation object to remove</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        internal void RemoveChildRelation(Relation childRelation)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(childRelation, "childRelation");

            this.childRelations.Remove(childRelation);
        }


        /// <summary>
        /// <p>
        /// This method creates a new parent-child relation where the parent is the given node and
        /// the child is this node.
        /// </p>
        /// <p>Simply creates a new Relation instance with the given parent and 'this' child </p>
        /// </summary>
        /// <param name="parent">The site map node to add as parent to this one.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        public void AddParent(SiteMapNode parent)
        {
            new Relation(parent, this);
        }


        /// <summary>
        /// <p>
        /// This method creates a new parent-child relation where the parent is the this node and the
        /// child is the given node.
        /// </p>
        /// <p>Simply creates a new Relation instance with this as the parent and the given node as child.</p>
        /// </summary>
        /// <param name="child">The child node to add as child to this one.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        public void AddChild(SiteMapNode child)
        {
            new Relation(this, child);
        }


        /// <summary>
        /// <p>This method deletes a parent - child relation between two nodes.</p>
        /// <p>Get the Relation object from the parentRelation list where
        /// relation.Parent.Equals(parent). Remove the Relation object from this node parent relations
        /// and from the parent's node child relations. Locks on the parentRelation list while enumerating.
        /// </p>
        /// </summary>
        /// <param name="parent">The parent node to remove.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        public void RemoveParent(SiteMapNode parent)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(parent, "parent");

            lock (parentRelations)
            {
                foreach (Relation r in parentRelations)
                {
                    if (r.Parent.Equals(parent))
                    {
                        parentRelations.Remove(r);

                        return;
                    }
                }
            }
        }


        /// <summary>
        /// <p>This method deletes a parent - child relation between two nodes.</p>
        /// <p>Get the Relation object from the childRelation list where
        /// relation.Child.Equals(child). Remove the Relation object from this
        /// node child relations and from the child's node parent relations. Locks
        /// on childRelation list while enumerating.
        /// </p>
        /// </summary>
        /// <param name="child">The child node to remove.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        public void RemoveChild(SiteMapNode child)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(child, "child");

            lock (childRelations)
            {
                foreach (Relation r in childRelations)
                {
                    if (r.Child.Equals(child))
                    {
                        childRelations.Remove(r);

                        return;
                    }
                }
            }
        }


        /// <summary>
        /// <p>Overrides the equal method as comparisons between two site map nodes will be required.</p>
        /// <p>Returns true if name, description and URL are the same.</p>
        /// </summary>
        /// <param name="node">A SiteMapNode object reference to check for equality.</param>
        /// <returns>True if equal; false otherwise.</returns>
        public override bool Equals(object node)
        {
            return node is SiteMapNode ? (node as SiteMapNode).Name.Equals(Name)
                && (node as SiteMapNode).Description.Equals(Description)
                && (node as SiteMapNode).Url.Equals(Url) : false;
        }

    }
}