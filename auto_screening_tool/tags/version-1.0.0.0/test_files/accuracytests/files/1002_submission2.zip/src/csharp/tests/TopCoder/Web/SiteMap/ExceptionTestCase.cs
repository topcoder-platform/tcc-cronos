using System;
using NUnit.Framework;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Tests the functionality of customized exceptions..
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class ExceptionTestCase
    {

        /// <summary>
        /// Represents a detail error message.
        /// </summary>
        private const string DETAIL_MESSAGE = "A detail message";

        /// <summary>
        /// Represents a original cause of the error.
        /// </summary>
        private static readonly Exception CAUSE = new Exception();

        /// <summary>
        /// Tests accuracy of <c>InvalidNodeRelationException()</c>. An instance of this class should be created.
        /// </summary>
        [Test]
        public void TestInvalidNodeRelationExceptionAccuracy()
        {
            InvalidNodeRelationException exception = new InvalidNodeRelationException();

            Assert.IsNotNull(exception, "Creates instance of LocalizationException failed.");
        }

        /// <summary>
        /// Tests accuracy of <c>InvalidNodeRelationException(string)</c>. The detail error message should be
        /// retrieved as set in the argument.
        /// </summary>
        [Test]
        public void TestInvalidNodeRelationExceptionStringAccuracy()
        {
            InvalidNodeRelationException exception = new InvalidNodeRelationException(DETAIL_MESSAGE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
        }

        /// <summary>
        /// Tests accuracy of <c>InvalidNodeRelationException(string, Exception)</c>. The detail error message
        /// should be retrieved as set in the argument. The original cause of the error should be retrieved
        /// as set in the argument.
        /// </summary>
        [Test]
        public void TestInvalidNodeRelationExceptionStringExceptionAccuracy()
        {
            InvalidNodeRelationException exception = new InvalidNodeRelationException(DETAIL_MESSAGE, CAUSE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
            Assert.AreEqual(CAUSE, exception.InnerException, "The cause should be the same as in argument.");
        }

        /// <summary>
        /// This test makes sure that the<c>InvalidNodeRelationException</c> class can be properly
        /// serialized and deserialized.
        /// </summary>
        [Test]
        public void TestSerializationInvalidNodeRelationException()
        {
            InvalidNodeRelationException exception = new InvalidNodeRelationException(DETAIL_MESSAGE, CAUSE);

            TestHelper.SerializationTest(exception);
        }

        /// <summary>
        /// Tests accuracy of <c>NodeAuthorizationException()</c>. An instance of this class should be created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationExceptionAccuracy()
        {
            NodeAuthorizationException exception = new NodeAuthorizationException();

            Assert.IsNotNull(exception, "Creates instance of LocalizationException failed.");
        }

        /// <summary>
        /// Tests accuracy of <c>NodeAuthorizationException(string)</c>. The detail error message should be
        /// retrieved as set in the argument.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationExceptionStringAccuracy()
        {
            NodeAuthorizationException exception = new NodeAuthorizationException(DETAIL_MESSAGE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
        }

        /// <summary>
        /// Tests accuracy of <c>NodeAuthorizationException(string, Exception)</c>. The detail error message
        /// should be retrieved as set in the argument. The original cause of the error should be retrieved
        /// as set in the argument.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationExceptionStringExceptionAccuracy()
        {
            NodeAuthorizationException exception = new NodeAuthorizationException(DETAIL_MESSAGE, CAUSE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
            Assert.AreEqual(CAUSE, exception.InnerException, "The cause should be the same as in argument.");
        }

        /// <summary>
        /// This test makes sure that the<c>NodeAuthorizationException</c> class can be properly
        /// serialized and deserialized.
        /// </summary>
        [Test]
        public void TestSerializationNodeAuthorizationException()
        {
            NodeAuthorizationException exception = new NodeAuthorizationException(DETAIL_MESSAGE, CAUSE);

            TestHelper.SerializationTest(exception);
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapConfigurationException()</c>. An instance of this class should be created.
        /// </summary>
        [Test]
        public void TestSiteMapConfigurationExceptionAccuracy()
        {
            SiteMapConfigurationException exception = new SiteMapConfigurationException();

            Assert.IsNotNull(exception, "Creates instance of LocalizationException failed.");
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapConfigurationException(string)</c>. The detail error message should be
        /// retrieved as set in the argument.
        /// </summary>
        [Test]
        public void TestSiteMapConfigurationExceptionStringAccuracy()
        {
            SiteMapConfigurationException exception = new SiteMapConfigurationException(DETAIL_MESSAGE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapConfigurationException(string, Exception)</c>. The detail error message
        /// should be retrieved as set in the argument. The original cause of the error should be retrieved
        /// as set in the argument.
        /// </summary>
        [Test]
        public void TestSiteMapConfigurationExceptionStringExceptionAccuracy()
        {
            SiteMapConfigurationException exception = new SiteMapConfigurationException(DETAIL_MESSAGE, CAUSE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
            Assert.AreEqual(CAUSE, exception.InnerException, "The cause should be the same as in argument.");
        }

        /// <summary>
        /// This test makes sure that the<c>SiteMapConfigurationException</c> class can be properly
        /// serialized and deserialized.
        /// </summary>
        [Test]
        public void TestSerializationSiteMapConfigurationException()
        {
            SiteMapConfigurationException exception = new SiteMapConfigurationException(DETAIL_MESSAGE, CAUSE);

            TestHelper.SerializationTest(exception);
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapException()</c>. An instance of this class should be created.
        /// </summary>
        [Test]
        public void TestSiteMapExceptionAccuracy()
        {
            SiteMapException exception = new SiteMapException();

            Assert.IsNotNull(exception, "Creates instance of LocalizationException failed.");
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapException(string)</c>. The detail error message should be
        /// retrieved as set in the argument.
        /// </summary>
        [Test]
        public void TestSiteMapExceptionStringAccuracy()
        {
            SiteMapException exception = new SiteMapException(DETAIL_MESSAGE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapException(string, Exception)</c>. The detail error message
        /// should be retrieved as set in the argument. The original cause of the error should be retrieved
        /// as set in the argument.
        /// </summary>
        [Test]
        public void TestSiteMapExceptionStringExceptionAccuracy()
        {
            SiteMapException exception = new SiteMapException(DETAIL_MESSAGE, CAUSE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
            Assert.AreEqual(CAUSE, exception.InnerException, "The cause should be the same as in argument.");
        }

        /// <summary>
        /// This test makes sure that the<c>SiteMapException</c> class can be properly
        /// serialized and deserialized.
        /// </summary>
        [Test]
        public void TestSerializationSiteMapException()
        {
            SiteMapException exception = new SiteMapException(DETAIL_MESSAGE, CAUSE);

            TestHelper.SerializationTest(exception);
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapReadException()</c>. An instance of this class should be created.
        /// </summary>
        [Test]
        public void TestSiteMapReadExceptionAccuracy()
        {
            SiteMapReadException exception = new SiteMapReadException();

            Assert.IsNotNull(exception, "Creates instance of LocalizationException failed.");
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapReadException(string)</c>. The detail error message should be
        /// retrieved as set in the argument.
        /// </summary>
        [Test]
        public void TestSiteMapReadExceptionStringAccuracy()
        {
            SiteMapReadException exception = new SiteMapReadException(DETAIL_MESSAGE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
        }

        /// <summary>
        /// Tests accuracy of <c>SiteMapReadException(string, Exception)</c>. The detail error message
        /// should be retrieved as set in the argument. The original cause of the error should be retrieved
        /// as set in the argument.
        /// </summary>
        [Test]
        public void TestSiteMapReadExceptionStringExceptionAccuracy()
        {
            SiteMapReadException exception = new SiteMapReadException(DETAIL_MESSAGE, CAUSE);

            Assert.AreEqual
                (DETAIL_MESSAGE, exception.Message, "The detail message should be the same as in argument.");
            Assert.AreEqual(CAUSE, exception.InnerException, "The cause should be the same as in argument.");
        }

        /// <summary>
        /// This test makes sure that the<c>SiteMapReadException</c> class can be properly
        /// serialized and deserialized.
        /// </summary>
        [Test]
        public void TestSerializationSiteMapReadException()
        {
            SiteMapReadException exception = new SiteMapReadException(DETAIL_MESSAGE, CAUSE);

            TestHelper.SerializationTest(exception);
        }

    }
}