using System;
using System.Runtime.Serialization;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// <p>
    /// This exception is used to signal any problems while determining if access to a specified
    /// site map node is granted. Throw by INodeAuthorization implementations..
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [Serializable]
    public class NodeAuthorizationException : SiteMapException
    {
        /// <summary>
        /// Creates a new instance of <c>NodeAuthorizationException</c> class.
        /// </summary>
        public NodeAuthorizationException()
        {
        }

        /// <summary>
        /// Creates a new instance of <c>NodeAuthorizationException</c> class. The detailed error message is
        /// given.
        /// <p>
        /// The string argument is not checked - it may be null or empty.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        public NodeAuthorizationException(string message) : base(message)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>NodeAuthorizationException</c> class. The detailed error message and
        /// the original innerException of this error are given.
        /// <p>
        /// Both arguments are not checked.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        /// <param name="innerException">The original innerException of this error.</param>
        public NodeAuthorizationException(string message, Exception innerException) : base(message, innerException)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>NodeAuthorizationException</c> class with deserialization.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source and destination.</param>
        protected NodeAuthorizationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}