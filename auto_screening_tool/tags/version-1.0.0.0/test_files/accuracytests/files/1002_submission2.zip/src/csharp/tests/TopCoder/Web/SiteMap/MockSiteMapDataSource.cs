using System;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// <p>
    /// Defines a Mock class of <c>SiteMapDataSource</c>.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class MockSiteMapDataSource : SiteMapDataSource
    {
        /// <summary>
        /// <p>Returns the INodeAuthorization reference for derived classes to use.</p>
        /// </summary>
        /// <value>
        /// The INodeAuthorization implementation to be used by derived classes for node authorization.
        /// </value>
        public new INodeAuthorization NodeAuthorization
        {
            get
            {
                return base.NodeAuthorization;
            }
        }

        /// <summary>
        /// <p>Returns the site map object model.</p>
        /// </summary>
        /// <value>
        /// The site map object model retrieved from a ISiteMapReader implementation.
        /// </value>
        public new SiteMap SiteMap
        {
            get
            {
                return base.SiteMap;
            }
        }

        /// <summary>
        /// Create a new <c>MockSiteMapDataSource</c> instance with default nameSpace.
        /// </summary>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public MockSiteMapDataSource()
        {
        }

        /// <summary>
        /// Create a new <c>MockSiteMapDataSource</c> instance with given nameSpace.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="ArgumentException">If the given string argument is empty.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public MockSiteMapDataSource(string nameSpace) : base(nameSpace)
        {
        }

        /// <summary>
        /// Create a new <c>MockSiteMapDataSource</c> instance with given INodeAuthorization.
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to plug instead of the configured one.
        /// </param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public MockSiteMapDataSource(INodeAuthorization nodeAuthorization) : base(nodeAuthorization)
        {
        }


        /// <summary>
        /// Create a new <c>MockSiteMapDataSource</c> instance with given ISiteMapReader.
        /// </summary>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public MockSiteMapDataSource(ISiteMapReader siteMapReader) : base(siteMapReader)
        {
        }


        /// <summary>
        /// Create a new <c>MockSiteMapDataSource</c> instance with given INodeAuthorization and ISiteMapReader.
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to plug instead of the configured one.
        /// </param>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        public MockSiteMapDataSource(INodeAuthorization nodeAuthorization, ISiteMapReader siteMapReader)
            : base(nodeAuthorization, siteMapReader)
        {
        }
    }
}