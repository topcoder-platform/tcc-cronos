using System;
using System.Collections;
using NUnit.Framework;
using TopCoder.Util.ConfigurationManager;
using TopCoder.Web.SiteMap;
using TopCoder.Web.SiteMap.Authorization;
using TopCoder.Web.SiteMap.Readers;
using TopCoder.Web.UI.WebControl.BreadCrumb.PathDiscovery.NodeMatcher;

namespace TopCoder.Web.UI.WebControl.BreadCrumb.PathDiscovery
{

    /// <summary>
    /// Tests the functionality and error cases of the <c>BreadCrumbSiteMapDataSource</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class BreadCrumbSiteMapDataSourceTestCase
    {
        /// <summary>
        /// Represents a ConfigManager instance used in the test.
        /// </summary>
        private ConfigManager manager = ConfigManager.GetInstance();

        /// <summary>
        /// Represents the file name template of the namespace used to create instance.
        /// </summary>
        private const string FILE_NAME_TEMP = "../../test_files/SiteMapDataSource/{0}.xml";

        /// <summary>
        /// Represents a valid file name to create instance.
        /// </summary>
        private const string VALID_FILE = "SiteMapDataSource";

        /// <summary>
        /// Represents a missing object_factory_namespace property configuration file name.
        /// </summary>
        private const string MISSING_OBJECT_FACTORY_NAMESPACE = "Missing_object_factory_namespace";

        /// <summary>
        /// Represents an empty object_factory_namespace property configuration file name.
        /// </summary>
        private const string EMPTY_OBJECT_FACTORY_NAMESPACE = "Empty_object_factory_namespace";

        /// <summary>
        /// Represents a missing site_map_reader_key property configuration file name.
        /// </summary>
        private const string MISSING_SITE_MAP_READER_KEY = "Missing_site_map_reader_key";

        /// <summary>
        /// Represents an empty site_map_reader_key property configuration file name.
        /// </summary>
        private const string EMPTY_SITE_MAP_READER_KEY = "Empty_site_map_reader_key";

        /// <summary>
        /// Represents a missing node_authorization_key property configuration file name.
        /// </summary>
        private const string MISSING_NODE_AUTHORIZATION_KEY = "Missing_node_authorization_key";

        /// <summary>
        /// Represents an empty node_authorization_key property configuration file name.
        /// </summary>
        private const string EMPTY_NODE_AUTHORIZATION_KEY = "Empty_node_authorization_key";

        /// <summary>
        /// Represents a valid nameSpace in the configuration file.
        /// </summary>
        private const string VALID_NAME_SPACE = "TopCoder.Web.SiteMap";

        /// <summary>
        /// Represents a valid xml file path used in the test.
        /// </summary>
        private const string VALID_XML_FILE_PATH = "../../test_files/Readers/SiteMap.xml";

        /// <summary>
        /// Represents a valid xsd file path used in the test.
        /// </summary>
        private const string VALID_XSD_FILE_PATH = "../../test_files/Readers/SiteMap.xsd";

        /// <summary>
        /// Represents the ISiteMapReader instance used as argument in the test.
        /// </summary>
        private ISiteMapReader reader;

        /// <summary>
        /// Represents a <c>BreadCrumbSiteMapDataSource</c> instance used in the test.
        /// </summary>
        private BreadCrumbSiteMapDataSource source;

        /// <summary>
        /// Represents the INodeAuthorization instance used as argument in the test.
        /// </summary>
        private INodeAuthorization nodeAuthorization;


        /// <summary>
        /// Sets up the test environment. The test instances are created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            nodeAuthorization = new DisabledNodeAuthorization();

            reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            source = new BreadCrumbSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Cleans up the test environment. The test instances are disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            // clear the configuration manager.
            manager.Clear();

            nodeAuthorization = null;

            source = null;
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource()</c> when the optional property is missing.
        /// The BreadCrumbSiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new BreadCrumbSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The BreadCrumbSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource()</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new BreadCrumbSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new BreadCrumbSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new BreadCrumbSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new BreadCrumbSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new BreadCrumbSiteMapDataSource();
        }

        /// <summary>
        /// Accuracy test of the <c>BreadCrumbSiteMapDataSource()</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceAccuracy()
        {
            source = new BreadCrumbSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The BreadCrumbSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>BreadCrumbSiteMapDataSource(String)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestBreadCrumbSiteMapDataSourceStringNull()
        {
            new BreadCrumbSiteMapDataSource(null as string);
        }

        /// <summary>
        /// Test the <c>BreadCrumbSiteMapDataSource(String)</c> with empty string argument. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestBreadCrumbSiteMapDataSourceStringEmpty()
        {
            new BreadCrumbSiteMapDataSource("   ");
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(String)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceStringMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new BreadCrumbSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The BreadCrumbSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(String)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceStringEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new BreadCrumbSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceStringMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new BreadCrumbSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceStringEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new BreadCrumbSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceStringMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new BreadCrumbSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceStringEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new BreadCrumbSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Accuracy test of the <c>BreadCrumbSiteMapDataSource(String)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceStringAccuracy()
        {
            source = new BreadCrumbSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The BreadCrumbSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>BreadCrumbSiteMapDataSource(INodeAuthorization)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestBreadCrumbSiteMapDataSourceINodeAuthorizationNull()
        {
            new BreadCrumbSiteMapDataSource(null as INodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(INodeAuthorization)</c> when the optional property
        /// is missing. The BreadCrumbSiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceINodeAuthorizationMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new BreadCrumbSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The BreadCrumbSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(INodeAuthorization)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceINodeAuthorizationEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new BreadCrumbSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(INodeAuthorization)</c> when the required property
        /// is missing. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceINodeAuthorizationMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new BreadCrumbSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(INodeAuthorization)</c> when the required property
        /// value is empty. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceINodeAuthorizationEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new BreadCrumbSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Accuracy test of the <c>BreadCrumbSiteMapDataSource(INodeAuthorization)</c>. The instance is
        /// created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceINodeAuthorizationAccuracy()
        {
            source = new BreadCrumbSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The BreadCrumbSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>BreadCrumbSiteMapDataSource(ISiteMapReader)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderNull()
        {
            new BreadCrumbSiteMapDataSource(null as ISiteMapReader);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(ISiteMapReader)</c> when the optional property is
        /// missing. The BreadCrumbSiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new BreadCrumbSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The BreadCrumbSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(ISiteMapReader)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new BreadCrumbSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(ISiteMapReader)</c> when the required property is
        /// missing. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new BreadCrumbSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>BreadCrumbSiteMapDataSource(ISiteMapReader)</c> when the required property value
        /// is empty. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new BreadCrumbSiteMapDataSource(reader);
        }

        /// <summary>
        /// Accuracy test of the <c>BreadCrumbSiteMapDataSource(ISiteMapReader)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderAccuracy()
        {
            source = new BreadCrumbSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>BreadCrumbSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderINodeAuthorizationNullA()
        {
            new BreadCrumbSiteMapDataSource(null, reader);
        }

        /// <summary>
        /// Test the <c>BreadCrumbSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderINodeAuthorizationNullB()
        {
            new BreadCrumbSiteMapDataSource(nodeAuthorization, null);
        }

        /// <summary>
        /// Accuracy test of the <c>BreadCrumbSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c>.
        /// The instance is created.
        /// </summary>
        [Test]
        public void TestBreadCrumbSiteMapDataSourceISiteMapReaderINodeAuthorizationAccuracy()
        {
            source = new BreadCrumbSiteMapDataSource(nodeAuthorization, reader);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Accuracy test of the <c>GetSiteMap()</c>. The corresponding IDictionary of the data source is
        /// returned.
        /// </summary>
        [Test]
        public void TestGetSiteMapAccuracy()
        {
            IDictionary ret = source.GetSiteMap();

            // Verify.
            Assert.IsNotNull(ret, "The IDictionary should be returned.");

            MockSiteMapDataSource mockSource = new MockSiteMapDataSource(nodeAuthorization);

            SiteMapNode rootNode = mockSource.SiteMap.RootNode;

            // Verify.
            RecursiveVerify(rootNode, ret);
        }

        /// <summary>
        /// A helper method to verify the contents of the given SiteMapNode array and MenuItemCollection.
        /// </summary>
        /// <param name="nodes">The SiteMapNode array to verify.</param>
        /// <param name="maps">The IDictionary to verify.</param>
        private void RecursiveVerify(SiteMapNode root, IDictionary maps)
        {
            foreach (INodeMather key in maps.Keys)
            {
                if (key.Equals(new BasicNodeMatcher(root.Name, root.Url)))
                {
                    IList siteMapNodeList = maps[key] as IList;

                    Assert.IsNotNull(siteMapNodeList, "The given node " + root.Name +" should be authorized.");

                    int currentIndex = 0;

                    foreach (INodeMather childMatcher in siteMapNodeList)
                    {
                        // Verify the root node.
                        Assert.AreEqual(childMatcher.Title, root.Children[currentIndex].Name,
                            "The TitleName property should be the same as expected.");

                        Assert.AreEqual(childMatcher.Url, root.Children[currentIndex].Url,
                            "The Url property should be the same as expected.");

                        currentIndex++;
                    }
                }
            }

            foreach (SiteMapNode childRoot in root.Children)
            {
                // Verify Recursively.
                RecursiveVerify(childRoot, maps);
            }
        }
    }
}