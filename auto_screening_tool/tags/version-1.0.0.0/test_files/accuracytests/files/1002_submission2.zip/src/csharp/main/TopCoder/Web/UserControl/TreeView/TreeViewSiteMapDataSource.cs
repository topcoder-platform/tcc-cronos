using System;
using TopCoder.Web.SiteMap;

namespace TopCoder.Web.UserControl.TreeView
{

    /// <summary>
    /// This class implements the Tree View Control ITreeLoader interface to provide the tree view
    /// object model based on a site map object model. This class converts the site map into a tree
    /// view structure including only the site map nodes that the specified principal is authorized
    /// to access. The model is build recursively and only site map nodes authorized for the specified
    /// credentials are included.
    /// </summary>
    /// <remarks>
    /// Thread safety:This class has no state and is thread safe.</p>
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class TreeViewSiteMapDataSource : SiteMapDataSource, ITreeLoader
    {

        /// <summary>
        /// Create a new <c>TreeViewSiteMapDataSource</c> instance.
        /// </summary>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public TreeViewSiteMapDataSource()
        {
        }

        /// <summary>
        /// Create a new <c>TreeViewSiteMapDataSource</c> instance with given nameSpace.
        /// </summary>
        /// <param name="nameSpace">Configuration Namespace.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="ArgumentException">If the given string argument is empty.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public TreeViewSiteMapDataSource(string nameSpace) : base(nameSpace)
        {
        }

        /// <summary>
        /// <p>Create a new <c>TreeViewSiteMapDataSource</c> instance with given INodeAuthorization.</p>
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to use.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public TreeViewSiteMapDataSource(INodeAuthorization nodeAuthorization) : base(nodeAuthorization)
        {
        }

        /// <summary>
        /// <p>
        /// Create a new <c>TreeViewSiteMapDataSource</c> instance with given ISiteMapReader.
        /// </p>
        /// </summary>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public TreeViewSiteMapDataSource(ISiteMapReader siteMapReader) : base(siteMapReader)
        {
        }


        /// <summary>
        /// Create a new <c>TreeViewSiteMapDataSource</c> instance with given INodeAuthorization and
        /// ISiteMapReader.
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to plug instead of the configured one.
        /// </param>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        public TreeViewSiteMapDataSource(INodeAuthorization nodeAuthorization, ISiteMapReader siteMapReader)
            : base(nodeAuthorization, siteMapReader)
        {
        }

        /// <summary>
        /// <p>
        /// This method will convert the site map object model stored in the base classs and retrieved
        /// from a configured persistence into an tree view object model.
        /// </p>
        /// </summary>
        /// <exception>TreeLoadException if needed.</exception>
        /// <returns>The tree view object model.</returns>
        /// <exception cref="TreeLoadException">Error occurs while load the tree.</exception>
        public TreeNode LoadTree()
        {
            try
            {
                // the root node of the SiteMap from base class.
                SiteMapNode root = SiteMap.RootNode;


                TreeNode ret = null;

                if (this.NodeAuthorization.IsAccessible(root))
                {
                    // create a TreeNode corresponding with the given SiteMapNode.
                    ret = new TreeNode(root.Name);

                    // a helper method to recursively process the children nodes.
                    RecursiveProcess(root, ret);
                }

                return ret;
            }
            catch(Exception e)
            {
                throw new TreeLoadException(e.Message, e);
            }
        }

        /// <summary>
        /// A helper method to process the children node recursively. For each authorized
        /// create a corresponding TreeNode.
        /// </summary>
        /// <param name="rootNode">The root node whose children nodes are to be processed.</param>
        /// <param name="rootTreeNode">The root TreeNode whose children item are to be processed.</param>
        private void RecursiveProcess(SiteMapNode rootNode, TreeNode rootTreeNode)
        {
            // initialize the IconUrl property.
            rootTreeNode.IconUrl = rootNode.Url;

            foreach (SiteMapNode node in rootNode.Children)
            {
                // if current node is not authorized, ignore it as well as it's children nodes.
                if (NodeAuthorization.IsAccessible(node))
                {
                    TreeNode nextTreeNode = new TreeNode(node.Name);

                    rootTreeNode.AddChild(nextTreeNode);

                    RecursiveProcess(node, nextTreeNode);
                }
            }
        }
    }
}
