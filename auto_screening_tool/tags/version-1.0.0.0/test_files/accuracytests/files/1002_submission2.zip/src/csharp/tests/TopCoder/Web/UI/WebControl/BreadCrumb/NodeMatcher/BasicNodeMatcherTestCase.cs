using System;
using NUnit.Framework;

namespace TopCoder.Web.UI.WebControl.BreadCrumb.PathDiscovery.NodeMatcher
{
    /// <summary>
    /// Tests the functionality and error cases of the <c>BasicNodeMatcher</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class BasicNodeMatcherTestCase
    {

        /// <summary>
        /// Represents a const string used as argument.
        /// </summary>
        private const string TITLE = "title";

        /// <summary>
        /// Represents a const string used as argument.
        /// </summary>
        private const string URL = "url";

        /// <summary>
        /// Represents a <c>BasicNodeMatcher</c> instance used in the test.
        /// </summary>
        private BasicNodeMatcher matcher;

        /// <summary>
        /// Sets up the test environment. The test instance is created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            matcher = new BasicNodeMatcher(TITLE, URL);
        }

        /// <summary>
        /// Cleans up the test environment. The test instance is disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            matcher = null;
        }

        /// <summary>
        /// Test the <c>BasicNodeMatcher(string, string)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestBasicNodeMatcherStringStringNullA()
        {
            new BasicNodeMatcher(null, URL);
        }

        /// <summary>
        /// Test the <c>BasicNodeMatcher(string, string)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestBasicNodeMatcherStringStringNullB()
        {
            new BasicNodeMatcher(TITLE, null);
        }

        /// <summary>
        /// Test the <c>BasicNodeMatcher(string, string)</c> with empty string argument.
        /// Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestBasicNodeMatcherStringStringEmptyA()
        {
            new BasicNodeMatcher("   ", URL);
        }

        /// <summary>
        /// Test the <c>BasicNodeMatcher(string, string)</c> with empty string argument.
        /// Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestBasicNodeMatcherStringStringEmptyB()
        {
            new BasicNodeMatcher(TITLE, "    ");
        }

        /// <summary>
        /// Test the <c>BasicNodeMatcher(string, string)</c> with right arguments. The instance is created.
        /// </summary>
        [Test]
        public void TestBasicNodeMatcherStringStringAccuracy()
        {
            matcher = new BasicNodeMatcher(TITLE, URL);

            // Verify.
            Assert.IsNotNull(matcher, "The instance should be created.");
        }

        /// <summary>
        /// Accuracy test of the <c>Equals(object)</c>. False is returned.
        /// </summary>
        [Test]
        public void TestEqualsObjectReturnFalse()
        {
            bool ret = matcher.Equals(null);

            // Verify.
            Assert.IsFalse(ret, "The given object should not be equal to the current matcher.");
        }

        /// <summary>
        /// Accuracy test of the <c>Equals(object)</c>. True is returned.
        /// </summary>
        [Test]
        public void TestEqualsObjectReturnTrue()
        {
            bool ret = matcher.Equals(new BasicNodeMatcher(TITLE, URL));

            // Verify.
            Assert.IsTrue(ret, "The given object should be equal to the current matcher.");
        }

        /// <summary>
        /// Accuracy test of the <c>GetHashCode()</c>. The int value is returned.
        /// </summary>
        [Test]
        public void TestGetHashCode()
        {
            int ret = matcher.GetHashCode();

            int another = (new BasicNodeMatcher(TITLE, URL)).GetHashCode();

            // Verify.
            Assert.AreEqual(ret, another, "The hashcode should be returned.");
        }


        /// <summary>
        /// Accuracy test of the <c>Matches(BreadCrumbNode)</c>. True is returned.
        /// </summary>
        [Test]
        public void TestMatchesBreadCrumbNodeReturnTrue()
        {
            BreadCrumbNode node = new BreadCrumbNode(TITLE, URL);

            // Verify.
            Assert.IsTrue(matcher.Matches(node), "The given node should have the same title and url as the matcher.");
        }

        /// <summary>
        /// Accuracy test of the <c>Matches(BreadCrumbNode)</c>. False is returned.
        /// </summary>
        [Test]
        public void TestMatchesBreadCrumbNodeReturnFalse()
        {
            BreadCrumbNode node = new BreadCrumbNode(TITLE + TITLE, URL);

            // Verify.
            Assert.IsFalse(matcher.Matches(node),
                "The given node should not have the same title and url as the matcher.");
        }

    }
}