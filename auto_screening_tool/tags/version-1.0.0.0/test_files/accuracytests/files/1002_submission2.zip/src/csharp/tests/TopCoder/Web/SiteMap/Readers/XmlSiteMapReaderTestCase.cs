using System;
using NUnit.Framework;

namespace TopCoder.Web.SiteMap.Readers
{

    /// <summary>
    /// Tests the functionality and error cases of the <c>XmlSiteMapReader</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class XmlSiteMapReaderTestCase
    {
        /// <summary>
        /// Represents a valid xml file path used in the test.
        /// </summary>
        private const string VALID_XML_FILE_PATH = "../../test_files/Readers/SiteMap.xml";

        /// <summary>
        /// Represents a not exist file path of xml.
        /// </summary>
        private const string NOT_EXIST_XML_FILE_PATH = "../../test_files/Readers/notexist.xml";

        /// <summary>
        /// Represents an invalid file path of xml.
        /// </summary>
        private const string INVALID_FORMAT_XML_FILE_PATH = "../../test_files/Readers/InvalidFormat.xml";

        /// <summary>
        /// Represents an invalid file path of xml.
        /// </summary>
        private const string DUPLICATE_XML_FILE_PATH = "../../test_files/Readers/DuplicateNodes.xml";

        /// <summary>
        /// Represents an invalid file path of xml.
        /// </summary>
        private const string NOT_DEFINED_NODE_XML_FILE_PATH = "../../test_files/Readers/NotDefinedNode.xml";

        /// <summary>
        /// Represents a valid xsd file path used in the test.
        /// </summary>
        private const string VALID_XSD_FILE_PATH = "../../test_files/Readers/SiteMap.xsd";

        /// <summary>
        /// Represents a not exist file path of xsd.
        /// </summary>
        private const string NOT_EXIST_XSD_FIlE_PATH = "../../test_files/Readers/notexist.xsd";


        /// <summary>
        /// Represents a <c>XmlSiteMapReader</c> instance used in the test.
        /// </summary>
        private XmlSiteMapReader reader;

        /// <summary>
        /// Sets up the test environment. The test instance is created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);
        }

        /// <summary>
        /// Cleans up the test environment. The test instance is disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            reader = null;
        }

        /// <summary>
        /// Test the <c>XmlSiteMapReader(String, String)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestXmlSiteMapReaderStringStringNullA()
        {
            new XmlSiteMapReader(null, VALID_XSD_FILE_PATH);
        }

        /// <summary>
        /// Test the <c>XmlSiteMapReader(String, String)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestXmlSiteMapReaderStringStringNullB()
        {
            new XmlSiteMapReader(VALID_XML_FILE_PATH, null);
        }

        /// <summary>
        /// Test the <c>XmlSiteMapReader(String, String)</c> with empty string argument. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestXmlSiteMapReaderStringStringEmptyA()
        {
            new XmlSiteMapReader("  ", VALID_XSD_FILE_PATH);
        }

        /// <summary>
        /// Test the <c>XmlSiteMapReader(String, String)</c> with empty string argument. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestXmlSiteMapReaderStringStringEmptyB()
        {
            new XmlSiteMapReader(VALID_XML_FILE_PATH, "  ");
        }

        /// <summary>
        /// Test the <c>XmlSiteMapReader(String, String)</c> with not exist file path string. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestXmlSiteMapReaderStringStringNotExistXml()
        {
            new XmlSiteMapReader(NOT_EXIST_XML_FILE_PATH, VALID_XSD_FILE_PATH);
        }

        /// <summary>
        /// Test the <c>XmlSiteMapReader(String, String)</c> with not exist file path. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestXmlSiteMapReaderStringStringNotExistXsd()
        {
            new XmlSiteMapReader(VALID_XML_FILE_PATH, NOT_EXIST_XSD_FIlE_PATH);
        }

        /// <summary>
        /// Accuracy test of the <c>XmlSiteMapReader(String, String)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestXmlSiteMapReaderStringStringAccuracy()
        {
            reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            // Verify.
            Assert.IsNotNull(reader, "The XmlSiteMapReader instance should be created.");
        }

        /// <summary>
        /// Test the <c>Read()</c> method when the given xml file does not meet the xsd schema.
        /// Expect SiteMapReadException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapReadException))]
        public void TestReadInvalidFormatXml()
        {
            reader = new XmlSiteMapReader(INVALID_FORMAT_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            reader.Read();
        }

        /// <summary>
        /// Test the <c>Read()</c> method when the given xml file contains duplicate defined nodes.
        /// Expect SiteMapReadException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapReadException))]
        public void TestReadDuplicateNodes()
        {
            reader = new XmlSiteMapReader(DUPLICATE_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            reader.Read();
        }

        /// <summary>
        /// Test the <c>Read()</c> method when the given xml file does not contains defined nodes.
        /// Expect SiteMapReadException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapReadException))]
        public void TestReadNotDefinedNodes()
        {
            reader = new XmlSiteMapReader(NOT_DEFINED_NODE_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            reader.Read();
        }

        /// <summary>
        /// Accuracy test of the <c>Read()</c> method. The SiteMap instance is returned.
        /// </summary>
        [Test]
        public void TestReadAccuracy()
        {
            SiteMap ret = reader.Read();

            // Verify.
            Assert.IsNotNull(ret, "The SiteMap instance should be returned.");
        }

    }
}