using System;
using TopCoder.Security.Authorization;

namespace TopCoder.Web.SiteMap.Authorization
{
    /// <summary>
    /// This class implements the INodeAuthorization interface to authorize a user credentials
    /// to a specified site map node using the Authorization 2.0 component.
    /// <p>
    /// The actual permissions for a node should be configured outside the component with the
    /// Authorization component. Based on this configured permissions an IAuthorizationEntity
    /// is authorized or not access to a specific site map node.
    /// </p>
    /// <p>
    /// This class can be provided with an AuthorizationManager and an IAuthorizationEntity to
    /// use or it will read the keys from the configuration file and create the instances using
    /// the Object Factory component. It will also read from the configuration file principal and
    /// resource names which it will retrieve from the Authorization component configured persistence.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class NodeAuthorization : INodeAuthorization
    {

        /// <summary>
        /// Represents the name of the object_factory_namespace property in the config file.
        /// </summary>
        private const string OBJECT_FACTORY_PROPERTY = "object_factory_namespace";

        /// <summary>
        /// Represents the name of the authorization_manager_key property in the config file.
        /// </summary>
        private const string AUTHORIZATION_MANAGER_KEY_PROPERTY = "authorization_manager_key";

        /// <summary>
        /// Represents the name of the authorization_entity_key property in the config file.
        /// </summary>
        private const string AUTHORIZATION_ENTITY_KEY_PROPERTY = "authorization_entity_key";

        /// <summary>
        /// Represents the name of the policy_decision_aggregator_key property in the config file.
        /// </summary>
        private const string POLICY_DECISION_AGGREGATOR_KEY_PROPERTY = "policy_decision_aggregator_key";

        /// <summary>
        /// Represents the name of the principal_context_type property in the config file.
        /// </summary>
        private const string PRINCIPAL_CONTEXT_TYPE_PROPERTY = "principal_context_type";

        /// <summary>
        /// Represents the name of the resource_context_type property in the config file.
        /// </summary>
        private const string RESOURCE_CONTEXT_TYPE_PROPERTY = "resource_context_type";

        /// <summary>
        /// <p>
        /// The AuthorizationManager to use for authorization. The authorization persistence used
        /// can be changed through the Authorization component.Used to get the principal and resource
        /// contexts and to authorize access.
        /// </p>
        /// <p>
        /// Set in the constructor to given parameter or created using a configured Object Factory key
        /// and not changed afterwards.Can not be null.
        /// </p>
        /// </summary>
        private readonly AuthorizationManager authorizationManager;

        /// <summary>
        /// <p>
        /// The IAuthorizatioEntity to be used for nodes authorization. One such instance will be used
        /// to authorize access to all site map nodes.Used in the IsAccesible method.
        /// </p>
        /// <p>
        /// Set in the constructor to given parameter or created using a configured Object Factory key
        /// and Not changed afterwards.Can not be null.
        /// </p>
        /// </summary>
        private readonly IAuthorizationEntity authorizationEntity;

        /// <summary>
        /// <p>
        /// The principal action context type. The name can be configured to something like &quot;user&quot;.
        /// This should be taken into account when configuring the nodes credentials with the Authorization
        /// component.
        /// </p>
        /// <p>
        /// The configured name is used to get the actual instance from the authorization persistence and not
        /// changed afterwards. Can not be null.
        /// </p>
        /// </summary>
        private readonly IActionContextType principalType;

        /// <summary>
        /// <p>
        /// The resource action context type. The name can be configured to something like &quot;node&quot; and
        /// should be taken into account when configuring the nodes credentials with the Authorization component.
        /// </p>
        /// <p>
        /// The configured name is used to get the actual instance from the authorization persistence. Set in
        /// the constructor and not changed afterwards. Can not be null.
        /// </p>
        /// </summary>
        private readonly IActionContextType resourceType;

        /// <summary>
        /// <p>
        /// The policy decision aggregator to use for authorization. Note that the actual implementation used
        /// will determine the AND, OR logical operations perform among the policies defined with the
        /// Authorization Component.
        /// </p>
        /// <p>
        /// Created in the constructor using the configured key and Object Factory and not changed afterwards.
        /// </p>
        /// </summary>
        private readonly IPolicyDecisionAggregator policyDecisionAggregator;

        /// <summary>
        /// <p>
        /// Default configuration namespace.
        /// </p>
        /// </summary>
        public const string Namespace = "TopCoder.Web.SiteMap.Authorization";

        /// <summary>
        /// <p>
        /// Create a new <c>NodeAuthorization</c> instance with default nameSpace.
        /// </p>
        /// <p>Calls over load constructor with default configuration namespace.</p>
        /// </summary>
        /// <exception cref="SiteMapConfigurationException">
        /// If any problem with configuration file or if can not create objects.
        /// </exception>
        public NodeAuthorization() : this(Namespace)
        {
        }

        /// <summary>
        /// <p>
        /// Create a new <c>NodeAuthorization</c> instance with given nameSpace.
        /// </p>
        /// <p>
        /// Reads from the configuration file the keys to create the AuthorizationManger, IAuthorizationEntity
        /// and the IPolicyDecisionAggregator and uses the Object Factory to actually create the objects.
        /// </p>
        /// <p>
        /// It will also read from the configuration file the principal and resource context type names and
        /// retrieve the objects from the Authorization persistence.
        /// </p>
        /// <p>
        /// All parameters used in this method in the configuration file are as below.
        /// <table>
        ///   <hr>
        ///       <th>Name</th>
        ///       <th>Required</th>
        ///   </hr>
        ///   <tr>
        ///       <td>object_factory_namespace</td>
        ///       <td>False</td>
        ///   </tr>
        ///   <tr>
        ///       <td>authorization_manager_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>authorization_entity_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>policy_decision_aggregator_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>principal_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>resource_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        /// </table>
        /// </p>
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace</param>
        /// <exception cref="ArgumentNullException">If the given nameSpace is null.</exception>
        /// <exception cref="ArgumentException">If the give nameSpace is empty string.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// If any problem with configuration file or if can not create objects.
        /// </exception>
        public NodeAuthorization(string nameSpace)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNullOrEmpty(nameSpace, "nameSpace");

            // initialize the authorizationManager member.
            this.authorizationManager = InitializeAuthorizationManager(nameSpace);

            // initialize the authorizationEntity member.
            this.authorizationEntity = InitializeAuthorizationEntity(nameSpace);

            // initialize the policyDecisionAggregator member.
            this.policyDecisionAggregator = InitializePolicyDecisionAggregator(nameSpace);

            // initialize the principalType member.
            this.principalType = InitializePrincipalType(nameSpace);

            // initialize the resourceType member.
            this.resourceType = InitializeResourceType(nameSpace);
        }

        /// <summary>
        /// <p>Create a new <c>NodeAuthorization</c> instance with given IAuthorizationEntity. The default
        /// namespace is used to create the AuthorizationManager, IPolicyDecisionAggregator and two action
        /// context types.
        /// </p>
        /// <p>
        /// All parameters used in this method in the configuration file are as below.
        /// <table>
        ///   <hr>
        ///       <th>Name</th>
        ///       <th>Required</th>
        ///   </hr>
        ///   <tr>
        ///       <td>object_factory_namespace</td>
        ///       <td>False</td>
        ///   </tr>
        ///   <tr>
        ///       <td>authorization_manager_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>policy_decision_aggregator_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>principal_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>resource_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        /// </table>
        /// </p>
        /// </summary>
        /// <param name="authorizationEntity">
        /// The IAuthorization entity to plug instead of the configured one.
        /// </param>
        /// <exception cref="ArgumentNullException">If the given parameter is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// If any problem with configuration file or if can not create objects.
        /// </exception>
        public NodeAuthorization(IAuthorizationEntity authorizationEntity)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(authorizationEntity, "authorizationEntity");

            this.authorizationEntity = authorizationEntity;

            // initialize the authorizationManager member.
            this.authorizationManager = InitializeAuthorizationManager(Namespace);

            // initialize the policyDecisionAggregator member.
            this.policyDecisionAggregator = InitializePolicyDecisionAggregator(Namespace);

            // initialize the principalType member.
            this.principalType = InitializePrincipalType(Namespace);

            // initialize the resourceType member.
            this.resourceType = InitializeResourceType(Namespace);
        }

        /// <summary>
        /// <p>Create a new <c>NodeAuthorization</c> instance with given AuthorizationManager. The default
        /// namespace is used to create the IAuthorizationEntity, IPolicyDecisionAggregator and two action
        /// context types.
        /// </p>
        /// <p>
        /// All parameters used in this method in the configuration file are as below.
        /// <table>
        ///   <hr>
        ///       <th>Name</th>
        ///       <th>Required</th>
        ///   </hr>
        ///   <tr>
        ///       <td>object_factory_namespace</td>
        ///       <td>False</td>
        ///   </tr>
        ///   <tr>
        ///       <td>authorization_entity_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>policy_decision_aggregator_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>principal_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>resource_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        /// </table>
        /// </p>
        /// </summary>
        /// <param name="authorizationManager">The Authorization to use.</param>
        /// <exception cref="ArgumentNullException">If the given parameter is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// If any problem with configuration file or if can not create objects.
        /// </exception>
        public NodeAuthorization(AuthorizationManager authorizationManager)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(authorizationManager, "authorizationManager");

            this.authorizationManager = authorizationManager;

            // initialize the authorizationEntity member.
            this.authorizationEntity = InitializeAuthorizationEntity(Namespace);

            // initialize the policyDecisionAggregator member.
            this.policyDecisionAggregator = InitializePolicyDecisionAggregator(Namespace);

            // initialize the principalType member.
            this.principalType = InitializePrincipalType(Namespace);

            // initialize the resourceType member.
            this.resourceType = InitializeResourceType(Namespace);

        }

        /// <summary>
        /// <p>Create a new <c>NodeAuthorization</c> instance with given IAuthorizationEntity and
        /// AuthorizationManager. The default namespace is used to create the IPolicyDecisionAggregator
        /// and two action context types.
        /// </p>
        /// <p>
        /// All parameters used in this method in the configuration file are as below.
        /// <table>
        ///   <hr>
        ///       <th>Name</th>
        ///       <th>Required</th>
        ///   </hr>
        ///   <tr>
        ///       <td>object_factory_namespace</td>
        ///       <td>False</td>
        ///   </tr>
        ///   <tr>
        ///       <td>policy_decision_aggregator_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>principal_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>resource_context_type</td>
        ///       <td>True</td>
        ///   </tr>
        /// </table>
        /// </p>
        /// </summary>
        /// <param name="authorizationEntity">
        /// The IAuthorization entity to plug instead of the configured one.</param>
        /// <param name="authorizationManager">The Authorization to use.</param>
        /// <exception cref="ArgumentNullException">If the either given parameter is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// If any problem with configuration file or if can not create objects.
        /// </exception>
        public NodeAuthorization(
            IAuthorizationEntity authorizationEntity, AuthorizationManager authorizationManager)
        {
            // check parameters
            SiteMapHelper.ValidateNotNull(authorizationEntity, "authorizationEntity");
            SiteMapHelper.ValidateNotNull(authorizationManager,"authorizationManager");

            this.authorizationEntity = authorizationEntity;
            this.authorizationManager = authorizationManager;

            // initialize the policyDecisionAggregator member.
            this.policyDecisionAggregator = InitializePolicyDecisionAggregator(Namespace);

            // initialize the principalType member.
            this.principalType = InitializePrincipalType(Namespace);

            // initialize the resourceType member.
            this.resourceType = InitializeResourceType(Namespace);
        }


        /// <summary>
        /// <p>This method will determine if access is granted to the specified node based on the configured
        /// permissions and the authorization entity credentials.
        /// </p>
        /// </summary>
        /// <param name="node">The node to check if the specified entity is authorized.</param>
        /// <returns>True if authorized; false otherwise.</returns>
        /// <exception cref="ArgumentNullException">If the given parameter is null.</exception>
        /// <exception cref="NodeAuthorizationException">
        /// To wrap exceptions from Authorization Component.
        /// </exception>
        public bool IsAccessible(SiteMapNode node)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(node, "node");

            try
            {
                // get the principal action context
                IActionContext principalActionContext = authorizationManager.GetActionContext(
                    principalType, authorizationEntity.PrincipalName);

                // get the action of this class.
                IAction action = authorizationManager.Persistence.GetAction(authorizationEntity.ActionName);

                // get the resource action context.
                IActionContext resourceActionContext
                    = authorizationManager.GetActionContext(resourceType, node.Name);

                // create the action contexts for authorization.
                ActionContexts contexts = new ActionContexts();
                contexts[principalType] = principalActionContext;
                contexts[resourceType] = resourceActionContext;

                return authorizationManager.Authorize(action, contexts, policyDecisionAggregator);
            }
            catch(Exception e)
            {
                throw new NodeAuthorizationException("error while Authorize the given node.", e);
            }
        }

        /// <summary>
        /// A helper to return an AuthorizationManager instance to initialize the authorizationManager
        /// member.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <returns>The created instance.</returns>
        private AuthorizationManager InitializeAuthorizationManager(string nameSpace)
        {
            // get the object factory namespace.
            string objectFactoryNamespace
                = SiteMapHelper.GetValue(nameSpace, OBJECT_FACTORY_PROPERTY, false);

            // create the authorizationManager member.
            string authorizationManagerKey
                = SiteMapHelper.GetValue(nameSpace, AUTHORIZATION_MANAGER_KEY_PROPERTY, true);

            return SiteMapHelper.CreateInstance(authorizationManagerKey, objectFactoryNamespace,
                typeof(AuthorizationManager)) as AuthorizationManager;
        }

        /// <summary>
        /// A helper to return an IAuthorizationEntity instance to initialize the authorizationEntity
        /// member.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <returns>The created instance.</returns>
        private IAuthorizationEntity InitializeAuthorizationEntity(string nameSpace)
        {
            // get the object factory namespace.
            string objectFactoryNamespace
                = SiteMapHelper.GetValue(nameSpace, OBJECT_FACTORY_PROPERTY, false);

            // create the authorizationEntity member.
            string authorizationEntityKey
                = SiteMapHelper.GetValue(nameSpace, AUTHORIZATION_ENTITY_KEY_PROPERTY, true);

            return SiteMapHelper.CreateInstance(authorizationEntityKey,
                objectFactoryNamespace, typeof(IAuthorizationEntity)) as IAuthorizationEntity;
        }

        /// <summary>
        /// A helper to return an IPolicyDecisionAggregator instance to initialize the
        /// policyDecisionAggregator member.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <returns>The created instance.</returns>
        private IPolicyDecisionAggregator InitializePolicyDecisionAggregator(string nameSpace)
        {
            // get the object factory namespace.
            string objectFactoryNamespace
                = SiteMapHelper.GetValue(nameSpace, OBJECT_FACTORY_PROPERTY, false);

            // create the policyDecisionAggregator member.
            string policyDecisionAggregatorKey
                = SiteMapHelper.GetValue(nameSpace, POLICY_DECISION_AGGREGATOR_KEY_PROPERTY, true);

            return SiteMapHelper.CreateInstance(policyDecisionAggregatorKey,
                objectFactoryNamespace, typeof(IPolicyDecisionAggregator)) as IPolicyDecisionAggregator;
        }

        /// <summary>
        /// A helper to return an IActionContextType instance to initialize the
        /// resourceType member.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <returns>The created instance.</returns>
        private IActionContextType InitializeResourceType(string nameSpace)
        {
            // create the resourceType member.
            string resourceTypeString
                = SiteMapHelper.GetValue(nameSpace, RESOURCE_CONTEXT_TYPE_PROPERTY, true);

            return authorizationManager.Persistence.GetActionContextType(resourceTypeString);
        }

        /// <summary>
        /// A helper to return an IActionContextType instance to initialize the
        /// principalType member.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <returns>The created instance.</returns>
        private IActionContextType InitializePrincipalType(string nameSpace)
        {
            // create the principalType member.
            string principalTypeString
                = SiteMapHelper.GetValue(nameSpace, PRINCIPAL_CONTEXT_TYPE_PROPERTY, true);

            return authorizationManager.Persistence.GetActionContextType(principalTypeString);
        }
    }
}