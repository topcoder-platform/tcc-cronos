using System;
using System.Collections;

namespace TopCoder.Web.SiteMap
{

    /// <summary>
    /// <p>This class abstracts a site map, it simply holds a reference to the root site map node.</p>
    /// <p>
    /// A site map can be created and managed programmatically or it can be created by a ISiteMapReader
    /// implementation.
    /// </p>
    /// <p>
    /// Although, it is possible to have more then one root node in the site map, due to the multiple
    /// parent functionality (we can have more then one node with no parents), the site map should be
    /// constructed with one root node, that is a node that has no parent nodes.
    /// </p>
    /// <p>
    /// It also defines a convenience method that retrieves a SiteMapNode by its title from the site
    /// map hierarchy.
    /// </p>
    /// </summary>
    /// <remarks>
    /// <p>
    /// Thread safety : This class is thread safe. It locks on this inside the RootNode property.
    /// </p>
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class SiteMap
    {
        /// <summary>
        /// <p>
        /// The root site map node. Each site map must define one root node. The root node should have
        /// no parents.
        /// </p>
        /// <p>
        /// Set in the constructor and accessed in its associated property. Can not be null.
        /// </p>
        /// </summary>
        private SiteMapNode root;

        /// <summary>
        /// <p>Returns or sets the root site map node.</p>
        /// </summary>
        /// <value>
        /// The root site map node.
        /// </value>
        public SiteMapNode RootNode
        {
            get
            {
                lock (this)
                {
                    return root;
                }
            }

            set
            {
                lock (this)
                {
                    this.root = value;
                }
            }
        }

        /// <summary>
        /// <p>Create a new <c>SiteMap</c> with given root.</p>
        /// <p>Sets the attribute to the parameter value.</p>
        /// </summary>
        /// <param name="rootNode">The site map root node.</param>
        /// <exception cref="ArgumentNullException">If parameter is null.</exception>
        public SiteMap(SiteMapNode rootNode)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(rootNode, "rootNode");

            this.root = rootNode;
        }

        /// <summary>
        /// <p>
        /// This method will return the site map node from the map, with the specified name. If the
        /// constructed site map contains more than one node with the same name, the first match will
        /// be returned.
        /// </p>
        /// <p>For implementation guidelines please refer to the component specifications.</p>
        /// </summary>
        /// <param name="name">Reurns the SiteMapNode if found, null otherwise.</param>
        /// <returns>The name of the node to look for.</returns>
        /// <exception cref="ArgumentNullException">If parameter is null.</exception>
        /// <exception cref="ArgumentException">If parameter is empty string.</exception>
        public SiteMapNode SelectSingleNode(string name)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNullOrEmpty(name, "name");

            return GetSingleNodeFromAncestor(RootNode, name);
        }

        /// <summary>
        /// <p>
        /// This method will return the site map node from the map, with the specified name. If the
        /// constructed site map contains more than one node with the same name, the first match will
        /// be returned.
        /// </p>
        /// <p>
        /// For implementation guidelines please refer to the component specifications.
        /// </p>
        /// </summary>
        /// <param name="name">The name of the node to look for</param>
        /// <returns>Reurns the SiteMapNode array of found nodes.</returns>
        /// <exception cref="ArgumentNullException">If parameter is null.</exception>
        /// <exception cref="ArgumentException">If parameter is empty string.</exception>
        public SiteMapNode[] SelectNodes(string name)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNullOrEmpty(name, "name");

            ArrayList ret = new ArrayList();

            GetNodesFromAncestor(RootNode, name, ret);

            return ret.ToArray(typeof(SiteMapNode)) as SiteMapNode[];
        }

        /// <summary>
        /// A helper method to retrieve a single from the SiteMap. The the name of the node to retrieve
        /// and the root of the SiteMap are given.
        /// </summary>
        /// <param name="ancestor">The root of the SiteMap</param>
        /// <param name="name">The name of the node to retrieve.</param>
        /// <returns>The retrieved node.</returns>
        private SiteMapNode GetSingleNodeFromAncestor(SiteMapNode ancestor, string name)
        {
            if (ancestor.Name.Equals(name))
            {
                return ancestor;
            }

            // look for the node in the children of the ancestor.
            foreach (SiteMapNode node in ancestor.Children)
            {
                SiteMapNode ret = GetSingleNodeFromAncestor(node, name);

                if (ret != null)
                {
                    // if any match node is found, return.
                    return ret;
                }
            }
            return null;

        }

        /// <summary>
        /// A helper method to retrieve a node collection from the SiteMap. The the name of the nodes to retrieve
        /// and the root of the SiteMap are given.
        /// </summary>
        /// <param name="ancestor">The root of the SiteMap</param>
        /// <param name="name">The name of the node to retrieve.</param>
        /// <param name="matches">The found nodes list.</param>
        private void GetNodesFromAncestor(SiteMapNode ancestor, string name, ArrayList matches)
        {
            if (ancestor.Name.Equals(name))
            {
                matches.Add(ancestor);
            }

            foreach (SiteMapNode node in ancestor.Children)
            {
                GetNodesFromAncestor(node, name, matches);
            }
        }
    }
}