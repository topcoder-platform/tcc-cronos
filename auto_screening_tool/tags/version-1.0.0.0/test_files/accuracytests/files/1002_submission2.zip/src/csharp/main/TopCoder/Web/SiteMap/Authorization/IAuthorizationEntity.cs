namespace TopCoder.Web.SiteMap.Authorization
{
    /// <summary>
    /// <p>
    /// This interface defines a contract to get the principal and action names in the context
    /// of site map node authorization model.
    /// </p>
    /// <p>
    /// Implementers should provide the principal name and an action name specific to the context
    /// they want to provide authorization for.
    /// </p>
    /// <p>
    /// This component provides an implementation for this interface which provides the authorization
    /// entity based on the web request IPrincipal.
    /// </p>
    /// </summary>
    /// <remarks>
    /// Thread safety:Implementations of this interface are expected to be thread safe.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public interface IAuthorizationEntity
    {
        /// <summary>
        /// <p>Property signature to return principal name.</p>
        /// </summary>
        /// <value>
        /// The name of the principal.
        /// </value>
        string PrincipalName
        {
            get;
        }


        /// <summary>
        /// <p>Property signature to return action name.</p>
        /// </summary>
        /// <value>
        /// The name of the action.
        /// </value>
        string ActionName
        {
            get;
        }

    }
}