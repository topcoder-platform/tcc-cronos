using System;
using System.Collections;

namespace TopCoder.Web.SiteMap
{

    /// <summary>
    /// <p>
    /// A relation represents a parent child relationship between two SiteMapNode objects in the
    /// site map hierarchy. Each of the two nodes will hold a reference to the relation, and will
    /// be aware of their parent and child nodes.
    /// </p>
    /// <p>
    /// A relation object can be instantiated separately for two nodes, as it internally sets itself
    /// as the nodes parent and child relation. Relation objects are also created whenever a new parent
    /// or child node is added to a node. When a parent - child relation is removed the relation reference
    /// is removed from the nodes parent and child relation collections.
    /// </p>
    /// <p>
    /// This class is also responsible for checking whether the intended parent-child relation is valid
    /// or not. A relation between the same node should not be possible, as well as a parent child relation
    /// where the child node is already set as parent to the parent node (no cyclic references).
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class Relation
    {

        /// <summary>
        /// <p>
        /// The site map node that represents the parent in the relation.
        /// </p>
        /// <p>
        /// Set in the constructor, returned by its property. Not changed afterwards. Can not be null.
        /// </p>
        /// </summary>
        private readonly SiteMapNode parent;

        /// <summary>
        /// <p>
        /// The site map node that represents the child in the relation.
        /// </p>
        /// <p>
        /// Set in the constructor, returned by its property. Not changed afterwards. Can not be null.
        /// </p>
        /// </summary>
        private readonly SiteMapNode child;

        /// <summary>
        /// <p>Returns the parent node.</p>
        /// </summary>
        /// <value>
        /// The site map node that represents the parent in the relation.
        /// </value>
        public SiteMapNode Parent
        {
            get
            {
                return parent;
            }
        }

        /// <summary>
        /// <p>Returns the child node.</p>
        /// </summary>
        /// <value>
        /// The site map node that represents the child in the relation.
        /// </value>
        public SiteMapNode Child
        {
            get
            {
                return child;
            }
        }

        /// <summary>
        /// <p>Create a new <c>Relation</c> instance with parent node and child node.</p>
        /// <p>
        /// This constructor will validate if the intended relation is possible. An exception will be
        /// thrown if the parent and child nodes are equal, if they already have this relation defined
        /// or if the intended child node is an ancestor to the intended parent node
        /// (checks IsancestorOf(child, parent)).
        /// </p>
        /// <p>
        /// Sets the attributes to the parameter values. Adds itself to the parent relations of the
        /// child node and to the child relations of the parent node.
        /// </p>
        /// </summary>
        /// <param name="parent">The parent node in the relation.</param>
        /// <param name="child">The child node in the relation.</param>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        /// <exception cref="InvalidNodeRelationException">
        /// If the parent and child nodes are equal, if they already have this relation defined
        /// or if the intended child node is an ancestor to the intended parent node
        /// (checks IsancestorOf(child, parent.Parents)).
        /// </exception>
        public Relation(SiteMapNode parent, SiteMapNode child)
        {
            // check parameters.
            SiteMapHelper.ValidateNotNull(parent, "parent");
            SiteMapHelper.ValidateNotNull(child, "child");

            if (parent.Equals(child))
            {
                throw new InvalidNodeRelationException(
                    "The given parent node and child node should not be equal.");
            }

            if ((new ArrayList(parent.Children)).Contains(child)
                || ((new ArrayList(child.Parents)).Contains(parent)))
            {
                throw new InvalidNodeRelationException(
                    "They already have this relation defined.");
            }

            if (IsAncestorOf(child, parent))
            {
                throw new InvalidNodeRelationException(
                    "the intended child node is an ancestor to the intended parent node.");
            }

            this.parent = parent;
            this.child = child;

            this.parent.AddChildRelation(this);

            this.child.AddParentRelation(this);
        }

        /// <summary>
        /// <p>
        /// This method checks if the test node(child) is actually an ancestor of the parent node,
        /// in order to avoid cycles in the object graph.
        /// </p>
        /// <p>
        /// This method will recursivelly check if the test node is in the parent node parents array
        /// and returns true if it is. Otherwise for each node in the array it continues recursivelly
        /// for its parents. For more details please see the algorithms section of the component
        /// specifications document.
        /// </p>
        /// </summary>
        /// <param name="test">The node to check if its ancestor of parent.</param>
        /// <param name="parent">The node for which to check if its parents include the test node.</param>
        /// <returns>True if test is ancestor for the specified parent node.</returns>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        private bool IsAncestorOf(SiteMapNode test, SiteMapNode parent)
        {
            // check parameters
            SiteMapHelper.ValidateNotNull(test, "test");
            SiteMapHelper.ValidateNotNull(parent, "parent");

            foreach (SiteMapNode node in parent.Parents)
            {
                if (node.Equals(test))
                {
                    return true;
                }

                if (IsAncestorOf(test, node))
                {
                    return true;
                }
            }

            return false;
        }
    }
}