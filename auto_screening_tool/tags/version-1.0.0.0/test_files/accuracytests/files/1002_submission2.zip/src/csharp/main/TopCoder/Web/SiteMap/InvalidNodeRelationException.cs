using System;
using System.Runtime.Serialization;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// <p>
    /// This exception is used to signal invalid relations between two site map nodes. Thrown by the
    /// Relation class constructor when the relation is already defined or if the two nodes are actually
    /// the same or if the intended child is already an ancestor of the intended parent.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [Serializable]
    public class InvalidNodeRelationException : SiteMapException
    {
        /// <summary>
        /// Creates a new instance of <c>InvalidNodeRelationException</c> class.
        /// </summary>
        public InvalidNodeRelationException()
        {
        }

        /// <summary>
        /// Creates a new instance of <c>InvalidNodeRelationException</c> class. The detailed error message is
        /// given.
        /// <p>
        /// The string argument is not checked - it may be null or empty.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        public InvalidNodeRelationException(string message) : base(message)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>InvalidNodeRelationException</c> class. The detailed error message and
        /// the original innerException of this error are given.
        /// <p>
        /// Both arguments are not checked.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        /// <param name="innerException">The original innerException of this error.</param>
        public InvalidNodeRelationException(string message, Exception innerException) : base(message, innerException)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>InvalidNodeRelationException</c> class with deserialization.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source and destination.</param>
        protected InvalidNodeRelationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}