using System;
using NUnit.Framework;
using TopCoder.Util.ConfigurationManager;
using TopCoder.Web.SiteMap;
using TopCoder.Web.SiteMap.Authorization;
using TopCoder.Web.SiteMap.Readers;

namespace TopCoder.Web.UI.WebControl.Menu.Source
{

    /// <summary>
    /// Tests the functionality and error cases of the <c>MenuSiteMapDataSource</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class MenuSiteMapDataSourceTestCase
    {

        /// <summary>
        /// Represents a ConfigManager instance used in the test.
        /// </summary>
        private ConfigManager manager = ConfigManager.GetInstance();

        /// <summary>
        /// Represents the file name template of the namespace used to create instance.
        /// </summary>
        private const string FILE_NAME_TEMP = "../../test_files/SiteMapDataSource/{0}.xml";

        /// <summary>
        /// Represents a valid file name to create instance.
        /// </summary>
        private const string VALID_FILE = "SiteMapDataSource";

        /// <summary>
        /// Represents a missing object_factory_namespace property configuration file name.
        /// </summary>
        private const string MISSING_OBJECT_FACTORY_NAMESPACE = "Missing_object_factory_namespace";

        /// <summary>
        /// Represents an empty object_factory_namespace property configuration file name.
        /// </summary>
        private const string EMPTY_OBJECT_FACTORY_NAMESPACE = "Empty_object_factory_namespace";

        /// <summary>
        /// Represents a missing site_map_reader_key property configuration file name.
        /// </summary>
        private const string MISSING_SITE_MAP_READER_KEY = "Missing_site_map_reader_key";

        /// <summary>
        /// Represents an empty site_map_reader_key property configuration file name.
        /// </summary>
        private const string EMPTY_SITE_MAP_READER_KEY = "Empty_site_map_reader_key";

        /// <summary>
        /// Represents a missing node_authorization_key property configuration file name.
        /// </summary>
        private const string MISSING_NODE_AUTHORIZATION_KEY = "Missing_node_authorization_key";

        /// <summary>
        /// Represents an empty node_authorization_key property configuration file name.
        /// </summary>
        private const string EMPTY_NODE_AUTHORIZATION_KEY = "Empty_node_authorization_key";

        /// <summary>
        /// Represents a valid nameSpace in the configuration file.
        /// </summary>
        private const string VALID_NAME_SPACE = "TopCoder.Web.SiteMap";

        /// <summary>
        /// Represents a <c>MenuSiteMapDataSource</c> instance used in the test.
        /// </summary>
        private MenuSiteMapDataSource source;

        /// <summary>
        /// Represents the INodeAuthorization instance used as argument in the test.
        /// </summary>
        private INodeAuthorization nodeAuthorization;

        /// <summary>
        /// Represents a valid xml file path used in the test.
        /// </summary>
        private const string VALID_XML_FILE_PATH = "../../test_files/Readers/SiteMap.xml";

        /// <summary>
        /// Represents a valid xsd file path used in the test.
        /// </summary>
        private const string VALID_XSD_FILE_PATH = "../../test_files/Readers/SiteMap.xsd";

        /// <summary>
        /// Represents the ISiteMapReader instance used as argument in the test.
        /// </summary>
        private ISiteMapReader reader;


        /// <summary>
        /// Sets up the test environment. The test instances are created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            nodeAuthorization = new DisabledNodeAuthorization();

            reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            source = new MenuSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Cleans up the test environment. The test instances are disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            // clear the configuration manager.
            manager.Clear();

            nodeAuthorization = null;

            reader = null;

            source = null;
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource()</c> when the optional property is missing.
        /// The MenuSiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MenuSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The MenuSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource()</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MenuSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource()</c> when the required property is missing.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new MenuSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new MenuSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource()</c> when the required property is missing.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new MenuSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new MenuSiteMapDataSource();
        }

        /// <summary>
        /// Accuracy test of the <c>MenuSiteMapDataSource()</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceAccuracy()
        {
            source = new MenuSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The MenuSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>MenuSiteMapDataSource(String)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestMenuSiteMapDataSourceStringNull()
        {
            new MenuSiteMapDataSource(null as string);
        }

        /// <summary>
        /// Test the <c>MenuSiteMapDataSource(String)</c> with empty string argument. Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestMenuSiteMapDataSourceStringEmpty()
        {
            new MenuSiteMapDataSource("   ");
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(String)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceStringMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MenuSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The MenuSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(String)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceStringEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MenuSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceStringMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new MenuSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceStringEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new MenuSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceStringMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new MenuSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceStringEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new MenuSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Accuracy test of the <c>MenuSiteMapDataSource(String)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceStringAccuracy()
        {
            source = new MenuSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The MenuSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>MenuSiteMapDataSource(INodeAuthorization)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestMenuSiteMapDataSourceINodeAuthorizationNull()
        {
            new MenuSiteMapDataSource(null as INodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(INodeAuthorization)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceINodeAuthorizationMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MenuSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The MenuSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(INodeAuthorization)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceINodeAuthorizationEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MenuSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(INodeAuthorization)</c> when the required property is missing.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceINodeAuthorizationMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new MenuSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(INodeAuthorization)</c> when the required property value
        /// is empty. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceINodeAuthorizationEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new MenuSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Accuracy test of the <c>MenuSiteMapDataSource(INodeAuthorization)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceINodeAuthorizationAccuracy()
        {
            source = new MenuSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The MenuSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>MenuSiteMapDataSource(ISiteMapReader)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestMenuSiteMapDataSourceISiteMapReaderNull()
        {
            new MenuSiteMapDataSource(null as ISiteMapReader);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(ISiteMapReader)</c> when the optional property is missing.
        /// The MenuSiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceISiteMapReaderMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new MenuSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The MenuSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(ISiteMapReader)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceISiteMapReaderEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new MenuSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(ISiteMapReader)</c> when the required property is missing.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceISiteMapReaderMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new MenuSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>MenuSiteMapDataSource(ISiteMapReader)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestMenuSiteMapDataSourceISiteMapReaderEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new MenuSiteMapDataSource(reader);
        }

        /// <summary>
        /// Accuracy test of the <c>MenuSiteMapDataSource(ISiteMapReader)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceISiteMapReaderAccuracy()
        {
            source = new MenuSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>MenuSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestMenuSiteMapDataSourceISiteMapReaderINodeAuthorizationNullA()
        {
            new MenuSiteMapDataSource(null, reader);
        }

        /// <summary>
        /// Test the <c>MenuSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestMenuSiteMapDataSourceISiteMapReaderINodeAuthorizationNullB()
        {
            new MenuSiteMapDataSource(nodeAuthorization, null);
        }

        /// <summary>
        /// Accuracy test of the <c>MenuSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c>.
        /// The instance is created.
        /// </summary>
        [Test]
        public void TestMenuSiteMapDataSourceISiteMapReaderINodeAuthorizationAccuracy()
        {
            source = new MenuSiteMapDataSource(nodeAuthorization, reader);

            // Verify.
            Assert.IsNotNull(source, "The SiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>GetMenu(WebMenuControl)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestGetMenuWebMenuControlNull()
        {
            source.GetMenu(null);
        }

        /// <summary>
        /// Accuracy test of the <c>GetMenu(WebMenuControl)</c>. The MainMenu is returned.
        /// </summary>
        [Test]
        public void TestGetMenuWebMenuControlAccuracy()
        {
            MainMenu ret = source.GetMenu(new WebMenuControl());

            // Verify.
            Assert.IsNotNull(ret, "The MainMenu should be returned.");

            MockSiteMapDataSource mockSource = new MockSiteMapDataSource(nodeAuthorization);

            SiteMapNode root  = mockSource.SiteMap.RootNode;

            // Verify.
            RecursiveVerify(root.Children, ret.MenuItems);
        }


        /// <summary>
        /// A helper method to verify the contents of the given SiteMapNode array and MenuItemCollection.
        /// </summary>
        /// <param name="nodes">The SiteMapNode array to verify.</param>
        /// <param name="menuItems">The MenuItemCollection to verify.</param>
        private void RecursiveVerify(SiteMapNode[] nodes, Menu.MenuItemCollection menuItems)
        {
            Assert.AreEqual(nodes.Length, menuItems.Count,
                "The Count property should be the same as expected.");

            int i= 0;

            foreach (MenuItem item in menuItems)
            {
                SiteMapNode mapNode = nodes[i++];

                // Verify.
                Assert.AreEqual(mapNode.Name, item.Text,
                    "The Name property should be the same as expected.");

                Assert.AreEqual(mapNode.Url, item.Url,
                    "The Url property should be the same as expected.");

                // Verify Recursively.
                RecursiveVerify(mapNode.Children, item.MenuItems);
            }

        }

    }
}
