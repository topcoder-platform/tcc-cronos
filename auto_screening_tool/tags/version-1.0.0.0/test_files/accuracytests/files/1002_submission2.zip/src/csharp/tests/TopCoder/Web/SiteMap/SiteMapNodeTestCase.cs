using System;
using NUnit.Framework;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Tests the functionality and error cases of the <c>SiteMapNode</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class SiteMapNodeTestCase
    {
        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string NAME = "name";

        /// <summary>
        /// <p>The description of the site map node.</p>
        /// </summary>
        private const string DESCRIPTION = "description";

        /// <summary>
        /// <p>The url of the site map node.</p>
        /// </summary>
        private const string URL = "/";


        /// <summary>
        /// Represents the SiteMapNode instance used in the test.
        /// </summary>
        private SiteMapNode node;

        /// <summary>
        /// Sets up the test environment. The test instance is created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            node = new SiteMapNode(NAME, DESCRIPTION, URL);
        }

        /// <summary>
        /// Cleans up the test environment. The test instance is disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            node = null;
        }

        /// <summary>
        /// Test the <c>SiteMapNode(String, String, String)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapNodeStringStringStringNullA()
        {
            new SiteMapNode(null, DESCRIPTION, URL);
        }

        /// <summary>
        /// Test the <c>SiteMapNode(String, String, String)</c> with empty string argument. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSiteMapNodeStringStringStringEmptyA()
        {
            new SiteMapNode("  ", DESCRIPTION, URL);
        }

        /// <summary>
        /// Test the <c>SiteMapNode(String, String, String)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapNodeStringStringStringNullB()
        {
            new SiteMapNode(NAME, null, URL);
        }

        /// <summary>
        /// Test the <c>SiteMapNode(String, String, String)</c> with empty string argument. This
        /// is allowed. The instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapNodeStringStringStringEmptyB()
        {
            node = new SiteMapNode(NAME, "   ", URL);

            // Verify.
            Assert.IsNotNull(node, "The instance should be created.");
        }

        /// <summary>
        /// Test the <c>SiteMapNode(String, String, String)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSiteMapNodeStringStringStringNullC()
        {
            new SiteMapNode(NAME, DESCRIPTION, null);
        }

        /// <summary>
        /// Test the <c>SiteMapNode(String, String, String)</c> with empty string argument. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSiteMapNodeStringStringStringEmptyC()
        {
            new SiteMapNode(NAME, DESCRIPTION, "   ");
        }

        /// <summary>
        /// Accuracy test of the <c>SiteMapNode(String, String, String)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestSiteMapNodeStringStringStringAccuracy()
        {
            node = new SiteMapNode(NAME, DESCRIPTION, URL);

            // Verify.
            Assert.IsNotNull(node, "The SiteMapNode instance should be created.");

            Assert.AreEqual(node.Name, NAME, "The Name property should be the same as set in arguments.");

            Assert.AreEqual(node.Description, DESCRIPTION,
                "The Description property should be the same as set in arguments.");

            Assert.AreEqual(node.Url, URL, "The Url property should be the same as set in arguments.");

            Assert.AreEqual(node.Parents.Length, 0, "The length of the Parents property should be zero.");

            Assert.AreEqual(node.Children.Length, 0, "The length of the Children property should be zero.");
        }


        /// <summary>
        /// Test the <c>Name</c> property getter. The value of the property is returned.
        /// </summary>
        [Test]
        public void TestNamePropertyGetter()
        {
            string ret = node.Name;

            // Verify.
            Assert.IsNotNull(ret, "The Name property should be returned by the getter.");

            Assert.AreEqual(ret, NAME, "The Name property should be the same as set in arguments.");
        }

        /// <summary>
        /// Test the <c>Name</c> property setter with null value. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNamePropertySetterNull()
        {
            node.Name = null;
        }

        /// <summary>
        /// Test the <c>Name</c> property setter with empty string. Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestNamePropertySetterEmpty()
        {
            node.Name = "   ";
        }

        /// <summary>
        /// Accuracy test of <c>Name</c> property setter. The value of the property is set to the given value.
        /// </summary>
        [Test]
        public void TestNamePropertySetterAccuracy()
        {
            node.Name = NAME + NAME;

            // Verify.
            Assert.AreEqual(node.Name, NAME + NAME, "The Name property should be the same as set in setter.");
        }


        /// <summary>
        /// Test the <c>Description</c> property getter. The value of the property is returned.
        /// </summary>
        [Test]
        public void TestDescriptionPropertyGetter()
        {
            string ret = node.Description;

            // Verify.
            Assert.IsNotNull(ret, "The Description property should be returned by the getter.");

            Assert.AreEqual(ret, DESCRIPTION, "The Description property should be the same as set in arguments.");
        }

        /// <summary>
        /// Test the <c>Description</c> property setter with null value. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestDescriptionPropertySetterNull()
        {
            node.Description = null;
        }

        /// <summary>
        /// Test the <c>Description</c> property setter with empty string.This is allowed. The value
        /// is set to the property.
        /// </summary>
        [Test]
        public void TestDescriptionPropertySetterEmpty()
        {

            // a variable storing the empty string.
            string emptyString = "  ";

            node.Description = emptyString;

            // Verify.
            Assert.AreEqual(node.Description, emptyString,
                "The Description property should be the same as set in setter.");
        }

        /// <summary>
        /// Accuracy test of <c>Description</c> property setter. The value of the property is set to the
        /// given value.
        /// </summary>
        [Test]
        public void TestDescriptionPropertySetterAccuracy()
        {
            node.Description = DESCRIPTION + DESCRIPTION;

            // Verify.
            Assert.AreEqual(node.Description, DESCRIPTION + DESCRIPTION,
                "The Description property should be the same as set in setter.");
        }

        /// <summary>
        /// Test the <c>Url</c> property getter. The value of the property is returned.
        /// </summary>
        [Test]
        public void TestUrlPropertyGetter()
        {
            string ret = node.Url;

            // Verify.
            Assert.IsNotNull(ret, "The Url property should be returned by the getter.");

            Assert.AreEqual(ret, URL, "The Url property should be the same as set in arguments.");
        }

        /// <summary>
        /// Test the <c>Url</c> property setter with null value. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestUrlPropertySetterNull()
        {
            node.Url = null;
        }

        /// <summary>
        /// Test the <c>Url</c> property setter with empty string. Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestUrlPropertySetterEmpty()
        {
            node.Url = "   ";
        }

        /// <summary>
        /// Accuracy test of <c>Url</c> property setter. The value of the property is set to the
        /// given value.
        /// </summary>
        [Test]
        public void TestUrlPropertySetterAccuracy()
        {
            node.Url = URL + URL;

            // Verify.
            Assert.AreEqual(node.Url, URL + URL,
                "The Url property should be the same as set in setter.");
        }

        /// <summary>
        /// Accuracy test of the <c>Parents</c> property. The array value is returned.
        /// </summary>
        [Test]
        public void TestParentsPropertyAccuracy()
        {
            Assert.AreEqual(node.Parents.Length, 0, "The length of the Parents property should be zero.");
        }

        /// <summary>
        /// Accuracy test of the <c>Children</c> property. The array value is returned.
        /// </summary>
        [Test]
        public void TestChildrenPropertyAccuracy()
        {
            Assert.AreEqual(node.Children.Length, 0, "The length of the Children property should be zero.");
        }

        /// <summary>
        /// Test the <c>AddChild(SiteMapNode)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestAddChildSiteMapNodeNull()
        {
            node.AddChild(null);
        }

        /// <summary>
        /// Accuracy test of the <c>AddChild(SiteMapNode)</c>. The node is added to the current node as child.
        /// </summary>
        [Test]
        public void TestAddChildSiteMapNodeAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                node.AddChild(new SiteMapNode(NAME + i, DESCRIPTION, URL));
            }

            // Verify.
            Assert.AreEqual(node.Children.Length, count,
                "The count of the child nodes should be the same as expected :" + count + ".");

        }


        /// <summary>
        /// Test the <c>AddParent(SiteMapNode)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestAddParentSiteMapNodeNull()
        {
            node.AddParent(null);
        }

        /// <summary>
        /// Accuracy test of the <c>AddParent(SiteMapNode)</c>. The node is added to the current node as parent.
        /// </summary>
        [Test]
        public void TestAddParentSiteMapNodeAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                node.AddParent(new SiteMapNode(NAME + i, DESCRIPTION, URL));
            }

            // Verify.
            Assert.AreEqual(node.Parents.Length, count,
                "The count of the Parents nodes should be the same as expected :" + count + ".");
        }

        /// <summary>
        /// Test the <c>AddChildRelation(Relation)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestAddChildRelationNull()
        {
            node.AddChildRelation(null);
        }

        /// <summary>
        /// Accuracy test of the <c>AddChildRelation(Relation)</c>. The relation is added to the current node.
        /// Since this method is used by the Relation class, this case call the Relation constructor to call
        /// this method.
        /// </summary>
        [Test]
        public void TestAddChildRelationAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                // this constructor is calling the AddChildRelation(Relation).
                new Relation(node, new SiteMapNode(NAME + i, DESCRIPTION, URL));
            }

            // Verify.
            Assert.AreEqual(node.Children.Length, count,
                "The count of the child nodes should be the same as expected :" + count + ".");
        }

        /// <summary>
        /// Test the <c>AddParentRelation(Relation)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestAddParentRelationNull()
        {
            node.AddParentRelation(null);
        }

        /// <summary>
        /// Accuracy test of the <c>AddParentRelation(Relation)</c>. The relation is added to the current node.
        /// Since this method is used by the Relation class, this case call the Relation constructor to call
        /// this method.
        /// </summary>
        [Test]
        public void TestAddParentRelationAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                // this constructor is calling the AddChildRelation(Relation).
                new Relation(new SiteMapNode(NAME + i, DESCRIPTION, URL), node);
            }

            // Verify.
            Assert.AreEqual(node.Parents.Length, count,
                "The count of the child nodes should be the same as expected :" + count + ".");
        }

        /// <summary>
        /// Test the <c>RemoveChild(SiteMapNode)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestRemoveChildSiteMapNodeNull()
        {
            node.RemoveChild(null);
        }

        /// <summary>
        /// Accuracy test of the <c>RemoveChild(SiteMapNode)</c>. The node is removed from current node.
        /// </summary>
        [Test]
        public void TestRemoveChildSiteMapNodeAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            // the array storing the child nodes.
            SiteMapNode[] children = new SiteMapNode[count];

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                children[i] = new SiteMapNode(NAME + i, DESCRIPTION, URL);
                node.AddChild(children[i]);
            }

            // Verify.
            Assert.AreEqual(node.Children.Length, count,
                "The child nodes should be added to the current node.");

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                node.RemoveChild(children[i]);
            }

            // Verify.
            Assert.AreEqual(node.Children.Length, 0,
                "The child nodes should be removed from the current node.");
        }

        /// <summary>
        /// Test the <c>RemoveParent(SiteMapNode)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestRemoveParentSiteMapNodeNull()
        {
            node.RemoveParent(null);
        }

        /// <summary>
        /// Accuracy test of the <c>RemoveParent(SiteMapNode)</c>. The node is removed from current node.
        /// </summary>
        [Test]
        public void TestRemoveParentSiteMapNodeAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            // the array storing the parent nodes.
            SiteMapNode[] parents = new SiteMapNode[count];

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                parents[i] = new SiteMapNode(NAME + i, DESCRIPTION, URL);
                node.AddParent(parents[i]);
            }

            // Verify.
            Assert.AreEqual(node.Parents.Length, count,
                "The parent nodes should be added to the current node.");

            // add children to the current node.
            for (int i = 0; i < count; i++)
            {
                node.RemoveParent(parents[i]);
            }

            // Verify.
            Assert.AreEqual(node.Parents.Length, 0,
                "The parent nodes should be removed from the current node.");
        }

        /// <summary>
        /// Test the <c>RemoveChildRelation(Relation)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestRemoveChildRelationNull()
        {
            node.RemoveChildRelation(null);
        }

        /// <summary>
        /// Accuracy test of the <c>RemoveChildRelation(Relation)</c>. The relation is added to the current node.
        /// Since this method is used by the Relation class, this case call the Relation constructor to call
        /// this method.
        /// </summary>
        [Test]
        public void TestRemoveChildRelationAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            Relation[] relations = new Relation[count];

            // add the relations to the current node.
            for (int i = 0; i < count; i++)
            {
                // this constructor is calling the AddChildRelation(Relation).
                relations[i] = new Relation(node, new SiteMapNode(NAME + i, DESCRIPTION, URL));
            }

            // Verify.
            Assert.AreEqual(node.Children.Length, count, "The relations should be added to the current node.");

            // remove the relations from the current node.
            for (int i = 0; i < count; i++)
            {
                node.RemoveChildRelation(relations[i]);
            }

            // Verify.
            Assert.AreEqual(node.Children.Length, 0, "The relations should be removed from the current node.");
        }

        /// <summary>
        /// Test the <c>RemoveParentRelation(Relation)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestRemoveParentRelationNull()
        {
            node.RemoveParentRelation(null);
        }

        /// <summary>
        /// Accuracy test of the <c>RemoveParentRelation(Relation)</c>. The relation is added to the current node.
        /// Since this method is used by the Relation class, this case call the Relation constructor to call
        /// this method.
        /// </summary>
        [Test]
        public void TestRemoveParentRelationAccuracy()
        {
            // a variable storing the count of the added nodes.
            int count = 30;

            Relation[] relations = new Relation[count];

            // add the relations to the current node.
            for (int i = 0; i < count; i++)
            {
                // this constructor is calling the AddChildRelation(Relation).
                relations[i] = new Relation(new SiteMapNode(NAME + i, DESCRIPTION, URL), node);
            }

            // Verify.
            Assert.AreEqual(node.Parents.Length, count, "The relations should be added to the current node.");

            // remove the relations from the current node.
            for (int i = 0; i < count; i++)
            {
                node.RemoveParentRelation(relations[i]);
            }

            // Verify.
            Assert.AreEqual(node.Parents.Length, 0, "The relations should be removed from the current node.");
        }


        /// <summary>
        /// Test the <c>Equals(object)</c> with the valid object. True is returned.
        /// </summary>
        [Test]
        public void TestEqualsObjectReturnTrue()
        {
            // create a same instance for testing.
            SiteMapNode newNode = new SiteMapNode(NAME, DESCRIPTION, URL);

            // Verify.
            Assert.IsTrue(node.Equals(newNode),
                "The two instances should have the same Name, Description and Url properties.");
        }

        /// <summary>
        /// Test the <c>Equals(object)</c> with null object. False is returned.
        /// </summary>
        [Test]
        public void TestEqualsObjectReturnFalseNull()
        {
            // Verify.
            Assert.IsFalse(node.Equals(null), "The two instances should be different.");
        }

        /// <summary>
        /// Test the <c>Equals(object)</c> with different object. False is returned.
        /// </summary>
        [Test]
        public void TestEqualsObjectReturnFalseDifferent()
        {
            SiteMapNode differentNode = new SiteMapNode(NAME + NAME, DESCRIPTION, URL);

            // Verify.
            Assert.IsFalse(node.Equals(differentNode), "The two instances should be different.");
        }
    }
}