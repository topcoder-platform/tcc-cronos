using System;
using TopCoder.Util.ConfigurationManager;
using TopCoder.Util.ObjectFactory;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Defines helper methods used in this component.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    internal sealed class SiteMapHelper
    {
        /// <summary>
        /// Creates a new instance of <c>SiteMapHelper</c> class.
        /// </summary>
        /// <remarks>
        /// This private constructor prevents the creation of a new instance.
        /// </remarks>
        private SiteMapHelper()
        {
        }

        /// <summary>
        /// Validates the value of a variable. The value cannot be <c>null</c>.
        /// </summary>
        /// <param name="value">The value of the variable to be validated.</param>
        /// <param name="name">The name of the variable to be validated.</param>
        /// <exception cref="ArgumentNullException">The value of the variable is <c>null</c>.</exception>
        public static void ValidateNotNull(object value, string name)
        {
            if (value == null)
            {
                throw new ArgumentNullException(name, name + " cannot be null.");
            }
        }

        /// <summary>
        /// Validates the value of a string variable. The value cannot be <c>null</c> or empty string after
        /// trimming.
        /// </summary>
        /// <param name="value">The value of the variable to be validated.</param>
        /// <param name="name">The name of the variable to be validated.</param>
        /// <exception cref="ArgumentNullException">The value of the variable is <c>null</c>.</exception>
        /// <exception cref="ArgumentException">The value of the variable is empty string.</exception>
        public static void ValidateNotNullOrEmpty(string value, string name)
        {
            ValidateNotNull(value, name);

            if (value.Trim().Length == 0)
            {
                throw new ArgumentException(name + " cannot be empty string.", name);
            }
        }

        /// <summary>
        /// Gets a string value from the configuration using the given namespace and property name. The
        /// string value cannot be empty string.
        /// </summary>
        /// <param name="nameSpace">The namespace where the property value is read.</param>
        /// <param name="propertyName">The property name where the property value is read.</param>
        /// <param name="mandatory">A flag indicating whether the property is mandatory.</param>
        /// <returns>The string value of the given property.</returns>
        /// <exception cref="SiteMapConfigurationException">The string value is empty string; or the
        /// property is missing in configuration if it is mandatory.</exception>
        public static string GetValue(string nameSpace, string propertyName, bool mandatory)
        {
            string value = ConfigManager.GetInstance().GetValue(nameSpace, propertyName);

            if ((value != null) && (value.Trim().Length == 0))
            {
                throw new SiteMapConfigurationException("Property '" + propertyName + "' cannot be empty.");
            }

            if ((value == null) && mandatory)
            {
                throw new SiteMapConfigurationException("Property '" + propertyName + "' is mandatory.");
            }

            return value;
        }

        /// <summary>
        /// Creates a new instance of the class. The type name and assembly name of the class is given. The
        /// created instance must be an instance of the expected type.
        /// </summary>
        /// <param name="keyName">The key of the instance in the object factory file.</param>
        /// <param name="nameSpace">The nameSpace of the object factory.</param>
        /// <returns>A new instance of the given class.</returns>
        /// <exception cref="SiteMapConfigurationException">A new instance of the given type cannot be
        /// created</exception>
        public static object CreateInstance(string keyName, string nameSpace, Type expected)
        {
            object createdObject = null;

            try
            {
                // create Object Factory for config namespace
                ObjectFactory factory = (nameSpace == null) ?
                    ObjectFactory.GetDefaultObjectFactory() : new ConfigurationObjectFactory(nameSpace);

                // create the instance.
                createdObject = factory.CreateDefinedObject(keyName);
            }
            catch(Exception e)
            {
                throw new SiteMapConfigurationException("error occured while create the instance.", e);
            }

            // Check if the expected is assignable from the retrieved type
            if (!expected.IsInstanceOfType(createdObject))
            {
                throw new SiteMapConfigurationException("The type should be sub-class of " +
                    expected.ToString() + ".");
            }

            return createdObject;
        }
    }
}