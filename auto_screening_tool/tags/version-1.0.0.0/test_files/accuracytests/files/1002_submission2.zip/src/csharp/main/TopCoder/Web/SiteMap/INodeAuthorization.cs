using System;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// <p>
    /// This interface defines a contract for the authorization mechanism used to determine access to
    /// a specific site map node.
    /// </p>
    /// <p>
    /// It defines a single method that will return true if access to the specified node is granted.
    /// </p>
    /// <p>
    /// This component provides an implementation of this interface that integrates with Authorization
    /// Manager 2.0 component to authorize access to a node.
    /// </p>
    /// <p>
    /// Implementations of this interface are created by or plugged into AbstractSiteMapDataSource and
    /// are used by derived classes when converting the site map to a control specific object model
    /// data source, to determine the nodes that will be included.
    /// </p>
    /// </summary>
    /// <remarks>
    /// Implementations of this interface are expected to be thread safe. Both implementations of this
    /// interface, provided by this component, are thread safe.
    /// </remarks>
    /// <author>saevio</author>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public interface INodeAuthorization
    {
        /// <summary>
        /// <p>
        /// Simply the method signature. This method should return true if access to the specified
        /// node is granted.
        /// </p>
        /// </summary>
        /// <param name="node">The node to check if it is accessible (authorized)</param>
        /// <returns>True if it is; false otherwise.</returns>
        /// <exception cref="ArgumentNullException">If the given parameter is null.</exception>
        /// <exception cref="NodeAuthorizationException">
        /// This exception to signal any problems and can not determine access rights.
        /// </exception>
        bool IsAccessible(SiteMapNode node);
    }
}