using System;
using System.Runtime.Serialization;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// <p>
    /// Base exception class for exceptions thrown by this component.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [Serializable]
    public class SiteMapException : ApplicationException
    {
        /// <summary>
        /// Creates a new instance of <c>SiteMapException</c> class.
        /// </summary>
        public SiteMapException()
        {
        }

        /// <summary>
        /// Creates a new instance of <c>SiteMapException</c> class. The detailed error message is
        /// given.
        /// <p>
        /// The string argument is not checked - it may be null or empty.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        public SiteMapException(string message) : base(message)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>SiteMapException</c> class. The detailed error message and
        /// the original innerException of this error are given.
        /// <p>
        /// Both arguments are not checked.
        /// </p>
        /// </summary>
        /// <param name="message">A detailed error message describing the nature of the error.</param>
        /// <param name="innerException">The original innerException of this error.</param>
        public SiteMapException(string message, Exception innerException) : base(message, innerException)
        {
        }

        /// <summary>
        /// Creates a new instance of <c>SiteMapException</c> class with deserialization.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source and destination.</param>
        protected SiteMapException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}