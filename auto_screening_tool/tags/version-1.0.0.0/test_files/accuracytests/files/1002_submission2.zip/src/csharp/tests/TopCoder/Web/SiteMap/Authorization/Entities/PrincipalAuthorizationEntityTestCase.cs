using System;
using System.Security.Principal;
using NUnit.Framework;

namespace TopCoder.Web.SiteMap.Authorization.Entities
{
    /// <summary>
    /// Tests the functionality and error cases of the <c>PrincipalAuthorizationEntity</c> class.
    /// Since this class is immutable, the properties are tested with constructor.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class PrincipalAuthorizationEntityTestCase
    {

        /// <summary>
        /// Represent a const principal name used in the test.
        /// </summary>
        private const string PRINCIPAL_NAME = "principal";

        /// <summary>
        /// <p>
        /// Represents the principal to return identity name from.
        /// </p>
        /// </summary>
        private readonly static IPrincipal PRINCIPAL = new MockIPrincipal(PRINCIPAL_NAME);

        /// <summary>
        /// Represents a <c>PrincipalAuthorizationEntity</c> instance used in the test.
        /// </summary>
        private PrincipalAuthorizationEntity entity;

        /// <summary>
        /// Sets up the test environment. The test instance is created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            entity = new PrincipalAuthorizationEntity(PRINCIPAL);
        }

        /// <summary>
        /// Cleans up the test environment. The test instance is disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            entity = null;
        }

        /// <summary>
        /// Test the <c>PrincipalAuthorizationEntity(IPrincipal)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestPrincipalAuthorizationEntityIPrincipalNull()
        {
            new PrincipalAuthorizationEntity(null);
        }

        /// <summary>
        /// Accuracy test of the <c>PrincipalAuthorizationEntity(IPrincipal)</c>. The instance is created.
        /// This case test the properties of this class as well.
        /// </summary>
        [Test]
        public void TestPrincipalAuthorizationEntityIPrincipalAccuracy()
        {
            entity = new PrincipalAuthorizationEntity(PRINCIPAL);

            // Verify.
            Assert.IsNotNull(entity, "The PrincipalAuthorizationEntity instance should be created.");

            Assert.AreEqual(entity.PrincipalName, PRINCIPAL_NAME,
                "The Principal property should be the same as expected.");

            Assert.IsNotNull(entity.ActionName, "The PrincipalAuthorizationEntity instance should be created.");
        }

    }
}