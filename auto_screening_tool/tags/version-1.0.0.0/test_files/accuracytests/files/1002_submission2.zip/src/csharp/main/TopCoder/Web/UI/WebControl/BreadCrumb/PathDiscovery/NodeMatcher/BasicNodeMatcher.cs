using System;
using TopCoder.Web.SiteMap;

namespace TopCoder.Web.UI.WebControl.BreadCrumb.PathDiscovery.NodeMatcher
{
    /// <summary>
    /// <p>
    /// This class extends the AbstractNodeMatcher to provide a simple node mather implementation that
    /// simply checks if strings are equal.
    /// </p>
    /// <p>This class will be needed to create the site map dictionary needed by the Bread Crumb control.</p>
    /// </summary>
    /// <remarks>
    /// Thread safety : This class has no state and is thread safe.
    /// </remarks>
    /// <author>saevio</author>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class BasicNodeMatcher : AbstractNodeMatcher
    {
        /// <summary>
        /// <p>Create a new <c>BasicNodeMatcher</c> with given title and url.</p>
        /// </summary>
        /// <param name="title">Node title</param>
        /// <param name="url">Node url</param>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        /// <exception cref="ArgumetException">If either parameter is empty string.</exception>
        public BasicNodeMatcher(string title, string url) : base(title, url)
        {
            // check parameters.
            SiteMapHelper.ValidateNotNullOrEmpty(title, "title");
            SiteMapHelper.ValidateNotNullOrEmpty(url, "url");
        }


        /// <summary>
        /// <p>
        /// This method will return true if node title and url are equal.
        /// </p>
        /// </summary>
        /// <param name="node">The BreadCrumbNode to check</param>
        /// <returns>True if matches false otherwise.</returns>
        public override bool Matches(BreadCrumbNode node)
        {
            return node.Title.Equals(Title) && node.Url.Equals(Url);
        }

        /// <summary>
        /// <p>
        /// This method will return true if the parameter is INodeMather and name and url
        /// are equal with this one.
        /// </p>
        /// </summary>
        /// <param name="nodeMatcher">INodeMather object</param>
        /// <returns>true if equal; false otherwise</returns>
        public override bool Equals(object nodeMatcher)
        {
            INodeMather match = nodeMatcher as INodeMather;

            return (match != null) ? match.Title.Equals(Title) && match.Url.Equals(Url)
                : false;
        }

        /// <summary>
        /// <p>Returns the hash code of name and url strings concatenated.
        /// </p>
        /// </summary>
        /// <returns>The hash code of the current instance.</returns>
        public override int GetHashCode()
        {
            return Url.GetHashCode() ^ Title.GetHashCode();
        }
    }
}