using System;
using NUnit.Framework;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Tests the functionality and error cases of the <c>Relation</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class RelationTestCase
    {

        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string PARENT_NAME = "parent name";

        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string CHILD_NAME = "child name";

        /// <summary>
        /// <p>The description of the site map node.</p>
        /// </summary>
        private const string DESCRIPTION = "description";

        /// <summary>
        /// <p>The url of the site map node.</p>
        /// </summary>
        private const string URL = "/";

        /// <summary>
        /// <p>
        /// The site map node that represents the parent in the relation.
        /// </p>
        /// </summary>
        private SiteMapNode parent;

        /// <summary>
        /// <p>
        /// The site map node that represents the child in the relation.
        /// </p>
        /// </summary>
        private SiteMapNode child;

        /// <summary>
        /// Represents the Relation instance used in the test.
        /// </summary>
        private Relation relation;

        /// <summary>
        /// Sets up the test environment. The test instance is created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // set up the arguments.
            parent = new SiteMapNode(PARENT_NAME, DESCRIPTION, URL);
            child = new SiteMapNode(CHILD_NAME, DESCRIPTION, URL);

            relation = new Relation(parent, child);
        }

        /// <summary>
        /// Cleans up the test environment. The test instance is disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            parent = null;

            child = null;

            relation = null;
        }

        /// <summary>
        /// Test the <c>Relation(SiteMapNode, SiteMapNode)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestRelationSiteMapNodeSiteMapNodeNullA()
        {
            new Relation(null, child);
        }

        /// <summary>
        /// Test the <c>Relation(SiteMapNode, SiteMapNode)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestRelationSiteMapNodeSiteMapNodeNullB()
        {
            new Relation(parent, null);
        }

        /// <summary>
        /// Test the <c>Relation(SiteMapNode, SiteMapNode)</c> with given SiteMapNodes are equal.
        /// Expect InvalidNodeRelationException
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidNodeRelationException))]
        public void TestRelationSiteMapNodeSiteMapNodeEqual()
        {
            // create a new node equal to the parent node.
            SiteMapNode newNode = new SiteMapNode(PARENT_NAME, DESCRIPTION, URL);

            new Relation(parent, newNode);
        }

        /// <summary>
        /// Test the <c>Relation(SiteMapNode, SiteMapNode)</c> when they already have this relation defined.
        /// Expect InvalidNodeRelationException
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidNodeRelationException))]
        public void TestRelationSiteMapNodeSiteMapNodeAlreadyDefined()
        {
            SiteMapNode newParent = new SiteMapNode(PARENT_NAME, DESCRIPTION, URL);

            // define second time.
            new Relation(newParent, child);
        }

        /// <summary>
        /// Test the <c>Relation(SiteMapNode, SiteMapNode)</c> when the intended child node is an
        /// ancestor to the intended parent node. Expect InvalidNodeRelationException
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidNodeRelationException))]
        public void TestRelationSiteMapNodeSiteMapNodeChildAncestor()
        {
            // the intended child node is an ancestor to the intended parent node now.
            SiteMapNode newParent = new SiteMapNode(PARENT_NAME, DESCRIPTION, URL);

            new Relation(child, newParent);
        }
    }
}