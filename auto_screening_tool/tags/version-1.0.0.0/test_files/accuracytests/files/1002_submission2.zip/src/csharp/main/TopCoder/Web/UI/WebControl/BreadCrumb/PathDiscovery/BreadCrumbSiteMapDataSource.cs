using System;
using System.Collections;
using TopCoder.Web.SiteMap;
using TopCoder.Web.UI.WebControl.BreadCrumb.PathDiscovery.NodeMatcher;

namespace TopCoder.Web.UI.WebControl.BreadCrumb.PathDiscovery
{
    /// <summary>
    /// This class implements the ISiteDicovery interface of the Bread Crumb control to provide the
    /// static site map to the control.
    /// <p>
    /// Note that the Bread Crumb control also supports binding to an array of BreadCrumbNode
    /// that represent the current page trail. The site map, however, is abstracted behind the path
    /// discovery in a ISiteMapDicovery interface.
    /// </p>
    /// <p>
    /// This component will provide the site map as a dictionary of INodeMatcher as expected by the
    /// control.
    /// </p>
    /// <p>
    /// This class will be configured with the Bread Crumb Control to provide the site map. It
    /// can not,however, be specified and thus providing an authorization entity will not be possible.
    /// </p>
    /// </summary>
    /// <remarks>Thread safety : This class has no state and is thread safe.</remarks>
    /// <author>saevio</author>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class BreadCrumbSiteMapDataSource : SiteMapDataSource, ISiteDiscovery
    {

        /// <summary>
        /// Create a new <c>BreadCrumbSiteMapDataSource</c> instance.
        /// </summary>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public BreadCrumbSiteMapDataSource()
        {
        }

        /// <summary>
        /// Create a new <c>BreadCrumbSiteMapDataSource</c> instance with given nameSpace.
        /// </summary>
        /// <param name="nameSpace">Configuration Namespace.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="ArgumentException">If the given string argument is empty.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public BreadCrumbSiteMapDataSource(string nameSpace) : base(nameSpace)
        {
        }


        /// <summary>
        /// <p>
        /// Create a new <c>BreadCrumbSiteMapDataSource</c> instance with given INodeAuthorization.
        /// </p>
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to use.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public BreadCrumbSiteMapDataSource(INodeAuthorization nodeAuthorization)
            : base(nodeAuthorization)
        {
        }

        /// <summary>
        /// <p>
        /// Create a new <c>BreadCrumbSiteMapDataSource</c> instance with given ISiteMapReader.
        /// </p>
        /// </summary>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        public BreadCrumbSiteMapDataSource(ISiteMapReader siteMapReader) : base(siteMapReader)
        {
        }


        /// <summary>
        /// Create a new <c>BreadCrumbSiteMapDataSource</c> instance with given INodeAuthorization and
        /// ISiteMapReader.
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to plug instead of the configured one.
        /// </param>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        public BreadCrumbSiteMapDataSource(INodeAuthorization nodeAuthorization, ISiteMapReader siteMapReader)
            : base(nodeAuthorization, siteMapReader)
        {
        }

        /// <summary>
        /// <p>
        /// This method will convert the site map object model stored in the base classs and
        /// retrieved from a configured persistence into a dictionary of INodeMatcher objects
        /// expected by Bread Crumb Trail Control.
        /// </p>
        /// </summary>
        /// <returns>The site map dictionary</returns>
        /// <exception cref="BreadCrumbException">If any error occurs during this method.</exception>
        public IDictionary GetSiteMap()
        {
            IDictionary ret = new Hashtable();

            try
            {
                // the root node of the SiteMap from base class.
                SiteMapNode root = SiteMap.RootNode;

                RecursiveProcess(root, ret);

                return ret;
            }
            catch(Exception e)
            {
                throw new BreadCrumbException(e.Message, e);
            }
        }

        /// <summary>
        /// A helper method to process the children node recursively.
        /// </summary>
        /// <param name="root">The root node whose children nodes are to be processed.</param>
        /// <param name="ret">The site map dictionary</param>
        private void RecursiveProcess(SiteMapNode root, IDictionary ret)
        {

            INodeMather matcher = new BasicNodeMatcher(root.Name, root.Url);

            // Note : each site map node should be checked if the given credentials are authorized for that
            // specific node. If not the node should not be added to the result and should be ignored as well
            // as its children.
            if (this.NodeAuthorization.IsAccessible(root) && (!ret.Contains(matcher)))
            {
                // values in the list should be INodeMatcher.
                IList valueList = new ArrayList();

                ret.Add(matcher, valueList);

                foreach (SiteMapNode child in root.Children)
                {
                    INodeMather childMatcher = new BasicNodeMatcher(child.Name, child.Url);

                    // if there is not one already for a node with the same name and url, add it to the list.
                    if (!valueList.Contains(childMatcher))
                    {
                        valueList.Add(childMatcher);
                    }

                    RecursiveProcess(child, ret);
                }
            }
        }
    }
}