using System;

namespace TopCoder.Web.SiteMap
{

    /// <summary>
    /// <p>
    /// This class represents the base class for all specific site map data sources. It is responsible
    /// for creating, using the Object Factory, an ISiteMapReader implementation and retrieve the site
    /// map object model.
    /// </p>
    /// <p>
    /// It is also responsible for creating, using the Object Factory, an INodeAuthorization implementation
    /// for derived classes to use for node authorization.
    /// </p>
    /// <p>
    /// The ISiteMapReader and INodeAuthorization implementations to use can either be specified in
    /// the constructor, or can be specified in the configuration file and created using the Object
    /// Factory component.
    /// </p>
    /// </summary>
    /// <remarks>
    /// This class is thread safe, since instances of this class are immutable.
    /// </remarks>
    /// <author>TCSDEVELOPER</author>
    /// <author>saevio</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public abstract class SiteMapDataSource
    {

        /// <summary>
        /// Represents the name of the object_factory_namespace property in the config file.
        /// </summary>
        private const string OBJECT_FACTORY_PROPERTY = "object_factory_namespace";

        /// <summary>
        /// Represents the name of the site_map_reader_key property in the config file.
        /// </summary>
        private const string SITE_MAP_READER_KEY_PROPERTY = "site_map_reader_key";

        /// <summary>
        /// Represents the name of the node_authorization_key property in the config file.
        /// </summary>
        private const string NODE_AUTHORIZATION_KEY_PROPERTY = "node_authorization_key";

        /// <summary>
        /// <p>
        /// The INodeAuthorization implementation to be used by derived classes for node authorization.
        /// Different implementations can easily be plugged.
        /// </p>
        /// <p>
        /// Set in the constructor and not changed afterwards. Can not be null. Either passed as parameter
        /// or created using the Object Factory component based on a configured key.
        /// </p>
        /// </summary>
        private readonly INodeAuthorization nodeAuthorization;

        /// <summary>
        /// <p>
        /// The site map object model retrieved from a ISiteMapReader implementation.
        /// </p>
        /// <p>
        /// Set in the constructor and not changed afterwards.Can not be null.
        /// </p>
        /// </summary>
        private readonly SiteMap siteMap;

        /// <summary>
        /// <p>Returns the INodeAuthorization reference for derived classes to use.</p>
        /// </summary>
        /// <value>
        /// The INodeAuthorization implementation to be used by derived classes for node authorization.
        /// </value>
        protected INodeAuthorization NodeAuthorization
        {
            get
            {
                return nodeAuthorization;
            }
        }

        /// <summary>
        /// <p>Returns the site map object model.</p>
        /// </summary>
        /// <value>
        /// The site map object model retrieved from a ISiteMapReader implementation.
        /// </value>
        protected SiteMap SiteMap
        {
            get
            {
                return siteMap;
            }
        }

        /// <summary>
        /// <p>Default configuration namespace.</p>
        /// </summary>
        public const string Namespace = "TopCoder.Web.SiteMap";

        /// <summary>
        /// <p>
        /// Create a new <c>SiteMapDataSource</c> instance with default nameSpace.
        /// </p>
        /// </summary>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        protected  SiteMapDataSource() : this(Namespace)
        {
        }

        /// <summary>
        /// <p>
        /// Create a new <c>SiteMapDataSource</c> instance with given nameSpace.
        /// </p>
        /// <p>
        /// All parameters used in this method in the configuration file are as below.
        /// <table>
        ///   <hr>
        ///       <th>Name</th>
        ///       <th>Required</th>
        ///   </hr>
        ///   <tr>
        ///       <td>object_factory_namespace</td>
        ///       <td>False</td>
        ///   </tr>
        ///   <tr>
        ///       <td>site_map_reader_key</td>
        ///       <td>True</td>
        ///   </tr>
        ///   <tr>
        ///       <td>node_authorization_key</td>
        ///       <td>True</td>
        ///   </tr>
        /// </table>
        /// </p>
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="ArgumentException">If the given string argument is empty.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        protected SiteMapDataSource(string nameSpace)
        {
            // check parameter
            SiteMapHelper.ValidateNotNullOrEmpty(nameSpace, "nameSpace");

            // create the siteMap member.
            this.siteMap = InitializeSiteMap(nameSpace);

            // create the nodeAuthorization member.
            this.nodeAuthorization = InitializeNodeAuthorization(nameSpace);

        }

        /// <summary>
        /// <p>
        /// Create a new <c>SiteMapDataSource</c> instance with given INodeAuthorization.
        /// </p>
        /// <p>
        /// All parameters used in this method in the configuration file are as below.
        /// <table>
        ///   <hr>
        ///       <th>Name</th>
        ///       <th>Required</th>
        ///   </hr>
        ///   <tr>
        ///       <td>object_factory_namespace</td>
        ///       <td>False</td>
        ///   </tr>
        ///   <tr>
        ///       <td>site_map_reader_key</td>
        ///       <td>True</td>
        ///   </tr>
        /// </table>
        /// </p>
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to plug instead of the configured one.
        /// </param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        protected SiteMapDataSource(INodeAuthorization nodeAuthorization)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(nodeAuthorization, "nodeAuthorization");

            this.nodeAuthorization = nodeAuthorization;

            // create the siteMap member.
            this.siteMap = InitializeSiteMap(Namespace);
        }


        /// <summary>
        /// <p>
        /// Create a new <c>SiteMapDataSource</c> instance with given ISiteMapReader.
        /// </p>
        /// <p>
        /// All parameters used in this method in the configuration file are as below.
        /// <table>
        ///   <hr>
        ///       <th>Name</th>
        ///       <th>Required</th>
        ///   </hr>
        ///   <tr>
        ///       <td>object_factory_namespace</td>
        ///       <td>False</td>
        ///   </tr>
        ///   <tr>
        ///       <td>node_authorization_key</td>
        ///       <td>True</td>
        ///   </tr>
        /// </table>
        /// </p>
        /// </summary>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If the given argument is null.</exception>
        /// <exception cref="SiteMapConfigurationException">
        /// To signal problems with configuration file or if can not create objects.
        /// </exception>
        protected SiteMapDataSource(ISiteMapReader siteMapReader)
        {
            // check parameter.
            SiteMapHelper.ValidateNotNull(siteMapReader, "siteMapReader");

            this.siteMap = siteMapReader.Read();

            // create the nodeAuthorization member.
            this.nodeAuthorization = InitializeNodeAuthorization(Namespace);
        }


        /// <summary>
        /// Create a new <c>SiteMapDataSource</c> instance with given INodeAuthorization and ISiteMapReader.
        /// </summary>
        /// <param name="nodeAuthorization">The INodeAuthorization to plug instead of the configured one.
        /// </param>
        /// <param name="siteMapReader">The ISiteMapReader to plug instead of the configured one.</param>
        /// <exception cref="ArgumentNullException">If either parameter is null.</exception>
        protected SiteMapDataSource(INodeAuthorization nodeAuthorization, ISiteMapReader siteMapReader)
        {
            // check parameters.
            SiteMapHelper.ValidateNotNull(nodeAuthorization, "nodeAuthorization");
            SiteMapHelper.ValidateNotNull(siteMapReader, "siteMapReader");

            this.nodeAuthorization = nodeAuthorization;
            this.siteMap = siteMapReader.Read();
        }

        /// <summary>
        /// A helper to return a SiteMap instance to initialize the
        /// siteMap member.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <returns>The created instance.</returns>
        private SiteMap InitializeSiteMap(string nameSpace)
        {
            // get the object factory namespace.
            string objectFactoryNamespace
                = SiteMapHelper.GetValue(nameSpace, OBJECT_FACTORY_PROPERTY, false);

            // create the siteMap member.
            string siteMapReaderKey
                = SiteMapHelper.GetValue(nameSpace, SITE_MAP_READER_KEY_PROPERTY, true);

            return (SiteMapHelper.CreateInstance(siteMapReaderKey, objectFactoryNamespace,
                typeof(ISiteMapReader)) as ISiteMapReader).Read();
        }

        /// <summary>
        /// A helper to return an INodeAuthorization instance to initialize the
        /// nodeAuthorization member.
        /// </summary>
        /// <param name="nameSpace">Alternative configuration namespace.</param>
        /// <returns>The created instance.</returns>
        private INodeAuthorization InitializeNodeAuthorization(string nameSpace)
        {
            // get the object factory namespace.
            string objectFactoryNamespace
                = SiteMapHelper.GetValue(nameSpace, OBJECT_FACTORY_PROPERTY, false);

            // create the nodeAuthorization member.
            string nodeAuthorizationKey
                = SiteMapHelper.GetValue(nameSpace, NODE_AUTHORIZATION_KEY_PROPERTY, true);

            return SiteMapHelper.CreateInstance(nodeAuthorizationKey, objectFactoryNamespace,
                typeof(INodeAuthorization)) as INodeAuthorization;
        }
    }
}