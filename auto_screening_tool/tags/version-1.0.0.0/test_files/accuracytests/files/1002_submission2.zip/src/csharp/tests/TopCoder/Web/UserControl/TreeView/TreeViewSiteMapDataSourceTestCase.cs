using System;
using NUnit.Framework;
using TopCoder.Util.ConfigurationManager;
using TopCoder.Web.SiteMap;
using TopCoder.Web.SiteMap.Authorization;
using TopCoder.Web.SiteMap.Readers;

namespace TopCoder.Web.UserControl.TreeView
{

    /// <summary>
    /// Tests the functionality and error cases of the <c>TreeViewSiteMapDataSource</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class TreeViewSiteMapDataSourceTestCase
    {
        /// <summary>
        /// Represents a ConfigManager instance used in the test.
        /// </summary>
        private ConfigManager manager = ConfigManager.GetInstance();

        /// <summary>
        /// Represents the file name template of the namespace used to create instance.
        /// </summary>
        private const string FILE_NAME_TEMP = "../../test_files/SiteMapDataSource/{0}.xml";

        /// <summary>
        /// Represents a valid file name to create instance.
        /// </summary>
        private const string VALID_FILE = "SiteMapDataSource";

        /// <summary>
        /// Represents a missing object_factory_namespace property configuration file name.
        /// </summary>
        private const string MISSING_OBJECT_FACTORY_NAMESPACE = "Missing_object_factory_namespace";

        /// <summary>
        /// Represents an empty object_factory_namespace property configuration file name.
        /// </summary>
        private const string EMPTY_OBJECT_FACTORY_NAMESPACE = "Empty_object_factory_namespace";

        /// <summary>
        /// Represents a missing site_map_reader_key property configuration file name.
        /// </summary>
        private const string MISSING_SITE_MAP_READER_KEY = "Missing_site_map_reader_key";

        /// <summary>
        /// Represents an empty site_map_reader_key property configuration file name.
        /// </summary>
        private const string EMPTY_SITE_MAP_READER_KEY = "Empty_site_map_reader_key";

        /// <summary>
        /// Represents a missing node_authorization_key property configuration file name.
        /// </summary>
        private const string MISSING_NODE_AUTHORIZATION_KEY = "Missing_node_authorization_key";

        /// <summary>
        /// Represents an empty node_authorization_key property configuration file name.
        /// </summary>
        private const string EMPTY_NODE_AUTHORIZATION_KEY = "Empty_node_authorization_key";

        /// <summary>
        /// Represents a valid nameSpace in the configuration file.
        /// </summary>
        private const string VALID_NAME_SPACE = "TopCoder.Web.SiteMap";

        /// <summary>
        /// Represents a valid xml file path used in the test.
        /// </summary>
        private const string VALID_XML_FILE_PATH = "../../test_files/Readers/SiteMap.xml";

        /// <summary>
        /// Represents a valid xsd file path used in the test.
        /// </summary>
        private const string VALID_XSD_FILE_PATH = "../../test_files/Readers/SiteMap.xsd";

        /// <summary>
        /// Represents the ISiteMapReader instance used as argument in the test.
        /// </summary>
        private ISiteMapReader reader;

        /// <summary>
        /// Represents a <c>TreeViewSiteMapDataSource</c> instance used in the test.
        /// </summary>
        private TreeViewSiteMapDataSource source;

        /// <summary>
        /// Represents the INodeAuthorization instance used as argument in the test.
        /// </summary>
        private INodeAuthorization nodeAuthorization;


        /// <summary>
        /// Sets up the test environment. The test instances are created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            nodeAuthorization = new DisabledNodeAuthorization();

            reader = new XmlSiteMapReader(VALID_XML_FILE_PATH, VALID_XSD_FILE_PATH);

            source = new TreeViewSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Cleans up the test environment. The test instances are disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            // clear the configuration manager.
            manager.Clear();

            nodeAuthorization = null;

            reader = null;

            source = null;
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource()</c> when the optional property is missing.
        /// The TreeViewSiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new TreeViewSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource()</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new TreeViewSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new TreeViewSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new TreeViewSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new TreeViewSiteMapDataSource();
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new TreeViewSiteMapDataSource();
        }

        /// <summary>
        /// Accuracy test of the <c>TreeViewSiteMapDataSource()</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceAccuracy()
        {
            source = new TreeViewSiteMapDataSource();

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>TreeViewSiteMapDataSource(String)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestTreeViewSiteMapDataSourceStringNull()
        {
            new TreeViewSiteMapDataSource(null as string);
        }

        /// <summary>
        /// Test the <c>TreeViewSiteMapDataSource(String)</c> with empty string argument. Expect
        /// ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestTreeViewSiteMapDataSourceStringEmpty()
        {
            new TreeViewSiteMapDataSource("   ");
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(String)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceStringMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new TreeViewSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(String)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceStringEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new TreeViewSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(String)</c> when the required property is missing.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceStringMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new TreeViewSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceStringEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new TreeViewSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(String)</c> when the required property is missing.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceStringMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new TreeViewSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceStringEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new TreeViewSiteMapDataSource(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Accuracy test of the <c>TreeViewSiteMapDataSource(String)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceStringAccuracy()
        {
            source = new TreeViewSiteMapDataSource(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>TreeViewSiteMapDataSource(INodeAuthorization)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestTreeViewSiteMapDataSourceINodeAuthorizationNull()
        {
            new TreeViewSiteMapDataSource(null as INodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(INodeAuthorization)</c> when the optional property is
        /// missing. The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceINodeAuthorizationMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new TreeViewSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(INodeAuthorization)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceINodeAuthorizationEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new TreeViewSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(INodeAuthorization)</c> when the required property is
        /// missing. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceINodeAuthorizationMissingSiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_SITE_MAP_READER_KEY));

            new TreeViewSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(INodeAuthorization)</c> when the required property
        /// value is empty. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceINodeAuthorizationEmptySiteMapReaderKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_SITE_MAP_READER_KEY));

            new TreeViewSiteMapDataSource(nodeAuthorization);
        }

        /// <summary>
        /// Accuracy test of the <c>TreeViewSiteMapDataSource(INodeAuthorization)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceINodeAuthorizationAccuracy()
        {
            source = new TreeViewSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>TreeViewSiteMapDataSource(ISiteMapReader)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderNull()
        {
            new TreeViewSiteMapDataSource(null as ISiteMapReader);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(ISiteMapReader)</c> when the optional property is missing.
        /// The TreeViewSiteMapDataSource instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderMissingObjectFactoryNamespace()
        {
            // initialize the ConfigManager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            source = new TreeViewSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(ISiteMapReader)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new TreeViewSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(ISiteMapReader)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderMissingNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_NODE_AUTHORIZATION_KEY));

            new TreeViewSiteMapDataSource(reader);
        }

        /// <summary>
        /// Test of the <c>TreeViewSiteMapDataSource(ISiteMapReader)</c> when the required property value
        /// is empty. Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderEmptyNodeAuthorizationKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_NODE_AUTHORIZATION_KEY));

            new TreeViewSiteMapDataSource(reader);
        }

        /// <summary>
        /// Accuracy test of the <c>TreeViewSiteMapDataSource(ISiteMapReader)</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderAccuracy()
        {
            source = new TreeViewSiteMapDataSource(reader);

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Test the <c>TreeViewSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderINodeAuthorizationNullA()
        {
            new TreeViewSiteMapDataSource(null, reader);
        }

        /// <summary>
        /// Test the <c>TreeViewSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c> with null argument.
        /// Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderINodeAuthorizationNullB()
        {
            new TreeViewSiteMapDataSource(nodeAuthorization, null);
        }

        /// <summary>
        /// Accuracy test of the <c>TreeViewSiteMapDataSource(INodeAuthorization, ISiteMapReader)</c>.
        /// The instance is created.
        /// </summary>
        [Test]
        public void TestTreeViewSiteMapDataSourceISiteMapReaderINodeAuthorizationAccuracy()
        {
            source = new TreeViewSiteMapDataSource(nodeAuthorization, reader);

            // Verify.
            Assert.IsNotNull(source, "The TreeViewSiteMapDataSource instance should be created.");
        }

        /// <summary>
        /// Accuracy test of the <c>LoadTree()</c>. A TreeNode is returned.
        /// </summary>
        [Test]
        public void TestLoadTreeAccuracy()
        {
            TreeNode ret = source.LoadTree();

            MockSiteMapDataSource mockSource = new MockSiteMapDataSource(nodeAuthorization);

            // Verify.
            Assert.IsNotNull(ret, "The TreeNode should be returned.");

            SiteMapNode root  = mockSource.SiteMap.RootNode;

            // Verify.
            RecursiveVerify(root, ret);
        }

        /// <summary>
        /// A helper method to verify the contents of the given SiteMapNode and TreeNode.
        /// </summary>
        /// <param name="rootNode">The SiteMapNode to verify.</param>
        /// <param name="rootTreeNode">The TreeNode to verify.</param>
        private void RecursiveVerify(SiteMapNode rootNode, TreeNode rootTreeNode)
        {
            Assert.AreEqual(rootNode.Name, rootTreeNode.Text,
                "The Name property should be the same as expected.");
            Assert.AreEqual(rootNode.Url, rootTreeNode.IconUrl,
                "The Url property should be the same as expected.");

            int i= 0;

            foreach (TreeNode treeNode in rootTreeNode.Children)
            {
                SiteMapNode mapNode = rootNode.Children[i++];

                // Verify.
                Assert.AreEqual(mapNode.Name, treeNode.Text,
                    "The Name property should be the same as expected.");

                Assert.AreEqual(mapNode.Url, treeNode.IconUrl,
                    "The Url property should be the same as expected.");

                // Verify Recursively.
                RecursiveVerify(mapNode, treeNode);
            }

        }
    }
}