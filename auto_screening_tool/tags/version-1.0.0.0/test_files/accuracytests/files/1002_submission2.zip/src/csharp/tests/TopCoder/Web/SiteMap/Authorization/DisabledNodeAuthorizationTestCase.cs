using System;
using NUnit.Framework;

namespace TopCoder.Web.SiteMap.Authorization
{

    /// <summary>
    /// Tests the functionality and error cases of the <c>DisabledNodeAuthorization</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class DisabledNodeAuthorizationTestCase
    {
        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string NAME = "name";

        /// <summary>
        /// <p>The description of the site map node.</p>
        /// </summary>
        private const string DESCRIPTION = "description";

        /// <summary>
        /// <p>The url of the site map node.</p>
        /// </summary>
        private const string URL = "/";

        /// <summary>
        /// Represents a <c>DisabledNodeAuthorization</c> instance used in the test.
        /// </summary>
        private DisabledNodeAuthorization disabledNodeAuthorization;

        /// <summary>
        /// Sets up the test environment. The test instance is created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            disabledNodeAuthorization = new DisabledNodeAuthorization();
        }

        /// <summary>
        /// Cleans up the test environment. The test instance is disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            disabledNodeAuthorization = null;
        }

        /// <summary>
        /// Accuracy test of the <c>DisabledNodeAuthorization()</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestDisabledNodeAuthorization()
        {
            disabledNodeAuthorization = new DisabledNodeAuthorization();

            // Verify.
            Assert.IsNotNull(disabledNodeAuthorization,
                "The DisabledNodeAuthorization instance should be created.");
        }


        /// <summary>
        /// Test the <c>IsAccessible(SiteMapNode)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestIsAccessibleSiteMapNodeNull()
        {
            disabledNodeAuthorization.IsAccessible(null);
        }

        /// <summary>
        /// Accuracy test of the <c>IsAccessible(SiteMapNode)</c>. True is returned.
        /// </summary>
        [Test]
        public void TestIsAccessibleSiteMapNodeAccuracy()
        {
            bool ret = disabledNodeAuthorization.IsAccessible(new SiteMapNode(NAME, DESCRIPTION, URL));

            // Verify.
            Assert.IsTrue(ret, "The DisabledNodeAuthorization instance should be created.");
        }
    }
}