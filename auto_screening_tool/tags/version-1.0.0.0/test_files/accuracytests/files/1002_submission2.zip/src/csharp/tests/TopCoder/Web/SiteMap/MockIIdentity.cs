using System;
using System.Security.Principal;

namespace TopCoder.Web.SiteMap
{
    /// <summary>
    /// Defines a Mock class of <c>IIdentity</c>.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    public class MockIIdentity : IIdentity
    {

        /// <summary>
        /// The name of the MockIIdentity.
        /// </summary>
        private string name;

        /// <summary>
        /// An ignored property getter.
        /// </summary>
        /// <value>
        /// Always to be false.
        /// </value>
        public bool IsAuthenticated
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// The getter of the name member.
        /// </summary>
        /// <value>
        /// The name of the MockIIdentity.
        /// </value>
        public string Name
        {
            get
            {
                return name;
            }
        }

        /// <summary>
        /// An ignored property getter.
        /// </summary>
        /// <value>
        /// Always to be null.
        /// </value>
        public string AuthenticationType
        {
            get
            {
                return null;
            }
        }

        /// <summary>
        /// Create a new <c>MockIIdentity</c> with given name.
        /// </summary>
        /// <param name="name">The name of the MockIIdentity.</param>
        public MockIIdentity(string name)
        {
            this.name = name;
        }

    }
}