using System;
using NUnit.Framework;
using TopCoder.Util.ConfigurationManager;
using TopCoder.Security.Authorization;
using TopCoder.Security.Authorization.Persistence;
using TopCoder.Security.Authorization.Policy;
using TopCoder.Web.SiteMap.Authorization.Entities;

namespace TopCoder.Web.SiteMap.Authorization
{
    /// <summary>
    /// Tests the functionality and error cases of the <c>NodeAuthorization</c> class.
    /// </summary>
    /// <author>TCSDEVELOPER</author>
    /// <version>1.0</version>
    /// <copyright>Copyright (c) 2006, TopCoder, Inc. All rights reserved.</copyright>
    [TestFixture]
    public class NodeAuthorizationTestCase
    {

        /// <summary>
        /// <p>The name of the site map node.</p>
        /// </summary>
        private const string NAME = "main";

        /// <summary>
        /// <p>The description of the site map node.</p>
        /// </summary>
        private const string DESCRIPTION = "description";

        /// <summary>
        /// <p>The url of the site map node.</p>
        /// </summary>
        private const string URL = "/";

        /// <summary>
        /// Represent a const principal name used in the test.
        /// </summary>
        private const string PRINCIPAL_NAME = "bob";

        /// <summary>
        /// Represents a ConfigManager instance used in the test.
        /// </summary>
        private ConfigManager manager = ConfigManager.GetInstance();

        /// <summary>
        /// Represents a valid nameSpace in the configuration file.
        /// </summary>
        private const string VALID_NAME_SPACE = "TopCoder.Web.SiteMap.Authorization";

        /// <summary>
        /// Represents the file name template of the namespace used to create instance.
        /// </summary>
        private const string FILE_NAME_TEMP = "../../test_files/Authorization/NodeAuthorization/{0}.xml";

        /// <summary>
        /// Represents a valid file name to create instance.
        /// </summary>
        private const string VALID_FILE = "NodeAuthorization";

        /// <summary>
        /// Represents a missing object_factory_namespace property configuration file name.
        /// </summary>
        private const string MISSING_OBJECT_FACTORY_NAMESPACE = "Missing_object_factory_namespace";

        /// <summary>
        /// Represents an empty object_factory_namespace property configuration file name.
        /// </summary>
        private const string EMPTY_OBJECT_FACTORY_NAMESPACE = "Empty_object_factory_namespace";

        /// <summary>
        /// Represents a missing authorization_manager_key property configuration file name.
        /// </summary>
        private const string MISSING_AUTHORIZATION_MANAGER_KEY = "Missing_authorization_manager_key";

        /// <summary>
        /// Represents an empty authorization_manager_key property configuration file name.
        /// </summary>
        private const string EMPTY_AUTHORIZATION_MANAGER_KEY = "Empty_authorization_manager_key";

        /// <summary>
        /// Represents a missing authorization_entity_key property configuration file name.
        /// </summary>
        private const string MISSING_AUTHORIZATION_ENTITY_KEY = "Missing_authorization_entity_key";

        /// <summary>
        /// Represents an empty authorization_entity_key property configuration file name.
        /// </summary>
        private const string EMPTY_AUTHORIZATION_ENTITY_KEY = "Empty_authorization_entity_key";

        /// <summary>
        /// Represents a missing policy_decision_aggregator_key property configuration file name.
        /// </summary>
        private const string MISSING_AGGREGATOR_KEY = "Missing_policy_decision_aggregator_key";

        /// <summary>
        /// Represents an empty policy_decision_aggregator_key property configuration file name.
        /// </summary>
        private const string EMPTY_AGGREGATOR_KEY = "Empty_policy_decision_aggregator_key";

        /// <summary>
        /// Represents a missing principal_context_type property configuration file name.
        /// </summary>
        private const string MISSING_PRINCIPAL_CONTEXT_TYPE = "Missing_principal_context_type";

        /// <summary>
        /// Represents an empty principal_context_type property configuration file name.
        /// </summary>
        private const string EMPTY_PRINCIPAL_CONTEXT_TYPE = "Empty_principal_context_type";

        /// <summary>
        /// Represents a missing resource_context_type property configuration file name.
        /// </summary>
        private const string MISSING_RESOURCE_CONTEXT_TYPE = "Missing_resource_context_type";

        /// <summary>
        /// Represents an empty resource_context_type property configuration file name.
        /// </summary>
        private const string EMPTY_RESOURCE_CONTEXT_TYPE = "Empty_resource_context_type";

        /// <summary>
        /// Represents a <c>NodeAuthorization</c> instance used in the test.
        /// </summary>
        private NodeAuthorization nodeAuthorization;

        /// <summary>
        /// Represents the IAuthorizationEntity instance used as argument in the test.
        /// </summary>
        private IAuthorizationEntity authorizationEntity;

        /// <summary>
        /// Represents the AuthorizationManager instance used as argument in the test.
        /// </summary>
        private AuthorizationManager authorizationManager;

        /// <summary>
        /// Sets up the test environment. The test instances are created.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            // initialize the config manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, VALID_FILE));

            authorizationEntity = new PrincipalAuthorizationEntity(new MockIPrincipal(PRINCIPAL_NAME));

            authorizationManager = new AuthorizationManager();

            nodeAuthorization = new NodeAuthorization();
        }

        /// <summary>
        /// Cleans up the test environment. The test instances are disposed.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            manager.Clear();

            authorizationEntity = null;

            authorizationManager = null;

            nodeAuthorization = null;
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }


        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationMissingObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            new NodeAuthorization(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationMissingAuthorizationManagerKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AUTHORIZATION_MANAGER_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationEmptyAuthorizationManagerKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AUTHORIZATION_MANAGER_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationMissingAuthorizationEntityKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AUTHORIZATION_ENTITY_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationEmptyAuthorizationEntityKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AUTHORIZATION_ENTITY_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationMissingAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AGGREGATOR_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationEmptyAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AGGREGATOR_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationMissingPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationEmptyPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationMissingResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization()</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationEmptyResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Accuracy test of the <c>NodeAuthorization()</c>. The instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationAccuracy()
        {
            nodeAuthorization = new NodeAuthorization();

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test the <c>NodeAuthorization(String)</c> with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNodeAuthorizationStringNull()
        {
            new NodeAuthorization(null as string);
        }

        /// <summary>
        /// Test the <c>NodeAuthorization(String)</c> with empty string argument. Expect ArgumentException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestNodeAuthorizationStringEmpty()
        {
            new NodeAuthorization("   ");
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }


        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationStringMissingObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            nodeAuthorization = new NodeAuthorization(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringMissingAuthorizationManagerKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AUTHORIZATION_MANAGER_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringEmptyAuthorizationManagerKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AUTHORIZATION_MANAGER_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringMissingAuthorizationEntityKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AUTHORIZATION_ENTITY_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringEmptyAuthorizationEntityKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AUTHORIZATION_ENTITY_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringMissingAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AGGREGATOR_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringEmptyAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AGGREGATOR_KEY));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringMissingPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringEmptyPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringMissingResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(String)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationStringEmptyResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(VALID_NAME_SPACE);
        }


        /// <summary>
        /// Accuracy test of the <c>NodeAuthorization(String)</c>. The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationStringAccuracy()
        {
            nodeAuthorization = new NodeAuthorization(VALID_NAME_SPACE);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test the <c>NodeAuthorization(IAuthorizationEntity)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNodeAuthorizationIAuthorizationEntityNull()
        {
            new NodeAuthorization(null as IAuthorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new NodeAuthorization(authorizationEntity);
        }


        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationIAuthorizationEntityMissingObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            nodeAuthorization = new NodeAuthorization(authorizationEntity);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityMissingAuthorizationManagerKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AUTHORIZATION_MANAGER_KEY));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityEmptyAuthorizationManagerKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AUTHORIZATION_MANAGER_KEY));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityMissingAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AGGREGATOR_KEY));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityEmptyAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AGGREGATOR_KEY));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityMissingPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityEmptyPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityMissingResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityEmptyResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity);
        }

        /// <summary>
        /// Accuracy test of the <c>NodeAuthorization(IAuthorizationEntity)</c>. The NodeAuthorization
        /// instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationIAuthorizationEntityAccuracy()
        {
            nodeAuthorization = new NodeAuthorization(authorizationEntity);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new NodeAuthorization(authorizationManager);
        }


        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationAuthorizationManagerMissingObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            nodeAuthorization = new NodeAuthorization(authorizationManager);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerMissingAuthorizationEntityKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AUTHORIZATION_ENTITY_KEY));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerEmptyAuthorizationEntityKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AUTHORIZATION_ENTITY_KEY));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerMissingAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AGGREGATOR_KEY));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerEmptyAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AGGREGATOR_KEY));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerMissingPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerEmptyPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerMissingResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(AuthorizationManager)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationAuthorizationManagerEmptyResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(authorizationManager);
        }

        /// <summary>
        /// Test the <c>NodeAuthorization(AuthorizationManager)</c> with null argument. Expect
        /// ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNodeAuthorizationAuthorizationManagerNull()
        {
            new NodeAuthorization(null as AuthorizationManager);
        }

        /// <summary>
        /// Accuracy test of the <c>NodeAuthorization(AuthorizationManager)</c>. The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationAuthorizationManagerAccuracy()
        {
            nodeAuthorization = new NodeAuthorization(authorizationManager);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> with null
        /// argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerNullA()
        {
            new NodeAuthorization(null, authorizationManager);
        }

        /// <summary>
        /// Test the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> with null
        /// argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerNullB()
        {
            new NodeAuthorization(authorizationEntity, null);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerEmptyObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_OBJECT_FACTORY_NAMESPACE));

            new NodeAuthorization(authorizationEntity, authorizationManager);
        }


        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the optional property is missing.
        /// The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerMissingObjectFactoryNamespace()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_OBJECT_FACTORY_NAMESPACE));

            nodeAuthorization = new NodeAuthorization(authorizationEntity, authorizationManager);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerMissingAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_AGGREGATOR_KEY));

            new NodeAuthorization(authorizationEntity, authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerEmptyAggregatorKey()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_AGGREGATOR_KEY));

            new NodeAuthorization(authorizationEntity, authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerMissingPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity, authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerEmptyPrincipalContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_PRINCIPAL_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity, authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the required property is missing..
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerMissingResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, MISSING_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity, authorizationManager);
        }

        /// <summary>
        /// Test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c> when the required property value is empty.
        /// Expect SiteMapConfigurationException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(SiteMapConfigurationException))]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerEmptyResourceContextType()
        {
            // initialize the configuration manager.
            manager.Clear();
            manager.LoadFile(string.Format(FILE_NAME_TEMP, EMPTY_RESOURCE_CONTEXT_TYPE));

            new NodeAuthorization(authorizationEntity, authorizationManager);
        }


        /// <summary>
        /// Accuracy test of the <c>NodeAuthorization(IAuthorizationEntity, AuthorizationManager)</c>. The NodeAuthorization instance is created.
        /// </summary>
        [Test]
        public void TestNodeAuthorizationIAuthorizationEntityAuthorizationManagerAccuracy()
        {
            nodeAuthorization = new NodeAuthorization(authorizationEntity, authorizationManager);

            // Verify.
            Assert.IsNotNull(nodeAuthorization, "The NodeAuthorization instance should be created.");
        }

        /// <summary>
        /// Test the <c>IsAccessible(SiteMapNode)</c>with null argument. Expect ArgumentNullException.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestIsAccessibleSiteMapNodeNull()
        {
            nodeAuthorization.IsAccessible(null);
        }

        /// <summary>
        /// Test the <c>IsAccessible(SiteMapNode)</c>with valid argument. If the given node is
        /// accessable base on the configuration, true is returned, false otherwise.
        /// </summary>
        [Test]
        public void TestIsAccessibleSiteMapNodeAccuracy()
        {
            //create the Authorization Manager
            AuthorizationManager am = new AuthorizationManager();

            // Get the Persistence Manager
            IAuthorizationPersistenceManager pm = am.Persistence;

            // configure the resource type
            // the resource type can be configured with this component when used to authorize a request.
            string resourceTypeName = "node";

            IActionContextType resourceType = pm.GetActionContextType(resourceTypeName);

            // configure the userType
            // the principal type can be configured with this component when used to authorize a request.
            string principalTypeName = "user";
            IActionContextType principalType = pm.GetActionContextType(principalTypeName);

            //create the action. We only define one action; the action is specified by the IAuthorizationEntiy
            // in this component when authorizing a request.

            // a variable storing the name of action.
            string actionName = "view node";
            IAction viewAction = pm.GetAction(actionName);

            //add the context types to the action
            viewAction.AddContextType(resourceType);
            viewAction.AddContextType(principalType);

            // create some site map nodes members; nodes should be specified by their name
            // all site map nodes that require  authorization should be specified
            IMember mainPage = pm.GetMember(resourceType, NAME);

            //The following configuration sets the admins role with bob identity, and the guests role with
            //jim identity

            // a variable storing the name of admin.
            string adminName = "bob";
            IMember bob = pm.GetMember(principalType, adminName);

            // a variable storing the name of admin role.
            string adminRoleName = "admin";

            IRole admin = pm.GetRole(principalType, adminRoleName);
            admin.AddMember(RoleMembershipType.Inclusion, bob);

            //add jim identity to the quests role

            // a variable storing the name of guest.
            string guestName = "jim";

            IMember jim = pm.GetMember(principalType, guestName);

            // a variable storing the name of guest role.
            string guestRoleName = "guests";

            IRole guests = pm.GetRole(principalType, guestRoleName);
            guests.AddMember(RoleMembershipType.Inclusion, jim);

            // create an access policy with "admin" role

            // a variable storing the name of policy.
            string policyName = "admins policy";

            IAuthorizationPolicy adminsPolicy = pm.GetAuthorizationPolicy(policyName);

            //add the action to the policy
            adminsPolicy.AddAction(viewAction);

            //add the role to the policy
            adminsPolicy.AddDescriptor(admin);

            //add the main page and administration page authorized only to administrators
            //descriptors should be added in the same fashion for all authorized nodes
            adminsPolicy.AddDescriptor(mainPage);
            adminsPolicy.IsAllow = true;

            //refresh the authorization manager
            am.Refresh();

            nodeAuthorization = new NodeAuthorization(am);

            SiteMapNode node = new SiteMapNode(NAME, DESCRIPTION, URL);

            // main is accessable node base on the configuration.
            Assert.IsTrue(nodeAuthorization.IsAccessible(node),
                "The given node should be accessable based on the configuration.");

            IAuthorizationEntity entity = new PrincipalAuthorizationEntity(new MockIPrincipal(guestName));

            nodeAuthorization = new NodeAuthorization(entity, am);

            // check the unaccessable configuration.
            Assert.IsFalse(nodeAuthorization.IsAccessible(node),
                "The given node should not be accessable based on the configuration.");
        }

    }
}