Since the depondent dll are still not valid for this project.

We can used the mock one to run the test cases.

You can mock the dll by yourself or use the dll in the DepondentDll.

Note. The dll in the DepondentDll are just mock ones.