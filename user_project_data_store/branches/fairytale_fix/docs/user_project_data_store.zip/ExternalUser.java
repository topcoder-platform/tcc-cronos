package com.cronos.onlinereview.external;

import java.io.Serializable;

public interface ExternalUser extends Serializable {
	long getId();
	String getHandle();
	String getFirstName();
	String getLastName();
	String getEmail();
	String[] getAlternativeEmails();
	String getDesignRating();
	String getDesignReliability();
	String getDevRating();
	String getDevReliability();
}
