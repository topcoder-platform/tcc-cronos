package com.cronos.onlinereview.external;

public interface ProjectRetrieval {
	ExternalProject retrieveProject(long id);
	ExternalProject retrieveProject(String name, String version);
	ExternalProject[] retrieveProjects(long[] ids);
	ExternalProject[] retrieveProjects(String[] name, String[] version);
}
