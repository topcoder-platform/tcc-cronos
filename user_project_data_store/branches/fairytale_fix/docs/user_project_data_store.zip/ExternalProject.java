package com.cronos.onlinereview.external;

import java.io.Serializable;

public interface ExternalProject extends Serializable {
	long getId();
	long getComponentId();
	long getVersionId();
	long getForumId();
	long getCatalogId();
	String getName();
	String getVersion();
}
