package com.cronos.onlinereview.external;

public interface UserRetrieval {
	ExternalUser retrieveUser(long id);
	ExternalUser retrieveUser(String handle);
	ExternalUser[] retrieveUsers(long[] ids);
	ExternalUser[] retrieveUsers(String[] handles);
}
